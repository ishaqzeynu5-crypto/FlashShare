# FlashShare Privacy & Permissions Policy

**FlashShare** (`com.flashshare.app`) operates **100% offline**. It never connects to any external server, contains zero ads, zero analytics SDKs, and zero third-party tracking.

## Distribution Flavors (`full` vs `play`)

| Feature / Permission | `full` Flavor (Direct APK / F-Droid) | `play` Flavor (Google Play Store) |
| :--- | :---: | :---: |
| Offline Wi-Fi Direct & LAN transfers (Protocol V5) | Included | Included |
| Browser sharing over local Wi-Fi (plain HTTP) | Included | Included |
| Photos, Videos, Music, Documents (SAF) | Included | Included |
| `READ_CONTACTS` / `WRITE_CONTACTS` (Phone Clone contacts) | Included (lazy prompt) | **Removed** (`tools:node="remove"`) |
| `REQUEST_INSTALL_PACKAGES` (APK & `.apks` PackageInstaller) | Included | **Removed** (`tools:node="remove"`) |
| `<queries>` (`ACTION_MAIN`/`CATEGORY_LAUNCHER` Apps tab) | Included | **Removed** (`tools:node="remove"`) |

## Permission Justifications

| Permission | Scope & Usage |
| :--- | :--- |
| `INTERNET`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_STATE`, `ACCESS_NETWORK_STATE`, `CHANGE_NETWORK_STATE` | Local LAN / Wi-Fi Direct TCP sockets and the local HTTP browser-sharing server only. No outbound internet traffic is ever made. |
| `NEARBY_WIFI_DEVICES` (`neverForLocation`) / `ACCESS_FINE_LOCATION` (`maxSdkVersion="32"`) | Required by Android OS for offline Wi-Fi Direct peer discovery. Location is never read, logged, or transmitted. |
| `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`, `READ_MEDIA_VISUAL_USER_SELECTED` | Browsing and selecting photos, videos, and audio locally, including Android 14+ partial visual selection. |
| `CAMERA` | Requested lazily only when scanning QR codes offline via ZXing. |
| `READ_CONTACTS`, `WRITE_CONTACTS` (`full` flavor only) | Requested lazily only when exporting/importing vCard 3.0 (`.vcf`) contacts locally in Phone Clone. |
| `REQUEST_INSTALL_PACKAGES` (`full` flavor only) | Allows tapping a received `.apk` or split-APK `.apks` bundle in History to launch Android's `PackageInstaller` after checking `canRequestPackageInstalls()`. |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `POST_NOTIFICATIONS`, `WAKE_LOCK` | Keeps large offline transfers alive in the background with live progress notifications and low-latency Wi-Fi lock. |

## Security & Local Data Storage
- **Protocol V5**: ZRTP-style hash-committed ECDH P-256 + HKDF-SHA256 + AES-256-GCM + mutual ECDSA P-256 Android Keystore device identity + dual-phone SAS confirmation for non-QR transfers + whole-file SHA-256 verification.
- **Web Share**: Plain HTTP on the local Wi-Fi/hotspot interface only (not HTTPS), protected by a 128-bit session token valid until sharing stops, IP-bound `HttpOnly; SameSite=Strict` cookie, and per-IP rate limiting.
- **No Cloud Backup**: `android:allowBackup="false"` with explicit `data_extraction_rules.xml` and `backup_rules.xml`.
