# FlashShare ProGuard / R8 Rules

# Keep Room entities, DAOs, and Database
-keep class com.flashshare.app.data.local.** { *; }
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# Keep Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Keep ZXing core
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**

# Keep transfer models & QR connection payloads
-keep class com.flashshare.app.domain.model.** { *; }

# Keep Parcelable & BroadcastReceivers
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Service

# Strip verbose debug logs in release builds
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}
