package com.flashshare.app.data.storage

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.util.Log
import com.flashshare.app.R
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object InstallResultBus {
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    fun emit(message: String) {
        _messages.tryEmit(message)
    }
}

/**
 * Non-exported BroadcastReceiver that receives PackageInstaller session commit callbacks
 * for received .apks split-APK bundles.
 */
class InstallResultReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "InstallResultReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val extraMessage = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE).orEmpty()

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirmIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                if (confirmIntent != null) {
                    confirmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(confirmIntent) }
                        .onFailure { e ->
                            Log.e(TAG, "Failed to launch PackageInstaller confirmation intent", e)
                            InstallResultBus.emit(context.getString(R.string.install_apks_failed, e.message ?: ""))
                        }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                InstallResultBus.emit(context.getString(R.string.install_apks_success))
            }
            PackageInstaller.STATUS_FAILURE_ABORTED -> {
                InstallResultBus.emit(context.getString(R.string.install_apks_cancelled))
            }
            else -> {
                Log.w(TAG, "Split APK install failed: status=$status msg=$extraMessage")
                InstallResultBus.emit(
                    context.getString(
                        R.string.install_apks_failed,
                        extraMessage.ifBlank { "code $status" }
                    )
                )
            }
        }
    }
}
