package com.flashshare.app.transfer

import com.flashshare.app.domain.model.IncomingTransferRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap

/**
 * Coordinates incoming transfer approval prompts with:
 * - Keying strictly by (batchId, peerFingerprint) so a sniffing attacker cannot inherit another sender's approval
 * - Bounded pending queue (max 3 pending requests)
 * - Per-remote-IP rate limiting (max 3 prompts per 60s window)
 */
class ApprovalCoordinator(
    private val maxPendingQueue: Int = MAX_PENDING_QUEUE,
    private val maxPromptsPerIpWindow: Int = MAX_PROMPTS_PER_IP_WINDOW,
    private val rateWindowMs: Long = RATE_WINDOW_MS,
    private val approvalTimeoutMs: Long = APPROVAL_TIMEOUT_MS,
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    companion object {
        const val MAX_PENDING_QUEUE = 3
        const val MAX_PROMPTS_PER_IP_WINDOW = 3
        const val RATE_WINDOW_MS = 60_000L
        const val APPROVAL_TIMEOUT_MS = 60_000L
    }

    data class ApprovalKey(val batchId: String, val peerFingerprint: String)

    private val lock = Any()
    private val activeDecisions = ConcurrentHashMap<ApprovalKey, CompletableDeferred<Boolean>>()
    private val pendingQueue = ArrayDeque<Pair<ApprovalKey, IncomingTransferRequest>>()
    private val ipPromptTimestamps = HashMap<String, MutableList<Long>>()

    private val _currentPending = MutableStateFlow<IncomingTransferRequest?>(null)
    val currentPending: StateFlow<IncomingTransferRequest?> = _currentPending.asStateFlow()

    suspend fun awaitApproval(
        request: IncomingTransferRequest,
        remoteIp: String
    ): Boolean {
        val key = ApprovalKey(request.batchId, request.senderFingerprint)

        // Reuse existing decision for same (batchId, peerFingerprint) (parallel worker/range sockets)
        activeDecisions[key]?.let { existing ->
            return withTimeoutOrNull(approvalTimeoutMs) { existing.await() } ?: false
        }

        val deferred = CompletableDeferred<Boolean>()
        val enqueued = synchronized(lock) {
            val existing = activeDecisions[key]
            if (existing != null) {
                return@synchronized existing
            }

            // Per-IP rate limit check & purge
            val now = clockMs()
            purgeExpiredRateLimitsLocked(now)
            val timestamps = ipPromptTimestamps.getOrPut(remoteIp) { mutableListOf() }
            if (timestamps.size >= maxPromptsPerIpWindow) {
                return@synchronized null
            }

            // Bounded pending queue check
            if (pendingQueue.size >= maxPendingQueue) {
                return@synchronized null
            }

            timestamps.add(now)
            activeDecisions[key] = deferred
            pendingQueue.addLast(key to request)
            if (_currentPending.value == null) {
                _currentPending.value = pendingQueue.firstOrNull()?.second
            }
            deferred
        } ?: return false

        // If another socket won the race inside the synchronized block, await its deferred
        if (enqueued !== deferred) {
            return withTimeoutOrNull(approvalTimeoutMs) { enqueued.await() } ?: false
        }

        val result = withTimeoutOrNull(approvalTimeoutMs) { deferred.await() } ?: false
        synchronized(lock) {
            if (!deferred.isCompleted) deferred.complete(false)
            removeFromQueueLocked(key)
            activeDecisions.remove(key, deferred)
        }
        return result
    }

    fun respond(batchId: String, senderFingerprint: String, accept: Boolean): IncomingTransferRequest? {
        val key = ApprovalKey(batchId, senderFingerprint)
        var answered: IncomingTransferRequest? = null
        synchronized(lock) {
            answered = removeFromQueueLocked(key)
            activeDecisions[key]?.complete(accept)
        }
        return answered
    }

    fun pendingCount(): Int = synchronized(lock) { pendingQueue.size }

    private fun removeFromQueueLocked(key: ApprovalKey): IncomingTransferRequest? {
        var removed: IncomingTransferRequest? = null
        val iter = pendingQueue.iterator()
        while (iter.hasNext()) {
            val item = iter.next()
            if (item.first == key) {
                removed = item.second
                iter.remove()
                break
            }
        }
        _currentPending.value = pendingQueue.firstOrNull()?.second
        return removed
    }

    private fun purgeExpiredRateLimitsLocked(nowMs: Long) {
        val cutoff = nowMs - rateWindowMs
        val mapIter = ipPromptTimestamps.entries.iterator()
        while (mapIter.hasNext()) {
            val entry = mapIter.next()
            entry.value.removeAll { it < cutoff }
            if (entry.value.isEmpty()) mapIter.remove()
        }
    }
}
