package com.flashshare.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.flashshare.app.R
import java.util.Locale

val BgBlack = Color(0xFF0A0A0B)
val SurfaceDark = Color(0xFF151618)
val SurfaceContainerDark = Color(0xFF1E1F23)
val OutlineSubtle = Color(0xFF2A2C31)
val OutlineStrong = Color(0xFF4A4D55)
val TextPrimary = Color(0xFFF2F3F5)
val TextSecondary = Color(0xFF9AA0AA)

private val MonochromeDarkScheme = darkColorScheme(
    primary = TextPrimary,
    onPrimary = BgBlack,
    primaryContainer = SurfaceContainerDark,
    onPrimaryContainer = TextPrimary,
    secondary = SurfaceContainerDark,
    onSecondary = TextPrimary,
    secondaryContainer = SurfaceDark,
    onSecondaryContainer = TextPrimary,
    tertiary = TextPrimary,
    onTertiary = BgBlack,
    background = BgBlack,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceContainerDark,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = SurfaceContainerDark,
    surfaceContainerLow = SurfaceDark,
    surfaceContainerHigh = SurfaceContainerDark,
    outline = OutlineStrong,
    outlineVariant = OutlineSubtle,
    error = TextPrimary,
    onError = BgBlack
)

val LatinFontFamily = FontFamily(
    Font(R.font.noto_sans_regular, FontWeight.Normal),
    Font(R.font.noto_sans_bold, FontWeight.Bold)
)

val EthiopicFontFamily = FontFamily(
    Font(R.font.noto_sans_ethiopic_regular, FontWeight.Normal),
    Font(R.font.noto_sans_ethiopic_bold, FontWeight.Bold)
)

private fun buildTypography(fontFamily: FontFamily): Typography {
    val base = Typography()
    return Typography(
        displayLarge = base.displayLarge.copy(fontFamily = fontFamily),
        displayMedium = base.displayMedium.copy(fontFamily = fontFamily),
        displaySmall = base.displaySmall.copy(fontFamily = fontFamily),
        headlineLarge = base.headlineLarge.copy(fontFamily = fontFamily),
        headlineMedium = base.headlineMedium.copy(fontFamily = fontFamily),
        headlineSmall = base.headlineSmall.copy(fontFamily = fontFamily),
        titleLarge = base.titleLarge.copy(fontFamily = fontFamily),
        titleMedium = base.titleMedium.copy(fontFamily = fontFamily),
        titleSmall = base.titleSmall.copy(fontFamily = fontFamily),
        bodyLarge = base.bodyLarge.copy(fontFamily = fontFamily),
        bodyMedium = base.bodyMedium.copy(fontFamily = fontFamily),
        bodySmall = base.bodySmall.copy(fontFamily = fontFamily),
        labelLarge = base.labelLarge.copy(fontFamily = fontFamily),
        labelMedium = base.labelMedium.copy(fontFamily = fontFamily),
        labelSmall = base.labelSmall.copy(fontFamily = fontFamily)
    )
}

@Composable
fun FlashShareTheme(
    content: @Composable () -> Unit
) {
    val isAmharic = Locale.getDefault().language.equals("am", ignoreCase = true)
    val typography = buildTypography(if (isAmharic) EthiopicFontFamily else LatinFontFamily)
    MaterialTheme(
        colorScheme = MonochromeDarkScheme,
        typography = typography,
        content = content
    )
}
