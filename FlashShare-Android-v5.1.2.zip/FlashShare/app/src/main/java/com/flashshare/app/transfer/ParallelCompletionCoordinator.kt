package com.flashshare.app.transfer

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap

/**
 * Ensures that when multiple parallel range handlers finish a single file transfer concurrently,
 * exactly ONE winner performs SHA-256 verification and MediaStore publishing while all other
 * range handlers wait for the winner's result and reply with that same status byte.
 */
class ParallelCompletionCoordinator(
    private val followerTimeoutMs: Long = 180_000L
) {
    private val inFlight = ConcurrentHashMap<String, CompletableDeferred<Byte>>()

    /**
     * Returns (isWinner, resultByte).
     */
    suspend fun executeOnce(
        transferId: String,
        onWinner: suspend () -> Byte
    ): Pair<Boolean, Byte> {
        val candidate = CompletableDeferred<Byte>()
        val existing = inFlight.putIfAbsent(transferId, candidate)
        return if (existing == null) {
            val result = try {
                onWinner()
            } catch (_: Exception) {
                TransferProtocol.VERIFY_STORAGE_ERROR
            }
            candidate.complete(result)
            true to result
        } else {
            val result = withTimeoutOrNull(followerTimeoutMs) { existing.await() }
                ?: TransferProtocol.VERIFY_HASH_MISMATCH
            false to result
        }
    }

    fun clear(transferId: String) {
        inFlight.remove(transferId)
    }
}
