package com.flashshare.app.data.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import com.flashshare.app.BuildConfig
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.transfer.CryptoHelper
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

class MediaStorePublishException(message: String, cause: Throwable? = null) : IOException(message, cause)

@Singleton
class StorageOrganizer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val TAG = "StorageOrganizer"
        const val MAX_SANITIZED_NAME_LENGTH = 180
        const val PART_RETENTION_MS = 7L * 24L * 60L * 60L * 1000L
        const val SHARE_CACHE_RETENTION_MS = 24L * 60L * 60L * 1000L
        const val MAX_SHARE_CACHE_COPY_BYTES = 512L * 1024L * 1024L // 512 MB cap for external share copies

        /**
         * Hardened filename sanitizer: rejects ".", "..", control chars, path traversal,
         * and over-long names while preserving file extension.
         */
        fun sanitizeFileName(raw: String): String {
            val stripped = raw
                .replace(Regex("[\\x00-\\x1F\\x7F]"), "")
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .trim()
                .trimStart('.')
            if (stripped.isBlank() || stripped == "." || stripped == "..") {
                return "received_${System.currentTimeMillis()}"
            }
            if (stripped.length <= MAX_SANITIZED_NAME_LENGTH) return stripped
            val dot = stripped.lastIndexOf('.')
            return if (dot > 0 && stripped.length - dot <= 16) {
                val ext = stripped.substring(dot)
                val base = stripped.substring(0, (MAX_SANITIZED_NAME_LENGTH - ext.length).coerceAtLeast(1))
                "$base$ext"
            } else {
                stripped.substring(0, MAX_SANITIZED_NAME_LENGTH)
            }
        }
    }

    fun getShareCacheDir(): File = File(context.cacheDir, "share_cache").apply { mkdirs() }

    fun getInProgressDir(): File = File(context.filesDir, "in_progress").apply { mkdirs() }

    /**
     * Keyed app-private .part file so resume never merges two different files with the same name.
     */
    fun resolvePartFile(transferId: String, senderFingerprint: String, totalSizeBytes: Long): File {
        val keyHash = CryptoHelper.sha256Hex(
            transferId.toByteArray(Charsets.UTF_8),
            senderFingerprint.toByteArray(Charsets.UTF_8),
            totalSizeBytes.toString().toByteArray(Charsets.UTF_8)
        ).take(32)
        return File(getInProgressDir(), "$keyHash.part")
    }

    /**
     * Deletes .part files older than 7 days to keep files/in_progress bounded.
     */
    fun cleanupExpiredPartFiles(nowMs: Long = System.currentTimeMillis()): Int {
        val dir = getInProgressDir()
        var deleted = 0
        dir.listFiles()?.forEach { file ->
            if (file.isFile && (nowMs - file.lastModified()) > PART_RETENTION_MS) {
                if (file.delete()) deleted++
            }
        }
        return deleted
    }

    /**
     * Deletes only stale share_cache files older than 24 hours that are not referenced by
     * staged or active transfers (avoids racing with MainActivity external share copies).
     */
    fun cleanupShareCache(
        protectedPaths: Set<String> = emptySet(),
        nowMs: Long = System.currentTimeMillis()
    ): Int {
        val dir = getShareCacheDir()
        var deleted = 0
        dir.listFiles()?.forEach { file ->
            if (file.isFile &&
                file.absolutePath !in protectedPaths &&
                (nowMs - file.lastModified()) > SHARE_CACHE_RETENTION_MS
            ) {
                if (file.delete()) deleted++
            }
        }
        return deleted
    }

    /**
     * Total bytes occupied by temporary .part files and share_cache bundles.
     */
    fun getTemporaryFilesSizeBytes(): Long {
        val inProg = getInProgressDir().listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
        val cache = getShareCacheDir().listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
        return inProg + cache
    }

    /**
     * Clears all temporary .part files and share_cache bundles (triggered from Settings).
     */
    fun clearAllTemporaryFiles(): Long {
        val before = getTemporaryFilesSizeBytes()
        getInProgressDir().listFiles()?.forEach { if (it.isFile) it.delete() }
        getShareCacheDir().listFiles()?.forEach { if (it.isFile) it.delete() }
        return before
    }

    fun getLegacyRootReceiveDir(): File {
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val publicTarget = File(publicDownloads, "FlashShare")
        if ((publicTarget.exists() && publicTarget.canWrite()) || (publicTarget.mkdirs() && publicTarget.canWrite())) {
            return publicTarget
        }
        val appExternal = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        return File(appExternal, "FlashShare").apply { mkdirs() }
    }

    /**
     * Always returns the real storage location actually used on this Android version.
     */
    fun getDisplayStoragePath(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            "Downloads/FlashShare · Pictures/FlashShare · Movies/FlashShare · Music/FlashShare"
        } else {
            getLegacyRootReceiveDir().absolutePath
        }
    }

    fun getAvailableBytes(): Long {
        return try {
            val stat = StatFs(getInProgressDir().absolutePath)
            stat.availableBytes
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * On API 29+, publishing needs the .part file plus the final MediaStore copy at the same time,
     * so require 2x remaining bytes + safety margin.
     */
    fun hasEnoughSpace(remainingBytes: Long, safetyMarginBytes: Long = 16L * 1024L * 1024L): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            (remainingBytes.coerceAtLeast(0L) * 2L) + safetyMarginBytes
        } else {
            remainingBytes.coerceAtLeast(0L) + safetyMarginBytes
        }
        return getAvailableBytes() > needed
    }

    /**
     * Publishes a completed & SHA-256-verified .part file to user-visible storage:
     * - API 29+: MediaStore (Images/Video/Audio when MIME matches collection, else MediaStore.Downloads)
     *   with RELATIVE_PATH and IS_PENDING=1 -> 0. Never falls back silently to a hidden folder.
     * - API 24-28: Legacy Downloads/FlashShare/<Category> + MediaScannerConnection.
     */
    @Throws(MediaStorePublishException::class)
    fun publishCompletedFile(
        partFile: File,
        fileName: String,
        mimeType: String,
        category: FileCategory
    ): String {
        val safeName = sanitizeFileName(fileName)
        val resolvedMime = mimeType.takeIf { it.isNotBlank() } ?: Formatters.inferMimeType(safeName)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val (collection, relativePath) = resolveMediaStoreTarget(category, resolvedMime)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                put(MediaStore.MediaColumns.MIME_TYPE, resolvedMime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            var insertedUri: Uri? = null
            try {
                insertedUri = context.contentResolver.insert(collection, values)
                    ?: throw MediaStorePublishException("MediaStore insert returned null")

                context.contentResolver.openOutputStream(insertedUri)?.use { out ->
                    FileInputStream(partFile).use { input ->
                        input.copyTo(out, bufferSize = 256 * 1024)
                    }
                } ?: throw MediaStorePublishException("Could not open MediaStore output stream")

                val doneValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                context.contentResolver.update(insertedUri, doneValues, null, null)
                partFile.delete()
                return insertedUri.toString()
            } catch (e: Exception) {
                Log.e(TAG, "MediaStore publish failed; rolling back", e)
                insertedUri?.let { uri -> runCatching { context.contentResolver.delete(uri, null, null) } }
                throw if (e is MediaStorePublishException) e else MediaStorePublishException("MediaStore publish failed: ${e.message}", e)
            }
        }

        // API 24-28 legacy public Downloads/FlashShare/<Category>
        val dir = File(getLegacyRootReceiveDir(), category.folderName).apply { mkdirs() }
        val target = resolveUniqueLegacyFile(dir, safeName)
        try {
            FileInputStream(partFile).use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output, bufferSize = 256 * 1024)
                }
            }
            partFile.delete()
            scanReceivedFile(target, resolvedMime)
            return target.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Legacy file publish failed", e)
            runCatching { target.delete() }
            throw MediaStorePublishException("Legacy publish failed: ${e.message}", e)
        }
    }

    /**
     * Normalizes MIME against target MediaStore collection.
     * If PHOTOS/VIDEOS/MUSIC has a mismatching MIME, publishes safely to MediaStore.Downloads instead of throwing.
     */
    private fun resolveMediaStoreTarget(category: FileCategory, resolvedMime: String): Pair<Uri, String> {
        val lowerMime = resolvedMime.lowercase()
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                category == FileCategory.PHOTOS && lowerMime.startsWith("image/") ->
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    "${Environment.DIRECTORY_PICTURES}/FlashShare"
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                category == FileCategory.VIDEOS && lowerMime.startsWith("video/") ->
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    "${Environment.DIRECTORY_MOVIES}/FlashShare"
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                category == FileCategory.MUSIC && lowerMime.startsWith("audio/") ->
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    "${Environment.DIRECTORY_MUSIC}/FlashShare"
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    "${Environment.DIRECTORY_DOWNLOADS}/FlashShare/${category.folderName}"
            else ->
                Uri.EMPTY to "${Environment.DIRECTORY_DOWNLOADS}/FlashShare/${category.folderName}"
        }
    }

    fun scanReceivedFile(file: File, mimeType: String? = null) {
        val resolvedMime = mimeType ?: Formatters.inferMimeType(file.name)
        MediaScannerConnection.scanFile(
            context,
            arrayOf(file.absolutePath),
            arrayOf(resolvedMime),
            null
        )
    }

    fun isApksBundle(pathOrUri: String, fileName: String? = null): Boolean {
        val name = (fileName ?: pathOrUri).lowercase()
        return name.endsWith(".apks")
    }

    /**
     * Builds an Intent to open a published MediaStore content:// URI or legacy File path.
     * For APKs on API 26+, checks flavor flag & canRequestPackageInstalls().
     */
    fun buildOpenFileIntent(pathOrUri: String, mimeType: String? = null): Intent? {
        if (pathOrUri.isBlank()) return null
        val isApk = mimeType == "application/vnd.android.package-archive" ||
            pathOrUri.lowercase().endsWith(".apk")

        if (isApk) {
            if (!BuildConfig.ENABLE_APK_INSTALL) return null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()
            ) {
                return Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        }

        val uri: Uri
        val resolvedMime: String
        if (pathOrUri.startsWith("content://")) {
            uri = Uri.parse(pathOrUri)
            resolvedMime = mimeType?.takeIf { it.isNotBlank() }
                ?: context.contentResolver.getType(uri)
                ?: "application/octet-stream"
        } else {
            val file = File(pathOrUri)
            if (!file.exists()) return null
            uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            resolvedMime = mimeType?.takeIf { it.isNotBlank() } ?: Formatters.inferMimeType(file.name)
        }

        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, resolvedMime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun resolveUniqueLegacyFile(dir: File, safeName: String): File {
        val exact = File(dir, safeName)
        if (!exact.exists()) return exact
        val dotIndex = safeName.lastIndexOf('.')
        val base = if (dotIndex > 0) safeName.substring(0, dotIndex) else safeName
        val ext = if (dotIndex > 0) safeName.substring(dotIndex) else ""
        var counter = 1
        while (true) {
            val candidate = File(dir, "$base ($counter)$ext")
            if (!candidate.exists()) return candidate
            counter++
        }
    }
}
