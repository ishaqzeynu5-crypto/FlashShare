package com.flashshare.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.network.WifiDirectState
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineStrong
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceContainerDark
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onSendClick: () -> Unit,
    onReceiveClick: () -> Unit,
    onQrClick: () -> Unit,
    onPhoneCloneClick: () -> Unit,
    onWebShareClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val wifiState by viewModel.wifiDirectState.collectAsState()
    val deviceName by viewModel.deviceName.collectAsState()
    val isWifiEnabled by viewModel.isWifiP2pEnabled.collectAsState()
    val transfers by viewModel.transfers.collectAsState()
    val availableBytes = viewModel.storageOrganizer.getAvailableBytes()

    val activeCount = transfers.count {
        it.status == TransferStatus.RUNNING ||
            it.status == TransferStatus.QUEUED ||
            it.status == TransferStatus.VERIFYING ||
            it.status == TransferStatus.PAUSED
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Header: Avatar + Device Name + QR button + Settings button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(SurfaceContainerDark, CircleShape)
                    .border(1.dp, OutlineStrong, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = deviceName.take(1).uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = deviceName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = stringResource(R.string.storage_free_summary, Formatters.formatBytes(availableBytes)),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            IconButton(
                onClick = onQrClick,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = AppIcons.QrCodeScanner,
                    contentDescription = stringResource(R.string.action_scan_qr),
                    tint = TextPrimary
                )
            }
            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = stringResource(R.string.action_settings),
                    tint = TextPrimary
                )
            }
        }

        // Inline Wi-Fi guidance banner if Wi-Fi is off
        if (!isWifiEnabled) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineStrong),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stringResource(R.string.radar_wifi_off_guidance),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // Active transfer shortcut pill
        if (activeCount > 0) {
            Surface(
                onClick = onOpenTransfers,
                color = SurfaceContainerDark,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, OutlineStrong),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${stringResource(R.string.transfers_title)} ($activeCount)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Icon(AppIcons.SwapVert, contentDescription = null, tint = TextPrimary)
                }
            }
        }

        // Connected peer status card
        if (wifiState is WifiDirectState.Connected) {
            val conn = wifiState as WifiDirectState.Connected
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.radar_connected_to, conn.peerName),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = stringResource(R.string.qr_ip_port_label, conn.groupOwnerIp, conn.port),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    OutlinedButton(
                        onClick = { viewModel.disconnectPeer() },
                        border = BorderStroke(1.dp, OutlineStrong),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.action_disconnect), color = TextPrimary)
                    }
                }
            }
        }

        // Two large primary buttons: Send (white #F2F3F5) and Receive (pale black #1E1F23)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PrimaryHeroButton(
                title = stringResource(R.string.action_send),
                icon = AppIcons.Upload,
                containerColor = TextPrimary,
                contentColor = BgBlack,
                borderColor = TextPrimary,
                onClick = onSendClick,
                modifier = Modifier.weight(1f)
            )
            PrimaryHeroButton(
                title = stringResource(R.string.action_receive),
                icon = AppIcons.Download,
                containerColor = SurfaceContainerDark,
                contentColor = TextPrimary,
                borderColor = OutlineSubtle,
                onClick = onReceiveClick,
                modifier = Modifier.weight(1f)
            )
        }

        // "More ways" section
        Text(
            text = stringResource(R.string.home_more_ways),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            MoreWayRow(
                title = stringResource(R.string.action_phone_clone),
                subtitle = stringResource(R.string.clone_subtitle),
                icon = AppIcons.PhoneAndroid,
                onClick = onPhoneCloneClick
            )
            MoreWayRow(
                title = stringResource(R.string.action_web_share),
                subtitle = stringResource(R.string.web_share_subtitle),
                icon = AppIcons.Language,
                onClick = onWebShareClick
            )
            MoreWayRow(
                title = stringResource(R.string.action_history_row),
                subtitle = stringResource(R.string.history_saved_folder, viewModel.storageOrganizer.getDisplayStoragePath()),
                icon = AppIcons.History,
                onClick = onHistoryClick
            )
        }
    }
}

@Composable
private fun PrimaryHeroButton(
    title: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    borderColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier.height(144.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(34.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun MoreWayRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = SurfaceDark,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, OutlineSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 68.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(SurfaceContainerDark, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 2
                )
            }
        }
    }
}
