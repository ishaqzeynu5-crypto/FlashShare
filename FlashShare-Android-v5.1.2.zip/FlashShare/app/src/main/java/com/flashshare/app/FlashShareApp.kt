package com.flashshare.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.transfer.TransferManager
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class FlashShareApp : Application(), ImageLoaderFactory {

    @Inject
    lateinit var storageOrganizer: StorageOrganizer

    @Inject
    lateinit var transferManager: TransferManager

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        // Clean only stale share_cache files (>24h and not staged/active) and expired .part files (>7d)
        appScope.launch {
            runCatching {
                storageOrganizer.cleanupShareCache(
                    protectedPaths = transferManager.getStagedShareCachePaths()
                )
            }
            runCatching { storageOrganizer.cleanupExpiredPartFiles() }
        }
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .crossfade(true)
            .build()
    }
}
