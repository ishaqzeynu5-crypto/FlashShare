package com.flashshare.app.data.storage

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.flashshare.app.BuildConfig
import com.flashshare.app.R
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream

sealed class ApksInstallOutcome {
    data object PermissionRequired : ApksInstallOutcome()
    data object CommittedAwaitingUser : ApksInstallOutcome()
    data class Error(val message: String) : ApksInstallOutcome()
}

/**
 * Installs received .apks split-APK ZIP bundles via Android PackageInstaller.Session (MODE_FULL_INSTALL).
 * Checks canRequestPackageInstalls() on API 26+ and commits using an explicit PendingIntent
 * with FLAG_MUTABLE (required by Android 12+ PackageInstaller status callbacks).
 */
object ApksInstaller {
    private const val TAG = "ApksInstaller"

    fun installApksBundle(context: Context, pathOrUri: String): ApksInstallOutcome {
        if (!BuildConfig.ENABLE_APK_INSTALL) {
            return ApksInstallOutcome.Error(context.getString(R.string.install_apks_disabled_flavor))
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !context.packageManager.canRequestPackageInstalls()
        ) {
            val settingsIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(settingsIntent) }
            return ApksInstallOutcome.PermissionRequired
        }

        val inputStream = runCatching {
            if (pathOrUri.startsWith("content://")) {
                context.contentResolver.openInputStream(Uri.parse(pathOrUri))
            } else {
                val file = File(pathOrUri)
                if (file.exists() && file.canRead()) FileInputStream(file) else null
            }
        }.getOrNull() ?: return ApksInstallOutcome.Error(context.getString(R.string.history_file_missing))

        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        var sessionId = -1
        var session: PackageInstaller.Session? = null

        return try {
            sessionId = packageInstaller.createSession(params)
            session = packageInstaller.openSession(sessionId)

            var apkEntryCount = 0
            val buf = ByteArray(128 * 1024)
            ZipInputStream(inputStream).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    if (!entry.isDirectory && entry.name.lowercase().endsWith(".apk")) {
                        val safeEntry = StorageOrganizer.sanitizeFileName(entry.name.substringAfterLast('/'))
                        session.openWrite("split_${apkEntryCount}_$safeEntry", 0L, -1L).use { out ->
                            while (true) {
                                val read = zis.read(buf)
                                if (read <= 0) break
                                out.write(buf, 0, read)
                            }
                            session.fsync(out)
                        }
                        apkEntryCount++
                    }
                    zis.closeEntry()
                }
            }

            if (apkEntryCount == 0) {
                session.abandon()
                return ApksInstallOutcome.Error(context.getString(R.string.install_apks_no_entries))
            }

            val callbackIntent = Intent(context, InstallResultReceiver::class.java).apply {
                `package` = context.packageName
            }
            val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                sessionId,
                callbackIntent,
                pendingFlags
            )
            session.commit(pendingIntent.intentSender)
            session.close()
            session = null
            ApksInstallOutcome.CommittedAwaitingUser
        } catch (e: Exception) {
            Log.e(TAG, "Failed to install .apks bundle", e)
            runCatching { session?.abandon() }
            runCatching { session?.close() }
            if (sessionId >= 0) runCatching { packageInstaller.abandonSession(sessionId) }
            ApksInstallOutcome.Error(context.getString(R.string.install_apks_failed, e.message ?: ""))
        } finally {
            runCatching { inputStream.close() }
        }
    }
}
