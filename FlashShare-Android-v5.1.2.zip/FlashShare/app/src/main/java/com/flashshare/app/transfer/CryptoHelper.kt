package com.flashshare.app.transfer

import java.nio.ByteBuffer
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cryptographic primitives for FlashShare Protocol V5 (API 24+ safe; pure-Kotlin Base64Url):
 * - Ephemeral ECDH P-256 (secp256r1) key agreement with ZRTP-style hash commitment
 * - RFC 5869 HKDF-SHA256 key derivation over ECDH secret + optional QR PSK + handshake transcript
 * - 6-digit Short Authentication String (SAS) bound to committed transcript
 * - Constant-time HMAC-SHA256 proof-of-possession for QR push and pull sessions
 * - Zero-allocation ThreadLocal AES-256-GCM chunk encryption/decryption
 */
object CryptoHelper {
    const val AES_KEY_BYTES = 32
    const val BASE_IV_BYTES = 12
    const val GCM_TAG_BYTES = 16
    const val COMMIT_NONCE_BYTES = 32
    private const val GCM_TAG_BITS = 128
    private val secureRandom = SecureRandom()

    // Anonymous ThreadLocal subclass works on API 1+ (avoids API 26+ ThreadLocal factory)
    private val threadCipher = object : ThreadLocal<Cipher>() {
        override fun initialValue(): Cipher = Cipher.getInstance("AES/GCM/NoPadding")
    }

    data class DerivedSessionMaterial(
        val aesKey: SecretKey,
        val sasCode: String
    )

    fun generateKeyBase64(): String {
        val key = ByteArray(AES_KEY_BYTES)
        secureRandom.nextBytes(key)
        return Base64Url.encodeNoPadding(key)
    }

    fun generateRandomToken128Bit(): String {
        val bytes = ByteArray(16)
        secureRandom.nextBytes(bytes)
        return Base64Url.encodeNoPadding(bytes)
    }

    fun generateNonce32(): ByteArray = ByteArray(COMMIT_NONCE_BYTES).also { secureRandom.nextBytes(it) }

    fun decodeKeyBytes(base64: String?): ByteArray? {
        if (base64.isNullOrBlank()) return null
        return runCatching {
            val bytes = Base64Url.decode(base64.trim())
            if (bytes.size == AES_KEY_BYTES) bytes else null
        }.getOrNull()
    }

    fun decodeKey(base64: String?): SecretKey? =
        decodeKeyBytes(base64)?.let { SecretKeySpec(it, "AES") }

    fun generateEcdhKeyPair(): KeyPair {
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"), secureRandom)
        return kpg.generateKeyPair()
    }

    fun computeEcdhSharedSecret(privateKey: PrivateKey, peerPublicKeyEncoded: ByteArray): ByteArray {
        val kf = KeyFactory.getInstance("EC")
        val peerPub = kf.generatePublic(X509EncodedKeySpec(peerPublicKeyEncoded))
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(privateKey)
        ka.doPhase(peerPub, true)
        return ka.generateSecret()
    }

    /**
     * ZRTP-style commitment: SHA-256("FLASHSHARE-V5-COMMIT|" || ecdhPub || nonce).
     */
    fun computeCommitment(ecdhPub: ByteArray, nonce: ByteArray): ByteArray =
        sha256("FLASHSHARE-V5-COMMIT|".toByteArray(Charsets.UTF_8), ecdhPub, nonce)

    /**
     * Derives the AES-256 session key and 6-digit SAS verification code via HKDF-SHA256
     * over ECDH shared secret + optional QR pre-shared key + handshake transcript hash.
     */
    fun deriveSessionMaterial(
        ecdhSecret: ByteArray,
        transcriptHash: ByteArray,
        qrPskBytes: ByteArray? = null
    ): DerivedSessionMaterial {
        val ikm = if (qrPskBytes != null && qrPskBytes.isNotEmpty()) {
            ByteArray(ecdhSecret.size + qrPskBytes.size).also {
                System.arraycopy(ecdhSecret, 0, it, 0, ecdhSecret.size)
                System.arraycopy(qrPskBytes, 0, it, ecdhSecret.size, qrPskBytes.size)
            }
        } else {
            ecdhSecret
        }
        val prk = hkdfExtract(salt = transcriptHash, ikm = ikm)
        val aesKeyBytes = hkdfExpand(prk, "FlashShare-v5-AES256-GCM".toByteArray(Charsets.UTF_8), AES_KEY_BYTES)
        val sasBytes = hkdfExpand(prk, "FlashShare-v5-SAS".toByteArray(Charsets.UTF_8), 4)
        val sasInt = (ByteBuffer.wrap(sasBytes).int and 0x7FFFFFFF) % 1_000_000
        val sasCode = "%03d-%03d".format(sasInt / 1000, sasInt % 1000)
        return DerivedSessionMaterial(
            aesKey = SecretKeySpec(aesKeyBytes, "AES"),
            sasCode = sasCode
        )
    }

    fun hkdfExtract(salt: ByteArray, ikm: ByteArray): ByteArray {
        val effectiveSalt = if (salt.isEmpty()) ByteArray(32) else salt
        return hmacSha256(effectiveSalt, ikm)
    }

    fun hkdfExpand(prk: ByteArray, info: ByteArray, length: Int): ByteArray {
        val hashLen = 32
        val n = (length + hashLen - 1) / hashLen
        val okm = ByteArray(length)
        var t = ByteArray(0)
        var offset = 0
        for (i in 1..n) {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(prk, "HmacSHA256"))
            mac.update(t)
            mac.update(info)
            mac.update(i.toByte())
            t = mac.doFinal()
            val copyLen = minOf(hashLen, length - offset)
            System.arraycopy(t, 0, okm, offset, copyLen)
            offset += copyLen
        }
        return okm
    }

    fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    /**
     * Proof of possession over (batchId | clientEcdhPub | roleLabel) for both QR PUSH and QR PULL.
     */
    fun computeQrProof(
        qrKeyBytes: ByteArray,
        batchId: String,
        clientEcdhPub: ByteArray,
        roleLabel: String
    ): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(qrKeyBytes, "HmacSHA256"))
        mac.update("FLASHSHARE-V5-QR-PROOF|".toByteArray(Charsets.UTF_8))
        mac.update(batchId.toByteArray(Charsets.UTF_8))
        mac.update('|'.code.toByte())
        mac.update(clientEcdhPub)
        mac.update('|'.code.toByte())
        mac.update(roleLabel.toByteArray(Charsets.UTF_8))
        return mac.doFinal()
    }

    fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    fun sha256(vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        parts.forEach { md.update(it) }
        return md.digest()
    }

    fun sha256Hex(vararg parts: ByteArray): String =
        sha256(*parts).joinToString("") { "%02x".format(it) }

    fun generateBaseIv(): ByteArray = ByteArray(BASE_IV_BYTES).also { secureRandom.nextBytes(it) }

    fun encryptChunkInto(
        key: SecretKey,
        baseIv: ByteArray,
        chunkIndex: Long,
        plain: ByteArray,
        length: Int,
        outBuf: ByteArray,
        nonceScratch: ByteArray
    ): Int {
        deriveNonceInto(baseIv, chunkIndex, nonceScratch)
        val cipher = threadCipher.get()!!
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonceScratch))
        return cipher.doFinal(plain, 0, length, outBuf, 0)
    }

    fun decryptChunkInto(
        key: SecretKey,
        baseIv: ByteArray,
        chunkIndex: Long,
        ciphertext: ByteArray,
        length: Int,
        outBuf: ByteArray,
        nonceScratch: ByteArray
    ): Int {
        deriveNonceInto(baseIv, chunkIndex, nonceScratch)
        val cipher = threadCipher.get()!!
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonceScratch))
        return cipher.doFinal(ciphertext, 0, length, outBuf, 0)
    }

    private fun deriveNonceInto(baseIv: ByteArray, chunkIndex: Long, outNonce: ByteArray) {
        System.arraycopy(baseIv, 0, outNonce, 0, BASE_IV_BYTES)
        for (i in 0 until 8) {
            val shift = (7 - i) * 8
            val idxByte = ((chunkIndex ushr shift) and 0xFFL).toInt()
            outNonce[4 + i] = (outNonce[4 + i].toInt() xor idxByte).toByte()
        }
    }
}
