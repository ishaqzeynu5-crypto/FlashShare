package com.flashshare.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Lightweight custom vector icons replacing material-icons-extended (~20 MB savings).
 */
object AppIcons {

    val Upload: ImageVector by lazy {
        icon("Upload") {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.NonZero) {
                moveTo(9f, 16f); horizontalLineToRelative(6f); verticalLineToRelative(-6f)
                horizontalLineToRelative(4f); lineToRelative(-7f, -7f); lineToRelative(-7f, 7f)
                horizontalLineToRelative(4f); close()
                moveTo(5f, 18f); horizontalLineToRelative(14f); verticalLineToRelative(2f)
                horizontalLineTo(5f); close()
            }
        }
    }

    val Download: ImageVector by lazy {
        icon("Download") {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.NonZero) {
                moveTo(19f, 9f); horizontalLineToRelative(-4f); verticalLineTo(3f)
                horizontalLineTo(9f); verticalLineToRelative(6f); horizontalLineTo(5f)
                lineToRelative(7f, 7f); lineToRelative(7f, -7f); close()
                moveTo(5f, 18f); verticalLineToRelative(2f); horizontalLineToRelative(14f)
                verticalLineToRelative(-2f); horizontalLineTo(5f); close()
            }
        }
    }

    val Folder: ImageVector by lazy {
        icon("Folder") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(10f, 4f); horizontalLineTo(4f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                verticalLineToRelative(12f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                horizontalLineToRelative(16f); curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f)
                verticalLineTo(8f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
                horizontalLineToRelative(-8f); lineToRelative(-2f, -2f); close()
            }
        }
    }

    val SwapVert: ImageVector by lazy {
        icon("SwapVert") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(16f, 17.01f); verticalLineTo(10f); horizontalLineToRelative(-2f)
                verticalLineToRelative(7.01f); horizontalLineToRelative(-3f); lineTo(15f, 21f)
                lineToRelative(4f, -3.99f); horizontalLineToRelative(-3f); close()
                moveTo(9f, 3f); lineTo(5f, 6.99f); horizontalLineToRelative(3f); verticalLineTo(14f)
                horizontalLineToRelative(2f); verticalLineTo(6.99f); horizontalLineToRelative(3f)
                lineTo(9f, 3f); close()
            }
        }
    }

    val History: ImageVector by lazy {
        icon("History") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(13f, 3f); curveToRelative(-4.97f, 0f, -9f, 4.03f, -9f, 9f)
                horizontalLineTo(1f); lineToRelative(3.89f, 3.89f); lineToRelative(0.07f, 0.14f)
                lineTo(9f, 12f); horizontalLineTo(6f); curveToRelative(0f, -3.87f, 3.13f, -7f, 7f, -7f)
                reflectiveCurveToRelative(7f, 3.13f, 7f, 7f); reflectiveCurveToRelative(-3.13f, 7f, -7f, 7f)
                curveToRelative(-1.93f, 0f, -3.68f, -0.79f, -4.94f, -2.06f); lineToRelative(-1.42f, 1.42f)
                curveTo(8.27f, 19.99f, 10.51f, 21f, 13f, 21f); curveToRelative(4.97f, 0f, 9f, -4.03f, 9f, -9f)
                reflectiveCurveToRelative(-4.03f, -9f, -9f, -9f); close()
                moveTo(12f, 8f); verticalLineToRelative(5f); lineToRelative(4.28f, 2.54f)
                lineToRelative(0.72f, -1.21f); lineToRelative(-3.5f, -2.08f); verticalLineTo(8f); close()
            }
        }
    }

    val Radar: ImageVector by lazy {
        icon("Radar") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f); curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
                reflectiveCurveToRelative(4.48f, 10f, 10f, 10f); reflectiveCurveToRelative(10f, -4.48f, 10f, -10f)
                reflectiveCurveTo(17.52f, 2f, 12f, 2f); close()
                moveTo(12f, 20f); curveToRelative(-4.42f, 0f, -8f, -3.58f, -8f, -8f)
                reflectiveCurveToRelative(3.58f, -8f, 8f, -8f); reflectiveCurveToRelative(8f, 3.58f, 8f, 8f)
                reflectiveCurveToRelative(-3.58f, 8f, -8f, 8f); close()
                moveTo(12f, 9f); curveToRelative(-1.66f, 0f, -3f, 1.34f, -3f, 3f)
                reflectiveCurveToRelative(1.34f, 3f, 3f, 3f); reflectiveCurveToRelative(3f, -1.34f, 3f, -3f)
                reflectiveCurveToRelative(-1.34f, -3f, -3f, -3f); close()
            }
        }
    }

    val PhoneAndroid: ImageVector by lazy {
        icon("PhoneAndroid") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(16f, 1f); horizontalLineTo(8f); curveTo(6.34f, 1f, 5f, 2.34f, 5f, 4f)
                verticalLineToRelative(16f); curveToRelative(0f, 1.66f, 1.34f, 3f, 3f, 3f)
                horizontalLineToRelative(8f); curveToRelative(1.66f, 0f, 3f, -1.34f, 3f, -3f)
                verticalLineTo(4f); curveToRelative(0f, -1.66f, -1.34f, -3f, -3f, -3f); close()
                moveTo(14f, 21f); horizontalLineToRelative(-4f); verticalLineToRelative(-1f)
                horizontalLineToRelative(4f); verticalLineToRelative(1f); close()
                moveTo(17.25f, 18f); horizontalLineTo(6.75f); verticalLineTo(4f)
                horizontalLineToRelative(10.5f); verticalLineToRelative(14f); close()
            }
        }
    }

    val Language: ImageVector by lazy {
        icon("Language") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f); curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
                reflectiveCurveToRelative(4.48f, 10f, 10f, 10f); reflectiveCurveToRelative(10f, -4.48f, 10f, -10f)
                reflectiveCurveTo(17.52f, 2f, 12f, 2f); close()
                moveTo(11f, 19.93f); curveToRelative(-3.95f, -0.49f, -7f, -3.85f, -7f, -7.93f)
                curveToRelative(0f, -0.62f, 0.08f, -1.21f, 0.21f, -1.79f); lineTo(9f, 15f)
                verticalLineToRelative(1f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                verticalLineToRelative(1.93f); close()
                moveTo(17.9f, 17.39f); curveToRelative(-0.26f, -0.81f, -1f, -1.39f, -1.9f, -1.39f)
                horizontalLineToRelative(-1f); verticalLineToRelative(-3f); curveToRelative(0f, -0.55f, -0.45f, -1f, -1f, -1f)
                horizontalLineTo(8f); verticalLineToRelative(-2f); horizontalLineToRelative(2f)
                curveToRelative(0.55f, 0f, 1f, -0.45f, 1f, -1f); verticalLineTo(7f); horizontalLineToRelative(2f)
                curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f); verticalLineToRelative(-0.41f)
                curveToRelative(2.93f, 1.19f, 5f, 4.06f, 5f, 7.41f)
                curveToRelative(0f, 2.08f, -0.8f, 3.97f, -2.1f, 5.39f); close()
            }
        }
    }

    val Wifi: ImageVector by lazy {
        icon("Wifi") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(1f, 9f); lineToRelative(2f, 2f); curveToRelative(4.97f, -4.97f, 13.03f, -4.97f, 18f, 0f)
                lineToRelative(2f, -2f); curveTo(16.93f, 2.93f, 7.08f, 2.93f, 1f, 9f); close()
                moveTo(9f, 17f); lineToRelative(3f, 3f); lineToRelative(3f, -3f)
                curveToRelative(-1.65f, -1.66f, -4.34f, -1.66f, -6f, 0f); close()
                moveTo(5f, 13f); lineToRelative(2f, 2f); curveToRelative(2.76f, -2.76f, 7.24f, -2.76f, 10f, 0f)
                lineToRelative(2f, -2f); curveTo(15.14f, 9.14f, 8.87f, 9.14f, 5f, 13f); close()
            }
        }
    }

    val QrCodeScanner: ImageVector by lazy {
        icon("QrCodeScanner") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 3f); horizontalLineToRelative(6f); verticalLineToRelative(2f); horizontalLineTo(5f)
                verticalLineToRelative(4f); horizontalLineTo(3f); close()
                moveTo(15f, 3f); horizontalLineToRelative(6f); verticalLineToRelative(6f); horizontalLineToRelative(-2f)
                verticalLineTo(5f); horizontalLineToRelative(-4f); close()
                moveTo(3f, 15f); horizontalLineToRelative(2f); verticalLineToRelative(4f); horizontalLineToRelative(4f)
                verticalLineToRelative(2f); horizontalLineTo(3f); close()
                moveTo(19f, 15f); horizontalLineToRelative(2f); verticalLineToRelative(6f); horizontalLineToRelative(-6f)
                verticalLineToRelative(-2f); horizontalLineToRelative(4f); close()
                moveTo(7f, 7f); horizontalLineToRelative(4f); verticalLineToRelative(4f); horizontalLineTo(7f); close()
                moveTo(13f, 13f); horizontalLineToRelative(4f); verticalLineToRelative(4f); horizontalLineToRelative(-4f); close()
            }
        }
    }

    val Pause: ImageVector by lazy {
        icon("Pause") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(6f, 19f); horizontalLineToRelative(4f); verticalLineTo(5f); horizontalLineTo(6f); close()
                moveTo(14f, 5f); verticalLineToRelative(14f); horizontalLineToRelative(4f); verticalLineTo(5f); close()
            }
        }
    }

    val Replay: ImageVector by lazy {
        icon("Replay") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 5f); verticalLineTo(1f); lineTo(7f, 6f); lineToRelative(5f, 5f); verticalLineTo(7f)
                curveToRelative(3.31f, 0f, 6f, 2.69f, 6f, 6f); reflectiveCurveToRelative(-2.69f, 6f, -6f, 6f)
                reflectiveCurveToRelative(-6f, -2.69f, -6f, -6f); horizontalLineTo(4f)
                curveToRelative(0f, 4.42f, 3.58f, 8f, 8f, 8f); reflectiveCurveToRelative(8f, -3.58f, 8f, -8f)
                reflectiveCurveToRelative(-3.58f, -8f, -8f, -8f); close()
            }
        }
    }

    val Description: ImageVector by lazy {
        icon("Description") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(14f, 2f); horizontalLineTo(6f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                verticalLineToRelative(16f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                horizontalLineToRelative(12f); curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f)
                verticalLineTo(8f); lineToRelative(-6f, -6f); close()
                moveTo(16f, 18f); horizontalLineTo(8f); verticalLineToRelative(-2f); horizontalLineToRelative(8f); close()
                moveTo(16f, 14f); horizontalLineTo(8f); verticalLineToRelative(-2f); horizontalLineToRelative(8f); close()
                moveTo(13f, 9f); verticalLineTo(3.5f); lineTo(18.5f, 9f); horizontalLineTo(13f); close()
            }
        }
    }

    val MusicNote: ImageVector by lazy {
        icon("MusicNote") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 3f); verticalLineToRelative(10.55f)
                curveToRelative(-0.59f, -0.34f, -1.27f, -0.55f, -2f, -0.55f)
                curveToRelative(-2.21f, 0f, -4f, 1.79f, -4f, 4f); reflectiveCurveToRelative(1.79f, 4f, 4f, 4f)
                reflectiveCurveToRelative(4f, -1.79f, 4f, -4f); verticalLineTo(7f); horizontalLineToRelative(4f)
                verticalLineTo(3f); horizontalLineToRelative(-6f); close()
            }
        }
    }

    val PlayCircle: ImageVector by lazy {
        icon("PlayCircle") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f); curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
                reflectiveCurveToRelative(4.48f, 10f, 10f, 10f); reflectiveCurveToRelative(10f, -4.48f, 10f, -10f)
                reflectiveCurveTo(17.52f, 2f, 12f, 2f); close()
                moveTo(10f, 16.5f); verticalLineToRelative(-9f); lineToRelative(6f, 4.5f)
                lineToRelative(-6f, 4.5f); close()
            }
        }
    }

    val PhotoLibrary: ImageVector by lazy {
        icon("PhotoLibrary") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(21f, 19f); verticalLineTo(5f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
                horizontalLineTo(5f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                verticalLineToRelative(14f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                horizontalLineToRelative(14f); curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f); close()
                moveTo(8.5f, 13.5f); lineToRelative(2.5f, 3.01f); lineTo(14.5f, 12f)
                lineToRelative(4.5f, 6f); horizontalLineTo(5f); lineToRelative(3.5f, -4.5f); close()
            }
        }
    }

    val Contacts: ImageVector by lazy {
        icon("Contacts") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 12f); curveToRelative(2.21f, 0f, 4f, -1.79f, 4f, -4f)
                reflectiveCurveToRelative(-1.79f, -4f, -4f, -4f); reflectiveCurveToRelative(-4f, 1.79f, -4f, 4f)
                reflectiveCurveToRelative(1.79f, 4f, 4f, 4f); close()
                moveTo(12f, 14f); curveToRelative(-2.67f, 0f, -8f, 1.34f, -8f, 4f)
                verticalLineToRelative(2f); horizontalLineToRelative(16f); verticalLineToRelative(-2f)
                curveToRelative(0f, -2.66f, -5.33f, -4f, -8f, -4f); close()
            }
        }
    }

    private fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector {
        return ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply(block).build()
    }
}
