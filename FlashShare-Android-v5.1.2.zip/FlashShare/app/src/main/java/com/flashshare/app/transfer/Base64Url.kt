package com.flashshare.app.transfer

/**
 * Pure-Kotlin RFC 4648 Section 5 Base64URL encoder/decoder.
 * Works identically on Android API 24+ and standard JVM unit tests without API 26+ JDK Base64
 * or android.util.Base64 (stubbed in JVM tests).
 */
object Base64Url {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    private val DECODE_TABLE = IntArray(128) { -1 }.apply {
        for (i in ALPHABET.indices) {
            this[ALPHABET[i].code] = i
        }
    }

    fun encodeNoPadding(data: ByteArray): String {
        if (data.isEmpty()) return ""
        val sb = StringBuilder(((data.size + 2) / 3) * 4)
        var i = 0
        while (i < data.size) {
            val b0 = data[i++].toInt() and 0xFF
            val hasB1 = i < data.size
            val b1 = if (hasB1) data[i++].toInt() and 0xFF else 0
            val hasB2 = i < data.size
            val b2 = if (hasB2) data[i++].toInt() and 0xFF else 0

            val triple = (b0 shl 16) or (b1 shl 8) or b2
            sb.append(ALPHABET[(triple ushr 18) and 0x3F])
            sb.append(ALPHABET[(triple ushr 12) and 0x3F])
            if (hasB1) sb.append(ALPHABET[(triple ushr 6) and 0x3F])
            if (hasB2) sb.append(ALPHABET[triple and 0x3F])
        }
        return sb.toString()
    }

    /**
     * Decodes a Base64URL string (with or without '=' padding).
     * Throws IllegalArgumentException on any invalid character, bad length, or non-zero trailing bits.
     */
    fun decode(input: String): ByteArray {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return ByteArray(0)

        var padCount = 0
        var end = trimmed.length
        while (end > 0 && trimmed[end - 1] == '=') {
            padCount++
            end--
        }
        if (padCount > 2) throw IllegalArgumentException("Invalid Base64URL padding")
        if (padCount > 0 && trimmed.length % 4 != 0) {
            throw IllegalArgumentException("Invalid padded Base64URL length")
        }

        val effectiveLen = end
        val rem = effectiveLen % 4
        if (rem == 1) throw IllegalArgumentException("Invalid Base64URL length")

        val outLen = (effectiveLen / 4) * 3 + when (rem) {
            2 -> 1
            3 -> 2
            else -> 0
        }
        val out = ByteArray(outLen)
        var outIdx = 0
        var i = 0

        while (i + 4 <= effectiveLen) {
            val v0 = decodeChar(trimmed[i++])
            val v1 = decodeChar(trimmed[i++])
            val v2 = decodeChar(trimmed[i++])
            val v3 = decodeChar(trimmed[i++])
            val triple = (v0 shl 18) or (v1 shl 12) or (v2 shl 6) or v3
            out[outIdx++] = (triple ushr 16).toByte()
            out[outIdx++] = (triple ushr 8).toByte()
            out[outIdx++] = triple.toByte()
        }

        when (rem) {
            2 -> {
                val v0 = decodeChar(trimmed[i++])
                val v1 = decodeChar(trimmed[i])
                if ((v1 and 0x0F) != 0) {
                    throw IllegalArgumentException("Non-zero trailing bits in Base64URL")
                }
                out[outIdx] = ((v0 shl 2) or (v1 ushr 4)).toByte()
            }
            3 -> {
                val v0 = decodeChar(trimmed[i++])
                val v1 = decodeChar(trimmed[i++])
                val v2 = decodeChar(trimmed[i])
                if ((v2 and 0x03) != 0) {
                    throw IllegalArgumentException("Non-zero trailing bits in Base64URL")
                }
                out[outIdx++] = ((v0 shl 2) or (v1 ushr 4)).toByte()
                out[outIdx] = (((v1 and 0x0F) shl 4) or (v2 ushr 2)).toByte()
            }
        }
        return out
    }

    private fun decodeChar(c: Char): Int {
        val code = c.code
        val v = if (code < 128) DECODE_TABLE[code] else -1
        if (v < 0) throw IllegalArgumentException("Invalid Base64URL character: '$c'")
        return v
    }
}
