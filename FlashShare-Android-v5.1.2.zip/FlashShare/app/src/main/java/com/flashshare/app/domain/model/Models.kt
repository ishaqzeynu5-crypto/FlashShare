package com.flashshare.app.domain.model

import android.net.Uri
import java.util.UUID

enum class FileCategory(val folderName: String) {
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    MUSIC("Music"),
    APPS("Apps"),
    DOCUMENTS("Documents"),
    DOWNLOADS("Downloads"),
    CONTACTS("Contacts"),
    OTHER("Other")
}

data class ShareableFile(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val category: FileCategory,
    val uri: Uri,
    val filePath: String? = null,
    val packageName: String? = null,
    val isSplitApk: Boolean = false,
    val lastModified: Long = 0L,
    val durationMs: Long = 0L,
    val isCachedTempFile: Boolean = false
)

enum class TransferDirection {
    SEND,
    RECEIVE
}

enum class TransferStatus {
    QUEUED,
    RUNNING,
    VERIFYING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class TransferItem(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val sizeBytes: Long,
    val transferredBytes: Long = 0L,
    val mimeType: String,
    val category: FileCategory,
    val direction: TransferDirection,
    val status: TransferStatus = TransferStatus.QUEUED,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val sourceUri: Uri? = null,
    val localPath: String? = null,
    val peerName: String = "",
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    val progressFraction: Float
        get() = if (sizeBytes <= 0L) 0f else (transferredBytes.toDouble() / sizeBytes.toDouble())
            .coerceIn(0.0, 1.0)
            .toFloat()

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}

data class IncomingTransferRequest(
    val batchId: String,
    val senderFingerprint: String,
    val senderName: String,
    val fileCount: Int,
    val totalBytes: Long,
    val verificationCode: String? = null,
    val isPullRequest: Boolean = false
)

/**
 * Shown on the sender phone when connecting without a verified QR PSK and to an unpinned
 * receiver (or when a previously pinned receiver's fingerprint has changed).
 */
data class PendingSasVerification(
    val batchId: String,
    val peerFingerprint: String,
    val peerName: String,
    val sasCode: String,
    val fingerprintChangedWarning: Boolean = false
)

data class NearbyDevice(
    val deviceName: String,
    val deviceAddress: String,
    val isGroupOwner: Boolean = false,
    val ipAddress: String? = null,
    val port: Int = 8988
)

enum class QrRole {
    SEND,
    RECEIVE
}

data class QrConnectionPayload(
    val role: QrRole = QrRole.RECEIVE,
    val deviceId: String = "",
    val deviceName: String,
    val ipAddress: String,
    val port: Int = 8988,
    val ssid: String? = null,
    val passphrase: String? = null,
    val encryptionKeyBase64: String? = null
) {
    fun encode(): String {
        val parts = listOf(
            "FLASHSHARE",
            "v5",
            role.name,
            Uri.encode(deviceId),
            Uri.encode(deviceName),
            Uri.encode(ipAddress),
            port.toString(),
            Uri.encode(ssid.orEmpty()),
            Uri.encode(passphrase.orEmpty()),
            Uri.encode(encryptionKeyBase64.orEmpty())
        )
        return parts.joinToString("|")
    }

    companion object {
        fun decode(raw: String): QrConnectionPayload? {
            val parts = raw.trim().split("|")
            if (parts.size < 7 || parts[0] != "FLASHSHARE") return null
            if (parts[1] != "v5") return null
            val role = runCatching { QrRole.valueOf(parts[2]) }.getOrDefault(QrRole.RECEIVE)
            val deviceId = Uri.decode(parts[3])
            val name = Uri.decode(parts[4]).ifBlank { "FlashShare Device" }
            val ip = Uri.decode(parts[5])
            val port = parts[6].toIntOrNull() ?: return null
            if (ip.isBlank() || port !in 1024..65535) return null
            val ssid = parts.getOrNull(7)?.let { Uri.decode(it) }?.ifBlank { null }
            val pass = parts.getOrNull(8)?.let { Uri.decode(it) }?.ifBlank { null }
            val key = parts.getOrNull(9)?.let { Uri.decode(it) }?.ifBlank { null }
            return QrConnectionPayload(
                role = role,
                deviceId = deviceId,
                deviceName = name,
                ipAddress = ip,
                port = port,
                ssid = ssid,
                passphrase = pass,
                encryptionKeyBase64 = key
            )
        }
    }
}

enum class AppLanguage(val tag: String) {
    ENGLISH("en"),
    OROMO("om"),
    AMHARIC("am")
}

data class PhoneCloneSelection(
    val includeContacts: Boolean = true,
    val includePhotos: Boolean = true,
    val includeVideos: Boolean = true,
    val includeMusic: Boolean = true
)

data class PhoneCloneSummary(
    val contactCount: Int = 0,
    val photoCount: Int = 0,
    val photoBytes: Long = 0L,
    val videoCount: Int = 0,
    val videoBytes: Long = 0L,
    val musicCount: Int = 0,
    val musicBytes: Long = 0L
)
