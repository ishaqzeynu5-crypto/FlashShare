package com.flashshare.app.data.repository

import com.flashshare.app.data.local.TransferHistoryDao
import com.flashshare.app.data.local.TransferHistoryEntity
import com.flashshare.app.domain.model.TransferItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferHistoryRepository @Inject constructor(
    private val dao: TransferHistoryDao
) {
    fun observeHistory(): Flow<List<TransferHistoryEntity>> = dao.observeAll()

    suspend fun recordTransfer(item: TransferItem) {
        dao.upsert(
            TransferHistoryEntity(
                id = item.id,
                fileName = item.fileName,
                sizeBytes = item.sizeBytes,
                mimeType = item.mimeType,
                category = item.category.name,
                direction = item.direction.name,
                status = item.status.name,
                localPath = item.localPath,
                sourceUriString = item.sourceUri?.toString(),
                peerName = item.peerName,
                timestamp = item.timestamp
            )
        )
    }

    suspend fun deleteEntry(id: String) {
        dao.deleteById(id)
    }

    suspend fun clearAll() {
        dao.deleteAll()
    }
}
