package com.flashshare.app.transfer

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Abstraction over the device's persistent ECDSA P-256 identity key so JVM unit tests
 * can provide an in-memory key pair without Android Keystore.
 */
interface DeviceIdentityProvider {
    fun getPublicKeyEncoded(): ByteArray
    fun getPublicKeyFingerprint(): String
    fun signTranscript(transcript: ByteArray): ByteArray
}

/**
 * Manages a persistent ECDSA P-256 device identity key pair stored in Android Keystore.
 * Trusted devices are identified by the SHA-256 fingerprint of this public key and
 * authenticated by signing the per-session handshake transcript.
 */
@Singleton
class DeviceIdentityManager @Inject constructor() : DeviceIdentityProvider {

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "flashshare_device_identity_v1"

        fun fingerprintHex(publicKeyEncoded: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(publicKeyEncoded)
            return digest.joinToString("") { "%02x".format(it) }
        }

        fun verifySignature(
            publicKeyEncoded: ByteArray,
            transcript: ByteArray,
            signatureBytes: ByteArray
        ): Boolean {
            return runCatching {
                val kf = KeyFactory.getInstance("EC")
                val pubKey = kf.generatePublic(X509EncodedKeySpec(publicKeyEncoded))
                val sig = Signature.getInstance("SHA256withECDSA")
                sig.initVerify(pubKey)
                sig.update(transcript)
                sig.verify(signatureBytes)
            }.getOrDefault(false)
        }
    }

    @Volatile
    private var cachedKeyPair: KeyPair? = null

    fun getOrCreateKeyPair(): KeyPair {
        cachedKeyPair?.let { return it }
        synchronized(this) {
            cachedKeyPair?.let { return it }
            val kp = loadOrGenerateAndroidKeystoreKeyPair()
            cachedKeyPair = kp
            return kp
        }
    }

    override fun getPublicKeyEncoded(): ByteArray = getOrCreateKeyPair().public.encoded

    override fun getPublicKeyFingerprint(): String = fingerprintHex(getPublicKeyEncoded())

    override fun signTranscript(transcript: ByteArray): ByteArray {
        val kp = getOrCreateKeyPair()
        val sig = Signature.getInstance("SHA256withECDSA")
        sig.initSign(kp.private)
        sig.update(transcript)
        return sig.sign()
    }

    private fun loadOrGenerateAndroidKeystoreKeyPair(): KeyPair {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existingEntry = ks.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
        if (existingEntry != null) {
            return KeyPair(existingEntry.certificate.publicKey, existingEntry.privateKey)
        }
        val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .build()
        kpg.initialize(spec)
        return kpg.generateKeyPair()
    }
}
