package com.flashshare.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [TransferHistoryEntity::class],
    version = 1,
    exportSchema = true
)
abstract class FlashShareDatabase : RoomDatabase() {
    abstract fun transferHistoryDao(): TransferHistoryDao

    companion object {
        /**
         * Explicit migration template for future schema upgrades (replaces fallbackToDestructiveMigration
         * so user transfer history is never wiped).
         */
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Template: add new columns/indices here when bumping database version to 2
            }
        }
    }
}
