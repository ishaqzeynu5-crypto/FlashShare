package com.flashshare.app.data.local

import android.content.Context
import android.os.Build
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.flashshare.app.domain.model.AppLanguage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "flashshare_prefs")

@Singleton
class UserPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val DEVICE_NAME = stringPreferencesKey("device_name")
        val DEVICE_ID = stringPreferencesKey("device_id")
        val TRUSTED_DEVICES = stringSetPreferencesKey("trusted_devices")
        val PINNED_RECEIVERS = stringSetPreferencesKey("pinned_receivers")
    }

    val language: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.LANGUAGE] ?: AppLanguage.ENGLISH.name
        runCatching { AppLanguage.valueOf(raw) }.getOrDefault(AppLanguage.ENGLISH)
    }

    val deviceName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.DEVICE_NAME]?.takeIf { it.isNotBlank() } ?: defaultDeviceName()
    }

    val trustedDevices: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[Keys.TRUSTED_DEVICES] ?: emptySet()
    }

    /**
     * Sender-side pinned receivers: maps normalized receiver peer key (name/IP) -> ECDSA public key fingerprint.
     */
    val pinnedReceivers: Flow<Map<String, String>> = context.dataStore.data.map { prefs ->
        val entries = prefs[Keys.PINNED_RECEIVERS] ?: emptySet()
        buildMap {
            entries.forEach { raw ->
                val sep = raw.lastIndexOf('=')
                if (sep > 0 && sep < raw.length - 1) {
                    put(raw.substring(0, sep), raw.substring(sep + 1))
                }
            }
        }
    }

    suspend fun getOrCreateDeviceId(): String {
        val existing = context.dataStore.data.map { it[Keys.DEVICE_ID] }.first()
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString()
        context.dataStore.edit { it[Keys.DEVICE_ID] = created }
        return created
    }

    suspend fun setLanguage(lang: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = lang.name }
    }

    suspend fun setDeviceName(name: String) {
        context.dataStore.edit { it[Keys.DEVICE_NAME] = name.trim().ifBlank { defaultDeviceName() } }
    }

    suspend fun addTrustedDevice(fingerprint: String) {
        if (fingerprint.isBlank()) return
        context.dataStore.edit { prefs ->
            val updated = (prefs[Keys.TRUSTED_DEVICES] ?: emptySet()) + fingerprint
            prefs[Keys.TRUSTED_DEVICES] = updated
        }
    }

    suspend fun pinReceiverFingerprint(peerKey: String, fingerprint: String) {
        val cleanKey = peerKey.trim().lowercase().replace("=", "_")
        if (cleanKey.isBlank() || fingerprint.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.PINNED_RECEIVERS] ?: emptySet()
            val filtered = current.filterNot { it.startsWith("$cleanKey=") }.toSet()
            prefs[Keys.PINNED_RECEIVERS] = filtered + "$cleanKey=$fingerprint"
        }
    }

    suspend fun getPinnedReceiverFingerprint(peerKey: String): String? {
        val cleanKey = peerKey.trim().lowercase().replace("=", "_")
        if (cleanKey.isBlank()) return null
        return pinnedReceivers.first()[cleanKey]
    }

    suspend fun clearTrustedDevices() {
        context.dataStore.edit {
            it[Keys.TRUSTED_DEVICES] = emptySet()
            it[Keys.PINNED_RECEIVERS] = emptySet()
        }
    }

    fun defaultDeviceName(): String {
        val model = Build.MODEL?.trim().orEmpty()
        val manufacturer = Build.MANUFACTURER?.trim().orEmpty()
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model".trim().ifBlank { "Android Device" }
        }
    }
}
