package com.flashshare.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferStatus

@Entity(tableName = "transfer_history")
data class TransferHistoryEntity(
    @PrimaryKey
    val id: String,
    val fileName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val category: String,
    val direction: String,
    val status: String,
    val localPath: String?,
    val sourceUriString: String?,
    val peerName: String,
    val timestamp: Long
) {
    fun fileCategoryEnum(): FileCategory =
        runCatching { FileCategory.valueOf(category) }.getOrDefault(FileCategory.OTHER)

    fun directionEnum(): TransferDirection =
        runCatching { TransferDirection.valueOf(direction) }.getOrDefault(TransferDirection.RECEIVE)

    fun statusEnum(): TransferStatus =
        runCatching { TransferStatus.valueOf(status) }.getOrDefault(TransferStatus.COMPLETED)
}
