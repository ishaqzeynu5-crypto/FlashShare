package com.flashshare.app.data.repository

import android.content.ContentProviderOperation
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

data class ParsedVCardContact(
    val displayName: String,
    val phones: List<String>,
    val emails: List<String>
)

enum class ContactsImportError {
    FILE_UNREADABLE,
    NO_CONTACTS_FOUND,
    PERMISSION_DENIED
}

data class ContactsImportResult(
    val imported: Int,
    val skippedDuplicates: Int,
    val failed: Int,
    val error: ContactsImportError? = null
)

class ContactDedupeIndex(
    val phoneNameKeys: MutableSet<String> = HashSet(),
    val emailNameKeys: MutableSet<String> = HashSet(),
    val names: MutableSet<String> = HashSet()
)

@Singleton
class ContactsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val TAG = "ContactsRepository"
        const val MAX_IMPORT_CONTACTS = 20_000
        private const val PHONE_MATCH_DIGITS = 9
        private val WHITESPACE_REGEX = Regex("\\s+")

        /**
         * Keeps digits only, then takes the last 9 digits so "+251911223344" and "0911223344" match.
         */
        fun normalizePhone(raw: String): String {
            val digits = buildString(raw.length) {
                for (ch in raw) {
                    if (ch in '0'..'9') append(ch)
                }
            }
            if (digits.isEmpty()) return ""
            return if (digits.length > PHONE_MATCH_DIGITS) {
                digits.substring(digits.length - PHONE_MATCH_DIGITS)
            } else {
                digits
            }
        }

        fun normalizeEmail(raw: String): String = raw.trim().lowercase()

        fun normalizeName(raw: String): String =
            raw.trim().lowercase().replace(WHITESPACE_REGEX, " ")

        /**
         * Pure duplicate check:
         * (a) normalized name is non-empty AND at least one normalized phone/email exists paired with that SAME normalized name, OR
         * (b) contact has no phones and no emails AND its normalized name is already in the index, OR
         * (c) normalized name is empty AND at least one normalized phone/email exists paired with an empty name.
         * Different names sharing a number/email are NOT duplicates.
         */
        fun isDuplicateContact(
            contact: ParsedVCardContact,
            existing: ContactDedupeIndex
        ): Boolean {
            val normName = normalizeName(contact.displayName)
            val normPhones = contact.phones.map { normalizePhone(it) }.filter { it.isNotEmpty() }
            val normEmails = contact.emails.map { normalizeEmail(it) }.filter { it.isNotEmpty() }

            if (normPhones.any { "$it|$normName" in existing.phoneNameKeys } ||
                normEmails.any { "$it|$normName" in existing.emailNameKeys }
            ) {
                return true
            }
            if (normPhones.isEmpty() && normEmails.isEmpty()) {
                return normName.isNotEmpty() && normName in existing.names
            }
            return false
        }

        fun registerContactInIndex(
            contact: ParsedVCardContact,
            existing: ContactDedupeIndex
        ) {
            val normName = normalizeName(contact.displayName)
            contact.phones.forEach { raw ->
                val normPhone = normalizePhone(raw)
                if (normPhone.isNotEmpty()) existing.phoneNameKeys.add("$normPhone|$normName")
            }
            contact.emails.forEach { raw ->
                val normEmail = normalizeEmail(raw)
                if (normEmail.isNotEmpty()) existing.emailNameKeys.add("$normEmail|$normName")
            }
            if (normName.isNotEmpty()) existing.names.add(normName)
        }

        fun formatVCard30(contacts: List<ParsedVCardContact>): String {
            val sb = StringBuilder()
            for (c in contacts) {
                sb.appendLine("BEGIN:VCARD")
                sb.appendLine("VERSION:3.0")
                sb.appendLine("FN:${escapeVcard(c.displayName)}")
                c.phones.forEach { phone -> sb.appendLine("TEL;TYPE=CELL:$phone") }
                c.emails.forEach { email -> sb.appendLine("EMAIL:$email") }
                sb.appendLine("END:VCARD")
            }
            return sb.toString()
        }

        fun parseVCardLines(lines: Sequence<String>): List<ParsedVCardContact> {
            val results = mutableListOf<ParsedVCardContact>()
            var currentName = ""
            val currentPhones = mutableListOf<String>()
            val currentEmails = mutableListOf<String>()

            for (rawLine in lines) {
                val line = rawLine.trim()
                when {
                    line.equals("BEGIN:VCARD", ignoreCase = true) -> {
                        currentName = ""
                        currentPhones.clear()
                        currentEmails.clear()
                    }
                    line.startsWith("FN:", ignoreCase = true) -> {
                        currentName = unescapeVcard(line.substringAfter(":").trim())
                    }
                    line.startsWith("TEL", ignoreCase = true) && line.contains(":") -> {
                        val phone = line.substringAfter(":").trim()
                        if (phone.isNotBlank()) currentPhones.add(phone)
                    }
                    line.startsWith("EMAIL", ignoreCase = true) && line.contains(":") -> {
                        val email = line.substringAfter(":").trim()
                        if (email.isNotBlank()) currentEmails.add(email)
                    }
                    line.equals("END:VCARD", ignoreCase = true) -> {
                        if (currentName.isNotBlank() || currentPhones.isNotEmpty() || currentEmails.isNotEmpty()) {
                            results.add(
                                ParsedVCardContact(
                                    displayName = currentName,
                                    phones = currentPhones.toList(),
                                    emails = currentEmails.toList()
                                )
                            )
                        }
                    }
                }
            }
            return results
        }

        private fun escapeVcard(value: String): String =
            value.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;")

        private fun unescapeVcard(value: String): String =
            value.replace("\\;", ";").replace("\\,", ",").replace("\\\\", "\\")
    }

    suspend fun getContactCount(): Int = withContext(Dispatchers.IO) {
        var count = 0
        runCatching {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID),
                null,
                null,
                null
            )?.use { cursor -> count = cursor.count }
        }
        count
    }

    suspend fun exportContactsToVcf(): ShareableFile? = withContext(Dispatchers.IO) {
        val contactsMap = linkedMapOf<String, Pair<String, MutableList<String>>>()
        val emailMap = mutableMapOf<String, MutableList<String>>()

        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol) ?: continue
                    val name = cursor.getString(nameCol)?.trim().orEmpty().ifBlank { "Unnamed" }
                    val number = cursor.getString(numCol)?.trim().orEmpty()
                    if (number.isBlank()) continue
                    val entry = contactsMap.getOrPut(contactId) { name to mutableListOf() }
                    if (number !in entry.second) entry.second.add(number)
                }
            }

            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Email.ADDRESS
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
                val emailCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol) ?: continue
                    val email = cursor.getString(emailCol)?.trim().orEmpty()
                    if (email.isNotBlank()) emailMap.getOrPut(contactId) { mutableListOf() }.add(email)
                }
            }
        }

        val parsedList = contactsMap.map { (id, pair) ->
            ParsedVCardContact(pair.first, pair.second, emailMap[id].orEmpty())
        }
        if (parsedList.isEmpty()) return@withContext null

        val exportDir = File(context.cacheDir, "share_cache").apply { mkdirs() }
        val vcfFile = File(exportDir, "FlashShare_Contacts_${System.currentTimeMillis()}.vcf")
        vcfFile.writeText(formatVCard30(parsedList), Charsets.UTF_8)

        ShareableFile(
            id = "contacts_vcf_${vcfFile.name}",
            name = vcfFile.name,
            sizeBytes = vcfFile.length(),
            mimeType = "text/vcard",
            category = FileCategory.CONTACTS,
            uri = Uri.fromFile(vcfFile),
            filePath = vcfFile.absolutePath,
            lastModified = vcfFile.lastModified()
        )
    }

    /**
     * Imports a received vCard (.vcf) from either a MediaStore content:// URI or a legacy File path
     * with (name + phone/email) pair duplicate detection, bounded contact limit, and clear error reporting.
     */
    suspend fun importContactsFromLocation(pathOrUri: String): ContactsImportResult = withContext(Dispatchers.IO) {
        val stream = try {
            if (pathOrUri.startsWith("content://")) {
                context.contentResolver.openInputStream(Uri.parse(pathOrUri))
            } else {
                val file = File(pathOrUri)
                if (file.exists()) FileInputStream(file) else null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to open vCard stream: ${e.javaClass.simpleName}")
            return@withContext ContactsImportResult(
                imported = 0,
                skippedDuplicates = 0,
                failed = 0,
                error = ContactsImportError.FILE_UNREADABLE
            )
        } ?: return@withContext ContactsImportResult(
            imported = 0,
            skippedDuplicates = 0,
            failed = 0,
            error = ContactsImportError.FILE_UNREADABLE
        )

        val parsed = try {
            stream.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                    parseVCardLines(reader.lineSequence())
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse vCard: ${e.javaClass.simpleName}")
            return@withContext ContactsImportResult(
                imported = 0,
                skippedDuplicates = 0,
                failed = 0,
                error = ContactsImportError.FILE_UNREADABLE
            )
        }

        val totalParsed = parsed.size
        if (totalParsed == 0) {
            return@withContext ContactsImportResult(
                imported = 0,
                skippedDuplicates = 0,
                failed = 0,
                error = ContactsImportError.NO_CONTACTS_FOUND
            )
        }

        val dedupeIndex = try {
            loadExistingContactIndex()
        } catch (se: SecurityException) {
            Log.w(TAG, "Contacts read denied: ${se.javaClass.simpleName}")
            return@withContext ContactsImportResult(
                imported = 0,
                skippedDuplicates = 0,
                failed = totalParsed,
                error = ContactsImportError.PERMISSION_DENIED
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load existing contacts: ${e.javaClass.simpleName}")
            ContactDedupeIndex()
        }

        val toProcess = if (totalParsed > MAX_IMPORT_CONTACTS) {
            parsed.subList(0, MAX_IMPORT_CONTACTS)
        } else {
            parsed
        }
        var imported = 0
        var skippedDuplicates = 0
        var failed = (totalParsed - toProcess.size).coerceAtLeast(0)

        for (contact in toProcess) {
            if (isDuplicateContact(contact, dedupeIndex)) {
                skippedDuplicates++
                continue
            }

            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )
            if (contact.displayName.isNotBlank()) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, contact.displayName)
                        .build()
                )
            }
            contact.phones.forEach { phone ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build()
                )
            }
            contact.emails.forEach { email ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                        .build()
                )
            }

            try {
                context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                imported++
                registerContactInIndex(contact, dedupeIndex)
            } catch (se: SecurityException) {
                Log.w(TAG, "Contacts write denied: ${se.javaClass.simpleName}")
                return@withContext ContactsImportResult(
                    imported = imported,
                    skippedDuplicates = skippedDuplicates,
                    failed = totalParsed - imported - skippedDuplicates,
                    error = ContactsImportError.PERMISSION_DENIED
                )
            } catch (e: Exception) {
                failed++
                Log.w(TAG, "Contact insert failed: ${e.javaClass.simpleName}")
            }
        }

        ContactsImportResult(
            imported = imported,
            skippedDuplicates = skippedDuplicates,
            failed = failed,
            error = null
        )
    }

    private fun loadExistingContactIndex(): ContactDedupeIndex {
        val index = ContactDedupeIndex()

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            ),
            null,
            null,
            null
        )?.use { cursor ->
            val numCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val nameCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val rawNum = if (numCol >= 0) cursor.getString(numCol) else null
                val rawName = if (nameCol >= 0) cursor.getString(nameCol) else null
                val normPhone = rawNum?.let { normalizePhone(it) }.orEmpty()
                val normName = rawName?.let { normalizeName(it) }.orEmpty()
                if (normPhone.isNotEmpty()) {
                    index.phoneNameKeys.add("$normPhone|$normName")
                }
                if (normName.isNotEmpty()) {
                    index.names.add(normName)
                }
            }
        }

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Email.ADDRESS,
                ContactsContract.CommonDataKinds.Email.DISPLAY_NAME
            ),
            null,
            null,
            null
        )?.use { cursor ->
            val emailCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
            val nameCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val rawEmail = if (emailCol >= 0) cursor.getString(emailCol) else null
                val rawName = if (nameCol >= 0) cursor.getString(nameCol) else null
                val normEmail = rawEmail?.let { normalizeEmail(it) }.orEmpty()
                val normName = rawName?.let { normalizeName(it) }.orEmpty()
                if (normEmail.isNotEmpty()) {
                    index.emailNameKeys.add("$normEmail|$normName")
                }
                if (normName.isNotEmpty()) {
                    index.names.add(normName)
                }
            }
        }

        context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
            null,
            null,
            null
        )?.use { cursor ->
            val nameCol = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
            while (cursor.moveToNext()) {
                if (nameCol >= 0) {
                    cursor.getString(nameCol)?.let { raw ->
                        val norm = normalizeName(raw)
                        if (norm.isNotEmpty()) index.names.add(norm)
                    }
                }
            }
        }

        return index
    }
}
