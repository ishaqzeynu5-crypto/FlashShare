# FlashShare — Offline Android File Sharing App

**FlashShare** (`com.flashshare.app`) is a production-ready, 100% offline Android file-sharing application built with **Kotlin**, **Jetpack Compose (Material 3)**, **MVVM + Coroutines/Flow**, **Hilt**, and **Room**. It has zero ads, zero analytics, zero tracking, and zero Google Play Services dependencies.

---

## Key Features

1. **Offline High-Speed Transfer (No Internet)** — Connects two phones via **Wi-Fi Direct** (`WifiP2pManager`) or a local Wi-Fi / Hotspot network and streams files over TCP sockets using a framed 64-bit binary protocol (`TransferProtocol`) with 256 KB buffers.
2. **QR Code & Nearby Discovery** — Connect by scanning the receiver's QR code (offline CameraX + ZXing `MultiFormatReader`) or tapping a discovered nearby peer on the animated radar screen.
3. **Animated Send / Receive Radar** — Live concentric radar sweep animation with peer discovery, QR display, manual IP fallback, and connection status.
4. **6-Tab File Browser** — Browse **Apps (APK)**, **Photos**, **Videos**, **Music**, **Documents**, and **Downloads** with search, photo/video thumbnails (Coil + `VideoFrameDecoder`), app icons, and multi-select.
5. **Transfer Queue & Foreground Service** — Live per-file progress bar, speed (`MB/s`), estimated remaining time (ETA), pause/resume (byte-offset resume negotiation), cancel, and ongoing notification progress with `WakeLock`.
6. **Phone Clone** — Export Contacts to vCard 3.0 (`.vcf`) and transfer Contacts, Photos, Videos, and Music in one batch, with one-tap contact import on the new phone.
7. **Share via Browser** — Built-in pure-Kotlin HTTP/1.1 local web server (`LocalWebServer`) with responsive HTML5 download page, QR link, and HTTP `Range` support for >4 GB downloads from any browser.
8. **Transfer History (Room)** — Persistent transfer log with **Open** (`FileProvider`), **Resend**, and **Delete** actions.
9. **Auto-Organized Dedicated Folder** — Received files are saved under `Downloads/FlashShare/` (or app external `FlashShare/` fallback) and automatically organized into `Apps/`, `Photos/`, `Videos/`, `Music/`, `Documents/`, `Contacts/`, and `Other/`.
10. **Quality & Resilience** — Runtime permission rationale dialogs (API 24–34), Dark/Light/System Material 3 theme, full **English** + **Amharic (አማርኛ)** localization, low-storage pre-checks (`StatFs`), disconnection recovery, and >4 GB 64-bit file streaming (`RandomAccessFile`).

---

## Architecture

FlashShare follows clean **MVVM + Unidirectional Data Flow**:

```text
FlashShare/
├── .github/workflows/build.yml        # GitHub Actions CI for Debug & Release APKs
├── settings.gradle.kts                # Project & repository configuration
├── build.gradle.kts                   # Root plugin versions (AGP 8.5.2, Kotlin 2.0.21, Hilt 2.52, KSP)
├── gradle.properties                  # JVM & AndroidX flags
├── keystore.properties.example        # Template for release APK signing
├── gradle/wrapper/
│   └── gradle-wrapper.properties      # Gradle 8.7 distribution config
└── app/
    ├── build.gradle.kts               # App module (minSdk 24, targetSdk 34, Compose BOM, Hilt, Room, CameraX, ZXing)
    ├── proguard-rules.pro             # R8/ProGuard keep rules for Room, Hilt, ZXing, Coroutines
    └── src/main/
        ├── AndroidManifest.xml        # Scoped permissions, FileProvider, ForegroundService, LocaleConfig
        ├── res/
        │   ├── values/strings.xml     # English strings
        │   ├── values-am/strings.xml  # Amharic (አማርኛ) strings
        │   ├── values/colors.xml      # Launcher background color
        │   ├── values/themes.xml      # AppCompat DayNight NoActionBar theme
        │   ├── xml/file_paths.xml     # FileProvider paths
        │   ├── xml/locales_config.xml # Per-app language config (en, am)
        │   └── mipmap-anydpi-v26/     # Adaptive launcher icon
        └── java/com/flashshare/app/
            ├── FlashShareApp.kt                   # @HiltAndroidApp + Coil VideoFrameDecoder
            ├── MainActivity.kt                    # @AndroidEntryPoint + Compose host
            ├── di/AppModule.kt                    # Hilt Room DB & DAO providers
            ├── domain/model/Models.kt             # FileCategory, ShareableFile, TransferItem, QrConnectionPayload
            ├── util/Formatters.kt                 # 64-bit byte formatting, ETA, MIME, local IPv4 lookup
            ├── data/
            │   ├── local/
            │   │   ├── TransferHistoryEntity.kt   # Room @Entity
            │   │   ├── TransferHistoryDao.kt      # Room @Dao
            │   │   ├── FlashShareDatabase.kt      # Room @Database
            │   │   └── UserPreferences.kt         # DataStore (theme, language, device name)
            │   ├── storage/StorageOrganizer.kt    # Dedicated FlashShare/<Type> folders, StatFs space check, FileProvider
            │   └── repository/
            │       ├── FileBrowserRepository.kt   # MediaStore + PackageManager 6-tab scanner
            │       ├── ContactsRepository.kt      # vCard 3.0 (.vcf) export & ContactsContract import
            │       └── TransferHistoryRepository.kt
            ├── network/WifiDirectManager.kt       # WifiP2pManager peer discovery, group host, IP fallback
            ├── transfer/
            │   ├── TransferProtocol.kt            # Framed 64-bit binary protocol + resume ACK
            │   └── TransferManager.kt             # TCP server/client, pause/resume/cancel, speed/ETA
            ├── service/TransferForegroundService.kt # Foreground dataSync service + live progress notification
            ├── qr/
            │   ├── QrCodeGenerator.kt             # Offline ZXing QR bitmap generator
            │   └── QrScannerView.kt               # Offline CameraX + ZXing QR scanner Composable
            ├── webserver/LocalWebServer.kt        # Pure-Kotlin HTTP/1.1 server with Range streaming
            └── ui/
                ├── theme/Theme.kt                 # Material 3 Light/Dark color schemes
                ├── permissions/PermissionHelper.kt # API 24-34 permission sets + rationale dialog
                ├── components/RadarView.kt        # Animated pulsing radar Canvas
                ├── viewmodel/MainViewModel.kt     # Hilt ViewModel coordinating all flows
                ├── navigation/FlashShareAppRoot.kt # Bottom bar + NavHost
                └── screens/
                    ├── HomeScreen.kt
                    ├── SendReceiveScreens.kt
                    ├── FileBrowserScreen.kt
                    ├── TransferQueueScreen.kt
                    ├── PhoneCloneScreen.kt
                    ├── WebShareScreen.kt
                    └── HistoryAndSettingsScreens.kt
```

---

## Step-by-Step Build Instructions

### Prerequisites (Local Machine)
- **JDK 17** (e.g., Eclipse Temurin 17)
- **Android SDK** with Platform 34 (`compileSdk = 34`) and Build-Tools 34.0.0
- **Gradle 8.7** (or Android Studio Ladybug / Koala+)

### 1. Build the Debug APK
1. Extract `FlashShare-Android.zip` and open the `FlashShare/` folder in Android Studio (or open a terminal inside `FlashShare/`).
2. Run:
   ```bash
   gradle assembleDebug
   ```
   *(If you have generated the Gradle wrapper locally via `gradle wrapper`, run `./gradlew assembleDebug`.)*
3. Locate the Debug APK at:
   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```

### 2. Generate a Release Keystore
Create a signing keystore (keep this file and its passwords private — never commit it to Git):
```bash
keytool -genkeypair -v \
  -keystore flashshare-release.jks \
  -alias flashshare \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

### 3. Configure Signing & Build the Signed Release APK
1. Copy `keystore.properties.example` to `keystore.properties` in the project root:
   ```properties
   storeFile=../flashshare-release.jks
   storePassword=YOUR_STORE_PASSWORD
   keyAlias=flashshare
   keyPassword=YOUR_KEY_PASSWORD
   ```
   *(Alternatively, export `FLASHSHARE_KEYSTORE_FILE`, `FLASHSHARE_STORE_PASSWORD`, `FLASHSHARE_KEY_ALIAS`, and `FLASHSHARE_KEY_PASSWORD` as environment variables.)*
2. Run:
   ```bash
   gradle assembleRelease
   ```
3. Locate the signed, R8-minified Release APK at:
   ```text
   app/build/outputs/apk/release/app-release.apk
   ```

### 4. Build Automatically via GitHub Actions (No PC Required)
1. Upload the `FlashShare/` contents to a new GitHub repository.
2. Open the **Actions** tab → **Build FlashShare APK** → **Run workflow**.
3. Download `FlashShare-debug-apk` or `FlashShare-release-apk` from the workflow **Artifacts** section.
4. For signed release builds on GitHub Actions, store your base64-encoded keystore and passwords in **Repository Secrets** (`FLASHSHARE_STORE_PASSWORD`, `FLASHSHARE_KEY_ALIAS`, `FLASHSHARE_KEY_PASSWORD`) and decode the keystore into `FLASHSHARE_KEYSTORE_FILE` before `gradle assembleRelease`.
