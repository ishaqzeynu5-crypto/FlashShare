package com.flashshare.app.transfer

import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Framed TCP transfer protocol supporting:
 * - Version 1 (legacy single-file framing, kept for backward compatibility)
 * - Version 2 (persistent batch connection reuse, parallel byte-range streams for large files,
 *   512 KB–1 MB buffers, CRC32 integrity verification, and optional AES-256-GCM encryption).
 */
object TransferProtocol {
    const val DEFAULT_PORT: Int = 8988
    const val MAX_PORT_FALLBACK: Int = 8998
    const val MAGIC: Int = 0x46534831 // "FSH1"
    const val PROTOCOL_VERSION_V1: Int = 1
    const val PROTOCOL_VERSION_V2: Int = 2

    const val BUFFER_SIZE: Int = 512 * 1024        // 512 KB transfer chunk buffer
    const val SOCKET_BUFFER_SIZE: Int = 1024 * 1024 // 1 MB TCP SO_SNDBUF / SO_RCVBUF
    const val LARGE_FILE_PARALLEL_THRESHOLD: Long = 32L * 1024L * 1024L // 32 MB
    const val PARALLEL_STREAMS_DEFAULT: Int = 3

    // V2 Session Flags
    const val FLAG_ENCRYPTED: Int = 0x01
    const val FLAG_BATCH: Int = 0x02
    const val FLAG_CHUNKED_RANGE: Int = 0x04

    // Response codes
    const val RESPONSE_OK: Byte = 1
    const val RESPONSE_LOW_STORAGE: Byte = 2
    const val RESPONSE_REJECTED: Byte = 3

    // Integrity verification codes
    const val VERIFY_OK: Byte = 10
    const val VERIFY_CRC_MISMATCH: Byte = 11

    // V1 Legacy header
    data class FileHeader(
        val transferId: String,
        val fileName: String,
        val mimeType: String,
        val categoryName: String,
        val senderName: String,
        val totalSizeBytes: Long
    )

    data class ReceiverAck(
        val status: Byte,
        val offsetOrAvailableBytes: Long
    )

    // V2 Batch session header (sent once per reused TCP connection)
    data class BatchHeaderV2(
        val flags: Int,
        val batchId: String,
        val senderId: String,
        val senderName: String,
        val totalFilesInBatch: Int,
        val streamFileCount: Int,
        val totalBatchBytes: Long
    ) {
        val isEncrypted: Boolean get() = (flags and FLAG_ENCRYPTED) != 0
        val isChunkedRange: Boolean get() = (flags and FLAG_CHUNKED_RANGE) != 0
    }

    // V2 Per-file (or per-range) header sent sequentially over the reused TCP socket
    data class FileHeaderV2(
        val transferId: String,
        val fileName: String,
        val mimeType: String,
        val categoryName: String,
        val totalSizeBytes: Long,
        val rangeStart: Long,
        val rangeLength: Long,
        val baseIv: ByteArray = ByteArray(0)
    )

    fun readPreambleVersion(input: DataInputStream): Int {
        val magic = input.readInt()
        if (magic != MAGIC) {
            throw IllegalStateException("Invalid FlashShare protocol header")
        }
        return input.readInt()
    }

    // ---- V1 helpers (backward compatibility) ----
    fun readHeaderV1Body(input: DataInputStream): FileHeader {
        val transferId = input.readUTF()
        val fileName = input.readUTF()
        val mimeType = input.readUTF()
        val categoryName = input.readUTF()
        val senderName = input.readUTF()
        val totalSize = input.readLong()
        return FileHeader(
            transferId = transferId,
            fileName = fileName,
            mimeType = mimeType,
            categoryName = categoryName,
            senderName = senderName,
            totalSizeBytes = totalSize
        )
    }

    fun writeAck(out: DataOutputStream, status: Byte, offsetOrAvailableBytes: Long) {
        out.writeByte(status.toInt())
        out.writeLong(offsetOrAvailableBytes)
        out.flush()
    }

    fun readAck(input: DataInputStream): ReceiverAck {
        val status = input.readByte()
        val value = input.readLong()
        return ReceiverAck(status = status, offsetOrAvailableBytes = value)
    }

    // ---- V2 helpers ----
    fun writeBatchHeaderV2(out: DataOutputStream, header: BatchHeaderV2) {
        out.writeInt(MAGIC)
        out.writeInt(PROTOCOL_VERSION_V2)
        out.writeByte(header.flags)
        out.writeUTF(header.batchId)
        out.writeUTF(header.senderId)
        out.writeUTF(header.senderName)
        out.writeInt(header.totalFilesInBatch)
        out.writeInt(header.streamFileCount)
        out.writeLong(header.totalBatchBytes)
        out.flush()
    }

    fun readBatchHeaderV2Body(input: DataInputStream): BatchHeaderV2 {
        val flags = input.readByte().toInt() and 0xFF
        val batchId = input.readUTF()
        val senderId = input.readUTF()
        val senderName = input.readUTF()
        val totalFiles = input.readInt()
        val streamFiles = input.readInt()
        val totalBytes = input.readLong()
        return BatchHeaderV2(
            flags = flags,
            batchId = batchId,
            senderId = senderId,
            senderName = senderName,
            totalFilesInBatch = totalFiles,
            streamFileCount = streamFiles,
            totalBatchBytes = totalBytes
        )
    }

    fun writeFileHeaderV2(out: DataOutputStream, header: FileHeaderV2) {
        out.writeUTF(header.transferId)
        out.writeUTF(header.fileName)
        out.writeUTF(header.mimeType)
        out.writeUTF(header.categoryName)
        out.writeLong(header.totalSizeBytes)
        out.writeLong(header.rangeStart)
        out.writeLong(header.rangeLength)
        out.writeByte(header.baseIv.size)
        if (header.baseIv.isNotEmpty()) {
            out.write(header.baseIv)
        }
        out.flush()
    }

    fun readFileHeaderV2(input: DataInputStream): FileHeaderV2 {
        val transferId = input.readUTF()
        val fileName = input.readUTF()
        val mimeType = input.readUTF()
        val categoryName = input.readUTF()
        val totalSize = input.readLong()
        val rangeStart = input.readLong()
        val rangeLength = input.readLong()
        val ivLen = input.readByte().toInt() and 0xFF
        val iv = if (ivLen > 0) ByteArray(ivLen).also { input.readFully(it) } else ByteArray(0)
        return FileHeaderV2(
            transferId = transferId,
            fileName = fileName,
            mimeType = mimeType,
            categoryName = categoryName,
            totalSizeBytes = totalSize,
            rangeStart = rangeStart,
            rangeLength = rangeLength,
            baseIv = iv
        )
    }
}
