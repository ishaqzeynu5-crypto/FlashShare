package com.flashshare.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [TransferHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class FlashShareDatabase : RoomDatabase() {
    abstract fun transferHistoryDao(): TransferHistoryDao
}
