package com.flashshare.app.webserver

import android.content.Context
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

data class WebServerState(
    val isRunning: Boolean = false,
    val url: String = "",
    val sharedFiles: List<ShareableFile> = emptyList(),
    val error: String? = null
)

/**
 * Pure-Kotlin local HTTP/1.1 server for Share via Browser.
 * Supports >4 GB streaming, HTTP Range resume requests, and zero external dependencies.
 */
@Singleton
class LocalWebServer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow(WebServerState())
    val state: StateFlow<WebServerState> = _state.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    fun setSharedFiles(files: List<ShareableFile>) {
        _state.value = _state.value.copy(sharedFiles = files)
    }

    fun start(preferredPort: Int = 8080) {
        if (_state.value.isRunning) return
        serverJob = scope.launch {
            val ip = Formatters.getLocalIpAddress() ?: "127.0.0.1"
            var boundSocket: ServerSocket? = null
            var boundPort = preferredPort

            for (port in preferredPort..(preferredPort + 10)) {
                try {
                    boundSocket = ServerSocket().apply {
                        reuseAddress = true
                        bind(InetSocketAddress(port))
                    }
                    boundPort = port
                    break
                } catch (_: Exception) {
                    // Try next port
                }
            }

            if (boundSocket == null) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    error = "Could not bind local port $preferredPort"
                )
                return@launch
            }

            serverSocket = boundSocket
            val url = "http://$ip:$boundPort"
            _state.value = _state.value.copy(isRunning = true, url = url, error = null)

            try {
                while (isActive && !boundSocket.isClosed) {
                    val client = try {
                        boundSocket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    launch { handleHttpClient(client) }
                }
            } finally {
                _state.value = _state.value.copy(isRunning = false)
            }
        }
    }

    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        _state.value = _state.value.copy(isRunning = false, url = "")
    }

    private fun handleHttpClient(socket: Socket) {
        try {
            socket.soTimeout = 30_000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val path = parts[1].substringBefore("?")

            val headers = mutableMapOf<String, String>()
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) break
                val idx = line.indexOf(':')
                if (idx > 0) {
                    headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
                }
            }

            val out = BufferedOutputStream(socket.getOutputStream(), 128 * 1024)

            if (method != "GET" && method != "HEAD") {
                sendSimpleResponse(out, 405, "Method Not Allowed", "text/plain", "Method Not Allowed")
                return
            }

            when {
                path == "/" || path == "/index.html" -> {
                    val html = buildIndexHtml(_state.value.sharedFiles)
                    sendSimpleResponse(out, 200, "OK", "text/html; charset=utf-8", html)
                }
                path.startsWith("/download/") -> {
                    val index = path.removePrefix("/download/").toIntOrNull()
                    val files = _state.value.sharedFiles
                    if (index == null || index !in files.indices) {
                        sendSimpleResponse(out, 404, "Not Found", "text/plain", "File not found")
                    } else {
                        streamFileResponse(out, files[index], headers["range"], method == "HEAD")
                    }
                }
                else -> {
                    sendSimpleResponse(out, 404, "Not Found", "text/plain", "Not Found")
                }
            }
        } catch (_: Exception) {
            // Client closed connection early
        } finally {
            runCatching { socket.close() }
        }
    }

    private fun sendSimpleResponse(
        out: BufferedOutputStream,
        code: Int,
        reason: String,
        contentType: String,
        body: String
    ) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val header = buildString {
            append("HTTP/1.1 $code $reason\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(bytes)
        out.flush()
    }

    private fun streamFileResponse(
        out: BufferedOutputStream,
        file: ShareableFile,
        rangeHeader: String?,
        headOnly: Boolean
    ) {
        val totalSize = file.sizeBytes
        var start = 0L
        var end = (totalSize - 1L).coerceAtLeast(0L)
        var isPartial = false

        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(",")
            val bounds = rangeSpec.split("-")
            val parsedStart = bounds.getOrNull(0)?.toLongOrNull()
            val parsedEnd = bounds.getOrNull(1)?.toLongOrNull()
            if (parsedStart != null && parsedStart in 0L until totalSize) {
                start = parsedStart
                end = (parsedEnd ?: (totalSize - 1L)).coerceIn(start, totalSize - 1L)
                isPartial = true
            }
        }

        val contentLength = (end - start + 1L).coerceAtLeast(0L)
        val encodedName = URLEncoder.encode(file.name, "UTF-8").replace("+", "%20")
        val statusLine = if (isPartial) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"

        val headers = buildString {
            append("$statusLine\r\n")
            append("Content-Type: ${file.mimeType}\r\n")
            append("Content-Length: $contentLength\r\n")
            append("Accept-Ranges: bytes\r\n")
            if (isPartial) {
                append("Content-Range: bytes $start-$end/$totalSize\r\n")
            }
            append("Content-Disposition: attachment; filename*=UTF-8''$encodedName\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(headers.toByteArray(Charsets.US_ASCII))
        out.flush()

        if (headOnly) return

        val stream = if (!file.filePath.isNullOrBlank() && File(file.filePath).canRead()) {
            FileInputStream(File(file.filePath))
        } else {
            context.contentResolver.openInputStream(file.uri)
        } ?: return

        stream.use { input ->
            if (start > 0L) {
                var toSkip = start
                val discard = ByteArray(64 * 1024)
                while (toSkip > 0L) {
                    val skipped = input.skip(toSkip)
                    if (skipped > 0L) {
                        toSkip -= skipped
                    } else {
                        val read = input.read(discard, 0, minOf(discard.size.toLong(), toSkip).toInt())
                        if (read == -1) break
                        toSkip -= read
                    }
                }
            }

            val buffer = ByteArray(128 * 1024)
            var remaining = contentLength
            while (remaining > 0L) {
                val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read == -1) break
                out.write(buffer, 0, read)
                remaining -= read
            }
            out.flush()
        }
    }

    private fun buildIndexHtml(files: List<ShareableFile>): String {
        val itemsHtml = if (files.isEmpty()) {
            "<p class='empty'>No files selected yet on the host phone.</p>"
        } else {
            files.mapIndexed { index, file ->
                val safeName = escapeHtml(file.name)
                val sizeStr = Formatters.formatBytes(file.sizeBytes)
                val catStr = file.category.folderName
                """
                <div class="card">
                    <div class="info">
                        <div class="name">$safeName</div>
                        <div class="meta">$catStr &bull; $sizeStr</div>
                    </div>
                    <a class="btn" href="/download/$index">Download</a>
                </div>
                """.trimIndent()
            }.joinToString("\n")
        }

        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>FlashShare — Browser Download</title>
                <style>
                    :root { color-scheme: light dark; }
                    body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 20px; background: #0f172a; color: #f8fafc; }
                    .container { max-width: 720px; margin: 0 auto; }
                    header { margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #1e293b; }
                    h1 { margin: 0 0 6px; font-size: 1.5rem; color: #2dd4bf; }
                    p.sub { margin: 0; color: #94a3b8; font-size: 0.92rem; }
                    .card { display: flex; align-items: center; justify-content: space-between; gap: 12px; background: #1e293b; padding: 14px 16px; border-radius: 12px; margin-bottom: 12px; }
                    .info { min-width: 0; flex: 1; }
                    .name { font-weight: 600; word-break: break-word; margin-bottom: 4px; }
                    .meta { font-size: 0.82rem; color: #94a3b8; }
                    .btn { display: inline-block; background: #0d9488; color: #ffffff; text-decoration: none; padding: 10px 16px; border-radius: 8px; font-weight: 600; white-space: nowrap; }
                    .btn:hover { background: #14b8a6; }
                    .empty { text-align: center; color: #94a3b8; padding: 40px 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <header>
                        <h1>FlashShare</h1>
                        <p class="sub">Offline local file transfer &bull; ${files.size} file(s) available</p>
                    </header>
                    $itemsHtml
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    private fun escapeHtml(text: String): String =
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
}
