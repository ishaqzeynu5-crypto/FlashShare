package com.flashshare.app.data.repository

import android.content.ContentProviderOperation
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContactsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    suspend fun getContactCount(): Int = withContext(Dispatchers.IO) {
        var count = 0
        runCatching {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID),
                null,
                null,
                null
            )?.use { cursor ->
                count = cursor.count
            }
        }
        count
    }

    /**
     * Exports all contacts to a standard vCard 3.0 (.vcf) file for Phone Clone transfer.
     */
    suspend fun exportContactsToVcf(): ShareableFile? = withContext(Dispatchers.IO) {
        val vcfBuilder = StringBuilder()
        var exportedCount = 0

        val contactsMap = linkedMapOf<String, Pair<String, MutableList<String>>>()
        val emailMap = mutableMapOf<String, MutableList<String>>()

        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol) ?: continue
                    val name = cursor.getString(nameCol)?.trim().orEmpty().ifBlank { "Unnamed" }
                    val number = cursor.getString(numCol)?.trim().orEmpty()
                    if (number.isBlank()) continue
                    val entry = contactsMap.getOrPut(contactId) { name to mutableListOf() }
                    if (number !in entry.second) {
                        entry.second.add(number)
                    }
                }
            }

            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Email.ADDRESS
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
                val emailCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol) ?: continue
                    val email = cursor.getString(emailCol)?.trim().orEmpty()
                    if (email.isNotBlank()) {
                        emailMap.getOrPut(contactId) { mutableListOf() }.add(email)
                    }
                }
            }
        }

        for ((contactId, pair) in contactsMap) {
            val (name, phones) = pair
            val emails = emailMap[contactId].orEmpty()
            vcfBuilder.appendLine("BEGIN:VCARD")
            vcfBuilder.appendLine("VERSION:3.0")
            vcfBuilder.appendLine("FN:${escapeVcard(name)}")
            phones.forEach { phone ->
                vcfBuilder.appendLine("TEL;TYPE=CELL:$phone")
            }
            emails.forEach { email ->
                vcfBuilder.appendLine("EMAIL:$email")
            }
            vcfBuilder.appendLine("END:VCARD")
            exportedCount++
        }

        if (exportedCount == 0) return@withContext null

        val exportDir = File(context.cacheDir, "phone_clone").apply { mkdirs() }
        val vcfFile = File(exportDir, "FlashShare_Contacts_${System.currentTimeMillis()}.vcf")
        vcfFile.writeText(vcfBuilder.toString(), Charsets.UTF_8)

        ShareableFile(
            id = "contacts_vcf_${vcfFile.name}",
            name = vcfFile.name,
            sizeBytes = vcfFile.length(),
            mimeType = "text/vcard",
            category = FileCategory.CONTACTS,
            uri = Uri.fromFile(vcfFile),
            filePath = vcfFile.absolutePath,
            lastModified = vcfFile.lastModified()
        )
    }

    /**
     * Imports a received vCard (.vcf) file into the Android Contacts provider.
     * Returns the number of contacts imported.
     */
    suspend fun importContactsFromVcf(vcfFile: File): Int = withContext(Dispatchers.IO) {
        if (!vcfFile.exists()) return@withContext 0
        var imported = 0
        var currentName = ""
        val currentPhones = mutableListOf<String>()
        val currentEmails = mutableListOf<String>()

        fun flushContact() {
            if (currentName.isBlank() && currentPhones.isEmpty()) return
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )
            if (currentName.isNotBlank()) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                            currentName
                        )
                        .build()
                )
            }
            currentPhones.forEach { phone ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        .build()
                )
            }
            currentEmails.forEach { email ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                        .build()
                )
            }
            runCatching {
                context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                imported++
            }
        }

        vcfFile.forEachLine(Charsets.UTF_8) { rawLine ->
            val line = rawLine.trim()
            when {
                line.equals("BEGIN:VCARD", ignoreCase = true) -> {
                    currentName = ""
                    currentPhones.clear()
                    currentEmails.clear()
                }
                line.startsWith("FN:", ignoreCase = true) -> {
                    currentName = unescapeVcard(line.substringAfter(":").trim())
                }
                line.startsWith("TEL", ignoreCase = true) && line.contains(":") -> {
                    val phone = line.substringAfter(":").trim()
                    if (phone.isNotBlank()) currentPhones.add(phone)
                }
                line.startsWith("EMAIL", ignoreCase = true) && line.contains(":") -> {
                    val email = line.substringAfter(":").trim()
                    if (email.isNotBlank()) currentEmails.add(email)
                }
                line.equals("END:VCARD", ignoreCase = true) -> {
                    flushContact()
                }
            }
        }
        imported
    }

    private fun escapeVcard(value: String): String =
        value.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;")

    private fun unescapeVcard(value: String): String =
        value.replace("\\;", ";").replace("\\,", ",").replace("\\\\", "\\")
}
