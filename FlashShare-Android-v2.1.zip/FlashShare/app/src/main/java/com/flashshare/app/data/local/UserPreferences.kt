package com.flashshare.app.data.local

import android.content.Context
import android.os.Build
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.flashshare.app.domain.model.AppLanguage
import com.flashshare.app.domain.model.AppThemeMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "flashshare_prefs")

@Singleton
class UserPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val DEVICE_NAME = stringPreferencesKey("device_name")
        val DEVICE_ID = stringPreferencesKey("device_id")
        val TRUSTED_DEVICES = stringSetPreferencesKey("trusted_devices")
        val ENCRYPTION_ENABLED = booleanPreferencesKey("encryption_enabled")
    }

    val themeMode: Flow<AppThemeMode> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.THEME_MODE] ?: AppThemeMode.SYSTEM.name
        runCatching { AppThemeMode.valueOf(raw) }.getOrDefault(AppThemeMode.SYSTEM)
    }

    val language: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.LANGUAGE] ?: AppLanguage.ENGLISH.name
        runCatching { AppLanguage.valueOf(raw) }.getOrDefault(AppLanguage.ENGLISH)
    }

    val deviceName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.DEVICE_NAME]?.takeIf { it.isNotBlank() } ?: defaultDeviceName()
    }

    val trustedDevices: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[Keys.TRUSTED_DEVICES] ?: emptySet()
    }

    val encryptionEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.ENCRYPTION_ENABLED] ?: true
    }

    suspend fun getOrCreateDeviceId(): String {
        val existing = context.dataStore.data.map { it[Keys.DEVICE_ID] }.first()
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString()
        context.dataStore.edit { it[Keys.DEVICE_ID] = created }
        return created
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setLanguage(lang: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = lang.name }
    }

    suspend fun setDeviceName(name: String) {
        context.dataStore.edit { it[Keys.DEVICE_NAME] = name.trim().ifBlank { defaultDeviceName() } }
    }

    suspend fun setEncryptionEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ENCRYPTION_ENABLED] = enabled }
    }

    suspend fun addTrustedDevice(senderId: String) {
        if (senderId.isBlank()) return
        context.dataStore.edit { prefs ->
            val updated = (prefs[Keys.TRUSTED_DEVICES] ?: emptySet()) + senderId
            prefs[Keys.TRUSTED_DEVICES] = updated
        }
    }

    suspend fun clearTrustedDevices() {
        context.dataStore.edit { it[Keys.TRUSTED_DEVICES] = emptySet() }
    }

    fun defaultDeviceName(): String {
        val model = Build.MODEL?.trim().orEmpty()
        val manufacturer = Build.MANUFACTURER?.trim().orEmpty()
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model".trim().ifBlank { "Android Device" }
        }
    }
}
