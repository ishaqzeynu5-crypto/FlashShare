package com.flashshare.app.transfer

import android.util.Base64
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Chunked AES-256-GCM encryption helper.
 * Derives a unique 12-byte nonce per chunk (baseIv XOR chunkIndex) so >4 GB files
 * stream with constant memory and per-chunk authentication.
 */
object CryptoHelper {
    private const val AES_KEY_BYTES = 32
    const val BASE_IV_BYTES = 12
    private const val GCM_TAG_BITS = 128
    private val secureRandom = SecureRandom()

    fun generateKeyBase64(): String {
        val key = ByteArray(AES_KEY_BYTES)
        secureRandom.nextBytes(key)
        return Base64.encodeToString(key, Base64.URL_SAFE or Base64.NO_WRAP)
    }

    fun decodeKey(base64: String?): SecretKey? {
        if (base64.isNullOrBlank()) return null
        return runCatching {
            val bytes = Base64.decode(base64, Base64.URL_SAFE or Base64.NO_WRAP)
            if (bytes.size != AES_KEY_BYTES) null else SecretKeySpec(bytes, "AES")
        }.getOrNull()
    }

    fun generateBaseIv(): ByteArray = ByteArray(BASE_IV_BYTES).also { secureRandom.nextBytes(it) }

    fun encryptChunk(
        key: SecretKey,
        baseIv: ByteArray,
        chunkIndex: Long,
        plain: ByteArray,
        length: Int
    ): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, deriveNonce(baseIv, chunkIndex)))
        return cipher.doFinal(plain, 0, length)
    }

    fun decryptChunk(
        key: SecretKey,
        baseIv: ByteArray,
        chunkIndex: Long,
        ciphertext: ByteArray
    ): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, deriveNonce(baseIv, chunkIndex)))
        return cipher.doFinal(ciphertext)
    }

    private fun deriveNonce(baseIv: ByteArray, chunkIndex: Long): ByteArray {
        val nonce = baseIv.copyOf(BASE_IV_BYTES)
        val idxBytes = ByteBuffer.allocate(8).putLong(chunkIndex).array()
        for (i in 0 until 8) {
            nonce[4 + i] = (nonce[4 + i].toInt() xor idxBytes[i].toInt()).toByte()
        }
        return nonce
    }
}
