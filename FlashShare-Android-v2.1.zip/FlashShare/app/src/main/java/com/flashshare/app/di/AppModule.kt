package com.flashshare.app.di

import android.content.Context
import androidx.room.Room
import com.flashshare.app.data.local.FlashShareDatabase
import com.flashshare.app.data.local.TransferHistoryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): FlashShareDatabase {
        return Room.databaseBuilder(
            context,
            FlashShareDatabase::class.java,
            "flashshare.db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun provideTransferHistoryDao(db: FlashShareDatabase): TransferHistoryDao {
        return db.transferHistoryDao()
    }
}
