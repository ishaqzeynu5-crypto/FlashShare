package com.flashshare.app.domain.model

import android.net.Uri
import java.util.UUID

enum class FileCategory(val folderName: String) {
    APPS("Apps"),
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    MUSIC("Music"),
    DOCUMENTS("Documents"),
    DOWNLOADS("Downloads"),
    CONTACTS("Contacts"),
    OTHER("Other")
}

data class ShareableFile(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val category: FileCategory,
    val uri: Uri,
    val filePath: String? = null,
    val packageName: String? = null,
    val lastModified: Long = 0L,
    val durationMs: Long = 0L
)

enum class TransferDirection {
    SEND,
    RECEIVE
}

enum class TransferStatus {
    QUEUED,
    RUNNING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class TransferItem(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val sizeBytes: Long,
    val transferredBytes: Long = 0L,
    val mimeType: String,
    val category: FileCategory,
    val direction: TransferDirection,
    val status: TransferStatus = TransferStatus.QUEUED,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val sourceUri: Uri? = null,
    val localPath: String? = null,
    val peerName: String = "",
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    val progressFraction: Float
        get() = if (sizeBytes <= 0L) 0f else (transferredBytes.toDouble() / sizeBytes.toDouble())
            .coerceIn(0.0, 1.0)
            .toFloat()

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}

data class IncomingTransferRequest(
    val batchId: String,
    val senderId: String,
    val senderName: String,
    val fileCount: Int,
    val totalBytes: Long
)

data class NearbyDevice(
    val deviceName: String,
    val deviceAddress: String,
    val isGroupOwner: Boolean = false,
    val ipAddress: String? = null,
    val port: Int = 8988
)

data class QrConnectionPayload(
    val deviceName: String,
    val ipAddress: String,
    val port: Int = 8988,
    val ssid: String? = null,
    val passphrase: String? = null,
    val encryptionKeyBase64: String? = null
) {
    fun encode(): String {
        val version = if (encryptionKeyBase64.isNullOrBlank()) "v1" else "v2"
        val parts = mutableListOf(
            "FLASHSHARE",
            version,
            Uri.encode(deviceName),
            Uri.encode(ipAddress),
            port.toString(),
            Uri.encode(ssid.orEmpty()),
            Uri.encode(passphrase.orEmpty()),
            Uri.encode(encryptionKeyBase64.orEmpty())
        )
        return parts.joinToString("|")
    }

    companion object {
        fun decode(raw: String): QrConnectionPayload? {
            val parts = raw.trim().split("|")
            if (parts.size < 5 || parts[0] != "FLASHSHARE") return null
            val name = Uri.decode(parts[2]).ifBlank { "FlashShare Device" }
            val ip = Uri.decode(parts[3])
            val port = parts[4].toIntOrNull() ?: return null
            if (ip.isBlank() || port !in 1024..65535) return null
            val ssid = parts.getOrNull(5)?.let { Uri.decode(it) }?.ifBlank { null }
            val pass = parts.getOrNull(6)?.let { Uri.decode(it) }?.ifBlank { null }
            val key = parts.getOrNull(7)?.let { Uri.decode(it) }?.ifBlank { null }
            return QrConnectionPayload(
                deviceName = name,
                ipAddress = ip,
                port = port,
                ssid = ssid,
                passphrase = pass,
                encryptionKeyBase64 = key
            )
        }
    }
}

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

enum class AppLanguage(val tag: String) {
    ENGLISH("en"),
    AMHARIC("am")
}

data class PhoneCloneSelection(
    val includeContacts: Boolean = true,
    val includePhotos: Boolean = true,
    val includeVideos: Boolean = true,
    val includeMusic: Boolean = true
)

data class PhoneCloneSummary(
    val contactCount: Int = 0,
    val photoCount: Int = 0,
    val photoBytes: Long = 0L,
    val videoCount: Int = 0,
    val videoBytes: Long = 0L,
    val musicCount: Int = 0,
    val musicBytes: Long = 0L
)
