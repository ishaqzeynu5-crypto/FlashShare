package com.flashshare.app.data.storage

import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.StatFs
import androidx.core.content.FileProvider
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageOrganizer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    /**
     * Dedicated root folder for all received files.
     * Uses public Downloads/FlashShare when writable, falling back to app-specific external FlashShare directory.
     */
    fun getRootReceiveDir(): File {
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val publicTarget = File(publicDownloads, "FlashShare")
        if (publicTarget.exists() && publicTarget.canWrite()) {
            return publicTarget
        }
        if (publicTarget.mkdirs() && publicTarget.canWrite()) {
            return publicTarget
        }
        val appExternal = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: context.filesDir
        return File(appExternal, "FlashShare").apply { mkdirs() }
    }

    fun getCategoryDir(category: FileCategory): File {
        val dir = File(getRootReceiveDir(), category.folderName)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun getDisplayStoragePath(): String = getRootReceiveDir().absolutePath

    /**
     * Checks available bytes on the volume hosting the receive directory.
     * Supports volumes and files larger than 4 GB via 64-bit StatFs.availableBytes.
     */
    fun getAvailableBytes(): Long {
        return try {
            val root = getRootReceiveDir()
            val stat = StatFs(root.absolutePath)
            stat.availableBytes
        } catch (_: Exception) {
            0L
        }
    }

    fun hasEnoughSpace(requiredBytes: Long, safetyMarginBytes: Long = 16L * 1024L * 1024L): Boolean {
        val available = getAvailableBytes()
        return available > requiredBytes + safetyMarginBytes
    }

    /**
     * Resolves a unique target file inside the dedicated category subfolder,
     * or returns the partial file if resuming an interrupted transfer.
     */
    fun resolveTargetFile(fileName: String, category: FileCategory, allowResumeExisting: Boolean): File {
        val safeName = sanitizeFileName(fileName)
        val dir = getCategoryDir(category)
        val exact = File(dir, safeName)
        if (allowResumeExisting && exact.exists()) {
            return exact
        }
        if (!exact.exists()) {
            return exact
        }
        val dotIndex = safeName.lastIndexOf('.')
        val base = if (dotIndex > 0) safeName.substring(0, dotIndex) else safeName
        val ext = if (dotIndex > 0) safeName.substring(dotIndex) else ""
        var counter = 1
        while (true) {
            val candidate = File(dir, "$base ($counter)$ext")
            if (!candidate.exists()) return candidate
            counter++
        }
    }

    fun scanReceivedFile(file: File, mimeType: String? = null) {
        val resolvedMime = mimeType ?: Formatters.inferMimeType(file.name)
        MediaScannerConnection.scanFile(
            context,
            arrayOf(file.absolutePath),
            arrayOf(resolvedMime),
            null
        )
    }

    fun buildOpenFileIntent(file: File, mimeType: String? = null): Intent? {
        if (!file.exists()) return null
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val resolvedMime = mimeType?.takeIf { it.isNotBlank() } ?: Formatters.inferMimeType(file.name)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, resolvedMime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun sanitizeFileName(raw: String): String {
        val clean = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return clean.ifBlank { "received_${System.currentTimeMillis()}" }
    }
}
