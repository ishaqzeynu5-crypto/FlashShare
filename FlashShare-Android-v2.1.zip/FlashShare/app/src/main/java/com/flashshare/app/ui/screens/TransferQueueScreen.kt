package com.flashshare.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferQueueScreen(viewModel: MainViewModel) {
    val transfers by viewModel.transfers.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(stringResource(R.string.transfers_title)) },
            actions = {
                if (transfers.any {
                        it.status == TransferStatus.COMPLETED ||
                            it.status == TransferStatus.FAILED ||
                            it.status == TransferStatus.CANCELLED
                    }
                ) {
                    TextButton(onClick = { viewModel.clearFinishedTransfers() }) {
                        Text(stringResource(R.string.transfer_clear_done))
                    }
                }
            }
        )

        if (transfers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.transfers_empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(transfers, key = { it.id }) { item ->
                    TransferItemCard(
                        item = item,
                        onPause = { viewModel.pauseTransfer(item.id) },
                        onResume = { viewModel.resumeTransfer(item.id) },
                        onCancel = { viewModel.cancelTransfer(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TransferItemCard(
    item: TransferItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit
) {
    val statusText = when (item.status) {
        TransferStatus.QUEUED -> stringResource(R.string.transfer_status_queued)
        TransferStatus.RUNNING -> stringResource(R.string.transfer_status_running)
        TransferStatus.PAUSED -> stringResource(R.string.transfer_status_paused)
        TransferStatus.COMPLETED -> stringResource(R.string.transfer_status_completed)
        TransferStatus.FAILED -> stringResource(R.string.transfer_status_failed)
        TransferStatus.CANCELLED -> stringResource(R.string.transfer_status_cancelled)
    }

    val statusColor = when (item.status) {
        TransferStatus.COMPLETED -> MaterialTheme.colorScheme.primary
        TransferStatus.FAILED -> MaterialTheme.colorScheme.error
        TransferStatus.PAUSED -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (item.direction == TransferDirection.SEND) {
                        AppIcons.Upload
                    } else {
                        AppIcons.Download
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${Formatters.formatBytes(item.transferredBytes)} / ${Formatters.formatBytes(item.sizeBytes)} • $statusText",
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor
                    )
                }

                when (item.status) {
                    TransferStatus.RUNNING, TransferStatus.QUEUED -> {
                        IconButton(onClick = onPause) {
                            Icon(
                                AppIcons.Pause,
                                contentDescription = stringResource(R.string.transfer_pause)
                            )
                        }
                        IconButton(onClick = onCancel) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = stringResource(R.string.transfer_cancel)
                            )
                        }
                    }
                    TransferStatus.PAUSED -> {
                        IconButton(onClick = onResume) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = stringResource(R.string.transfer_resume)
                            )
                        }
                        IconButton(onClick = onCancel) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = stringResource(R.string.transfer_cancel)
                            )
                        }
                    }
                    else -> Unit
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { item.progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${item.progressPercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Medium
                )
                if (item.status == TransferStatus.RUNNING) {
                    val speedStr = Formatters.formatBytes(item.speedBytesPerSec)
                    val etaStr = Formatters.formatDuration(item.etaSeconds)
                    Text(
                        text = stringResource(R.string.transfer_speed_eta, speedStr, etaStr),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (!item.errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
