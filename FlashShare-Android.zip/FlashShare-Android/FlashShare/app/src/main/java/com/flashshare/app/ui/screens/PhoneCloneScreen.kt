package com.flashshare.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.domain.model.PhoneCloneSelection
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.ui.permissions.PermissionRationaleDialog
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneCloneScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenSendRadar: () -> Unit,
    onOpenReceiveRadar: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val context = LocalContext.current
    val summary by viewModel.cloneSummary.collectAsState()
    val isPreparing by viewModel.isPreparingClone.collectAsState()
    val lastVcfPath by viewModel.lastReceivedVcfPath.collectAsState()

    var selection by remember { mutableStateOf(PhoneCloneSelection()) }
    var showContactsDialog by remember { mutableStateOf(false) }

    val clonePermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.loadPhoneCloneSummary()
    }

    LaunchedEffect(Unit) {
        val needed = (PermissionHelper.contactsPermissions() + PermissionHelper.mediaPermissions()).distinct().toTypedArray()
        if (PermissionHelper.hasAll(context, needed)) {
            viewModel.loadPhoneCloneSummary()
        } else {
            showContactsDialog = true
        }
    }

    if (showContactsDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_contacts_title),
            description = stringResource(R.string.perm_contacts_desc),
            onGrantClick = {
                showContactsDialog = false
                clonePermLauncher.launch(
                    (PermissionHelper.contactsPermissions() + PermissionHelper.mediaPermissions()).distinct().toTypedArray()
                )
            },
            onOpenSettingsClick = {
                showContactsDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = {
                showContactsDialog = false
                viewModel.loadPhoneCloneSummary()
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.clone_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = stringResource(R.string.clone_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // New Phone (Receive All) quick button
            OutlinedButton(
                onClick = onOpenReceiveRadar,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.clone_new_phone))
            }

            if (lastVcfPath != null) {
                Button(
                    onClick = {
                        viewModel.importReceivedContacts { count ->
                            viewModel.showMessage(context.getString(R.string.clone_contacts_imported, count))
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.clone_import_contacts))
                }
            }

            Text(
                text = stringResource(R.string.clone_old_phone),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            CloneCategoryRow(
                icon = Icons.Default.Contacts,
                title = stringResource(R.string.clone_contacts),
                subtitle = "${summary.contactCount} contacts (vCard .vcf)",
                checked = selection.includeContacts,
                onToggle = { selection = selection.copy(includeContacts = !selection.includeContacts) }
            )

            CloneCategoryRow(
                icon = Icons.Default.PhotoLibrary,
                title = stringResource(R.string.clone_photos),
                subtitle = stringResource(
                    R.string.clone_items_summary,
                    summary.photoCount,
                    Formatters.formatBytes(summary.photoBytes)
                ),
                checked = selection.includePhotos,
                onToggle = { selection = selection.copy(includePhotos = !selection.includePhotos) }
            )

            CloneCategoryRow(
                icon = Icons.Default.VideoLibrary,
                title = stringResource(R.string.clone_videos),
                subtitle = stringResource(
                    R.string.clone_items_summary,
                    summary.videoCount,
                    Formatters.formatBytes(summary.videoBytes)
                ),
                checked = selection.includeVideos,
                onToggle = { selection = selection.copy(includeVideos = !selection.includeVideos) }
            )

            CloneCategoryRow(
                icon = Icons.Default.MusicNote,
                title = stringResource(R.string.clone_music),
                subtitle = stringResource(
                    R.string.clone_items_summary,
                    summary.musicCount,
                    Formatters.formatBytes(summary.musicBytes)
                ),
                checked = selection.includeMusic,
                onToggle = { selection = selection.copy(includeMusic = !selection.includeMusic) }
            )

            if (isPreparing) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(stringResource(R.string.clone_preparing))
                }
            } else {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = {
                        viewModel.startPhoneCloneSend(selection) { sentImmediately ->
                            if (sentImmediately) {
                                onOpenTransfers()
                            } else {
                                onOpenSendRadar()
                            }
                        }
                    },
                    enabled = selection.includeContacts || selection.includePhotos ||
                        selection.includeVideos || selection.includeMusic,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.clone_start))
                }
            }
        }
    }
}

@Composable
private fun CloneCategoryRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
        }
    }
}
