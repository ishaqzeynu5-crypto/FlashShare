package com.flashshare.app.network

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Looper
import androidx.core.content.ContextCompat
import com.flashshare.app.domain.model.NearbyDevice
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

sealed class WifiDirectState {
    data object Idle : WifiDirectState()
    data object Discovering : WifiDirectState()
    data class HostingGroup(
        val ipAddress: String,
        val ssid: String? = null,
        val passphrase: String? = null
    ) : WifiDirectState()
    data class Connected(
        val peerName: String,
        val groupOwnerIp: String,
        val isGroupOwner: Boolean
    ) : WifiDirectState()
    data class Error(val message: String) : WifiDirectState()
}

@Singleton
class WifiDirectManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val manager: WifiP2pManager? =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null
    private var receiverRegistered = false

    private val _peers = MutableStateFlow<List<NearbyDevice>>(emptyList())
    val peers: StateFlow<List<NearbyDevice>> = _peers.asStateFlow()

    private val _state = MutableStateFlow<WifiDirectState>(WifiDirectState.Idle)
    val state: StateFlow<WifiDirectState> = _state.asStateFlow()

    private val _isWifiP2pEnabled = MutableStateFlow(true)
    val isWifiP2pEnabled: StateFlow<Boolean> = _isWifiP2pEnabled.asStateFlow()

    private var pendingPeerName: String = "Nearby Device"

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val stateVal = intent.getIntExtra(
                        WifiP2pManager.EXTRA_WIFI_STATE,
                        WifiP2pManager.WIFI_P2P_STATE_DISABLED
                    )
                    _isWifiP2pEnabled.value = (stateVal == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    if (hasNearbyPermission()) {
                        channel?.let { ch ->
                            manager?.requestPeers(ch) { peerList ->
                                val list = peerList.deviceList.map { device: WifiP2pDevice ->
                                    NearbyDevice(
                                        deviceName = device.deviceName.ifBlank { device.deviceAddress },
                                        deviceAddress = device.deviceAddress,
                                        isGroupOwner = device.isGroupOwner,
                                        port = TransferProtocol.DEFAULT_PORT
                                    )
                                }
                                _peers.value = list
                            }
                        }
                    }
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    requestConnectionInfo()
                }
            }
        }
    }

    fun initialize() {
        if (channel == null && manager != null) {
            channel = manager.initialize(context, Looper.getMainLooper(), null)
        }
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
            receiverRegistered = true
        }
    }

    fun hasNearbyPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.NEARBY_WIFI_DEVICES
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        initialize()
        if (!hasNearbyPermission()) {
            _state.value = WifiDirectState.Error("Nearby Wi-Fi permission required")
            return
        }
        val ch = channel ?: return
        _state.value = WifiDirectState.Discovering
        manager?.discoverPeers(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                _state.value = WifiDirectState.Discovering
            }

            override fun onFailure(reasonCode: Int) {
                _state.value = WifiDirectState.Error("Discovery unavailable (code $reasonCode). Use QR code or same Wi-Fi.")
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        val ch = channel ?: return
        manager?.stopPeerDiscovery(ch, null)
        if (_state.value is WifiDirectState.Discovering) {
            _state.value = WifiDirectState.Idle
        }
    }

    /**
     * Starts a Wi-Fi Direct group as receiver (Group Owner) so senders can connect directly
     * or via QR code without internet.
     */
    @SuppressLint("MissingPermission")
    fun startReceiverGroup() {
        initialize()
        val fallbackIp = Formatters.getLocalIpAddress() ?: "192.168.49.1"
        if (!hasNearbyPermission() || manager == null || channel == null) {
            _state.value = WifiDirectState.HostingGroup(ipAddress = fallbackIp)
            return
        }
        val ch = channel ?: return
        manager.createGroup(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                manager.requestGroupInfo(ch) { group ->
                    val ip = Formatters.getLocalIpAddress() ?: "192.168.49.1"
                    _state.value = WifiDirectState.HostingGroup(
                        ipAddress = ip,
                        ssid = group?.networkName,
                        passphrase = group?.passphrase
                    )
                }
            }

            override fun onFailure(reasonCode: Int) {
                val ip = Formatters.getLocalIpAddress() ?: "192.168.49.1"
                _state.value = WifiDirectState.HostingGroup(ipAddress = ip)
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun connectToPeer(device: NearbyDevice) {
        initialize()
        if (!hasNearbyPermission()) {
            _state.value = WifiDirectState.Error("Nearby Wi-Fi permission required")
            return
        }
        val ch = channel ?: return
        pendingPeerName = device.deviceName
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
        }
        manager?.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                requestConnectionInfo()
            }

            override fun onFailure(reason: Int) {
                _state.value = WifiDirectState.Error("Could not connect to ${device.deviceName} (code $reason)")
            }
        })
    }

    /**
     * Directly connects over local Wi-Fi or Hotspot using IP from QR scan or manual entry.
     */
    fun connectDirectlyByIp(ipAddress: String, peerName: String) {
        _state.value = WifiDirectState.Connected(
            peerName = peerName,
            groupOwnerIp = ipAddress,
            isGroupOwner = false
        )
    }

    @SuppressLint("MissingPermission")
    fun requestConnectionInfo() {
        val ch = channel ?: return
        manager?.requestConnectionInfo(ch) { info ->
            if (info != null && info.groupFormed) {
                val ownerIp = info.groupOwnerAddress?.hostAddress
                    ?: Formatters.getLocalIpAddress()
                    ?: "192.168.49.1"
                _state.value = WifiDirectState.Connected(
                    peerName = pendingPeerName,
                    groupOwnerIp = ownerIp,
                    isGroupOwner = info.isGroupOwner
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        val ch = channel
        if (ch != null) {
            manager?.removeGroup(ch, null)
            manager?.stopPeerDiscovery(ch, null)
        }
        _peers.value = emptyList()
        _state.value = WifiDirectState.Idle
    }

    fun release() {
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
    }
}
