package com.flashshare.app.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.flashshare.app.R
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.ui.permissions.PermissionRationaleDialog
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

private val BrowserTabs = listOf(
    FileCategory.APPS to R.string.tab_apps,
    FileCategory.PHOTOS to R.string.tab_photos,
    FileCategory.VIDEOS to R.string.tab_videos,
    FileCategory.MUSIC to R.string.tab_music,
    FileCategory.DOCUMENTS to R.string.tab_documents,
    FileCategory.DOWNLOADS to R.string.tab_downloads
)

@Composable
fun FileBrowserScreen(
    viewModel: MainViewModel,
    onProceedToSend: () -> Unit
) {
    val context = LocalContext.current
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val categoryFiles by viewModel.categoryFiles.collectAsState()
    val isLoading by viewModel.isLoadingCategory.collectAsState()
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var showMediaPermDialog by remember { mutableStateOf(false) }

    val mediaPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.loadCategoryFiles(selectedCategory, forceRefresh = true)
    }

    LaunchedEffect(selectedCategory) {
        val needsMediaPerm = selectedCategory != FileCategory.APPS
        if (needsMediaPerm && !PermissionHelper.hasAll(context, PermissionHelper.mediaPermissions())) {
            showMediaPermDialog = true
        } else {
            viewModel.loadCategoryFiles(selectedCategory)
        }
    }

    if (showMediaPermDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_media_title),
            description = stringResource(R.string.perm_media_desc),
            onGrantClick = {
                showMediaPermDialog = false
                mediaPermLauncher.launch(PermissionHelper.mediaPermissions())
            },
            onOpenSettingsClick = {
                showMediaPermDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = {
                showMediaPermDialog = false
                viewModel.loadCategoryFiles(selectedCategory)
            }
        )
    }

    val rawList = categoryFiles[selectedCategory].orEmpty()
    val displayedList = remember(rawList, searchQuery) {
        if (searchQuery.isBlank()) rawList
        else rawList.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text(stringResource(R.string.files_search_hint)) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )

        // 6 Category Tabs
        val selectedIndex = BrowserTabs.indexOfFirst { it.first == selectedCategory }.coerceAtLeast(0)
        ScrollableTabRow(
            selectedTabIndex = selectedIndex,
            edgePadding = 12.dp
        ) {
            BrowserTabs.forEach { (category, labelRes) ->
                Tab(
                    selected = category == selectedCategory,
                    onClick = { viewModel.selectCategory(category) },
                    text = { Text(stringResource(labelRes)) }
                )
            }
        }

        // File content area
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                isLoading && displayedList.isEmpty() -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(stringResource(R.string.files_loading))
                    }
                }
                displayedList.isEmpty() -> {
                    Text(
                        text = stringResource(R.string.files_empty_category),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                selectedCategory == FileCategory.PHOTOS || selectedCategory == FileCategory.VIDEOS -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayedList, key = { it.id }) { file ->
                            val isSelected = selectedFiles.containsKey(file.id)
                            MediaThumbnailTile(
                                file = file,
                                isSelected = isSelected,
                                onToggle = { viewModel.toggleFileSelection(file) }
                            )
                        }
                    }
                }
                else -> {
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayedList, key = { it.id }) { file ->
                            val isSelected = selectedFiles.containsKey(file.id)
                            FileListRow(
                                file = file,
                                isSelected = isSelected,
                                onToggle = { viewModel.toggleFileSelection(file) }
                            )
                        }
                    }
                }
            }
        }

        // Bottom Multi-Select Action Bar
        if (selectedFiles.isNotEmpty()) {
            val totalBytes = selectedFiles.values.sumOf { it.sizeBytes }
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(
                                R.string.files_selected_count,
                                selectedFiles.size,
                                Formatters.formatBytes(totalBytes)
                            ),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(
                            onClick = { viewModel.clearSelection() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(stringResource(R.string.files_clear_selection))
                        }
                    }
                    Button(onClick = onProceedToSend) {
                        Text(stringResource(R.string.files_send_selected, selectedFiles.size))
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaThumbnailTile(
    file: ShareableFile,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .border(3.dp, borderColor, RoundedCornerShape(10.dp))
            .clickable(onClick = onToggle)
    ) {
        AsyncImage(
            model = file.uri,
            contentDescription = file.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (file.category == FileCategory.VIDEOS) {
            Icon(
                imageVector = Icons.Default.PlayCircle,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(34.dp)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = Formatters.formatBytes(file.sizeBytes),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
        if (isSelected) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .background(Color.White, CircleShape)
                    .size(22.dp)
            )
        }
    }
}

@Composable
private fun FileListRow(
    file: ShareableFile,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    val context = LocalContext.current
    val appIconBitmap = remember(file.packageName) {
        file.packageName?.let { pkg ->
            runCatching {
                val drawable = context.packageManager.getApplicationIcon(pkg)
                if (drawable is BitmapDrawable && drawable.bitmap != null) {
                    drawable.bitmap
                } else {
                    val width = drawable.intrinsicWidth.coerceAtLeast(48)
                    val height = drawable.intrinsicHeight.coerceAtLeast(48)
                    Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bmp ->
                        val canvas = Canvas(bmp)
                        drawable.setBounds(0, 0, canvas.width, canvas.height)
                        drawable.draw(canvas)
                    }
                }
            }.getOrNull()
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (appIconBitmap != null) {
            Image(
                bitmap = appIconBitmap.asImageBitmap(),
                contentDescription = file.name,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
        } else {
            val icon = when (file.category) {
                FileCategory.APPS -> Icons.Default.Android
                FileCategory.MUSIC -> Icons.Default.AudioFile
                FileCategory.DOWNLOADS -> Icons.Default.Download
                else -> Icons.Default.Description
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(
                        MaterialTheme.colorScheme.primaryContainer,
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = Formatters.formatBytes(file.sizeBytes),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Checkbox(
            checked = isSelected,
            onCheckedChange = { onToggle() }
        )
    }
}
