package com.flashshare.app.transfer

import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Binary framed TCP protocol for high-speed offline transfers.
 * Supports 64-bit file sizes (>4 GB) and byte-offset resume negotiation.
 */
object TransferProtocol {
    const val DEFAULT_PORT: Int = 8988
    const val MAGIC: Int = 0x46534831 // "FSH1"
    const val PROTOCOL_VERSION: Int = 1
    const val BUFFER_SIZE: Int = 256 * 1024 // 256 KB chunks for high LAN throughput

    const val RESPONSE_OK: Byte = 1
    const val RESPONSE_LOW_STORAGE: Byte = 2
    const val RESPONSE_REJECTED: Byte = 3

    data class FileHeader(
        val transferId: String,
        val fileName: String,
        val mimeType: String,
        val categoryName: String,
        val senderName: String,
        val totalSizeBytes: Long
    )

    data class ReceiverAck(
        val status: Byte,
        val offsetOrAvailableBytes: Long
    )

    fun writeHeader(out: DataOutputStream, header: FileHeader) {
        out.writeInt(MAGIC)
        out.writeInt(PROTOCOL_VERSION)
        out.writeUTF(header.transferId)
        out.writeUTF(header.fileName)
        out.writeUTF(header.mimeType)
        out.writeUTF(header.categoryName)
        out.writeUTF(header.senderName)
        out.writeLong(header.totalSizeBytes)
        out.flush()
    }

    fun readHeader(input: DataInputStream): FileHeader {
        val magic = input.readInt()
        if (magic != MAGIC) {
            throw IllegalStateException("Invalid FlashShare protocol header")
        }
        val version = input.readInt()
        if (version != PROTOCOL_VERSION) {
            throw IllegalStateException("Unsupported protocol version: $version")
        }
        val transferId = input.readUTF()
        val fileName = input.readUTF()
        val mimeType = input.readUTF()
        val categoryName = input.readUTF()
        val senderName = input.readUTF()
        val totalSize = input.readLong()
        return FileHeader(
            transferId = transferId,
            fileName = fileName,
            mimeType = mimeType,
            categoryName = categoryName,
            senderName = senderName,
            totalSizeBytes = totalSize
        )
    }

    fun writeAck(out: DataOutputStream, status: Byte, offsetOrAvailableBytes: Long) {
        out.writeByte(status.toInt())
        out.writeLong(offsetOrAvailableBytes)
        out.flush()
    }

    fun readAck(input: DataInputStream): ReceiverAck {
        val status = input.readByte()
        val value = input.readLong()
        return ReceiverAck(status = status, offsetOrAvailableBytes = value)
    }
}
