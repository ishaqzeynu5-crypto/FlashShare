package com.flashshare.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.flashshare.app.R
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.ui.screens.FileBrowserScreen
import com.flashshare.app.ui.screens.HistoryScreen
import com.flashshare.app.ui.screens.HomeScreen
import com.flashshare.app.ui.screens.PhoneCloneScreen
import com.flashshare.app.ui.screens.QrScanScreen
import com.flashshare.app.ui.screens.ReceiveRadarScreen
import com.flashshare.app.ui.screens.SendRadarScreen
import com.flashshare.app.ui.screens.SettingsScreen
import com.flashshare.app.ui.screens.TransferQueueScreen
import com.flashshare.app.ui.screens.WebShareScreen
import com.flashshare.app.ui.viewmodel.MainViewModel

object Routes {
    const val HOME = "home"
    const val FILES = "files"
    const val TRANSFERS = "transfers"
    const val HISTORY = "history"
    const val SEND_RADAR = "send_radar"
    const val RECEIVE_RADAR = "receive_radar"
    const val QR_SCAN = "qr_scan"
    const val PHONE_CLONE = "phone_clone"
    const val WEB_SHARE = "web_share"
    const val SETTINGS = "settings"
}

private data class BottomTab(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector
)

@Composable
fun FlashShareAppRoot(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val statusBanner by viewModel.statusBanner.collectAsState()
    val transfers by viewModel.transfers.collectAsState()

    val activeTransferCount = transfers.count {
        it.status == TransferStatus.RUNNING ||
            it.status == TransferStatus.QUEUED ||
            it.status == TransferStatus.PAUSED
    }

    LaunchedEffect(statusBanner) {
        statusBanner?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearMessage()
        }
    }

    val tabs = listOf(
        BottomTab(Routes.HOME, R.string.nav_home, Icons.Default.Share),
        BottomTab(Routes.FILES, R.string.nav_files, Icons.Default.Folder),
        BottomTab(Routes.TRANSFERS, R.string.nav_transfers, Icons.Default.SwapVert),
        BottomTab(Routes.HISTORY, R.string.nav_history, Icons.Default.History)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = currentRoute in tabs.map { it.route }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    tabs.forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                if (tab.route == Routes.TRANSFERS && activeTransferCount > 0) {
                                    BadgedBox(
                                        badge = { Badge { Text(activeTransferCount.toString()) } }
                                    ) {
                                        Icon(tab.icon, contentDescription = stringResource(tab.labelRes))
                                    }
                                } else {
                                    Icon(tab.icon, contentDescription = stringResource(tab.labelRes))
                                }
                            },
                            label = { Text(stringResource(tab.labelRes)) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    viewModel = viewModel,
                    onSendClick = { navController.navigate(Routes.FILES) },
                    onReceiveClick = { navController.navigate(Routes.RECEIVE_RADAR) },
                    onSendRadarClick = { navController.navigate(Routes.SEND_RADAR) },
                    onPhoneCloneClick = { navController.navigate(Routes.PHONE_CLONE) },
                    onWebShareClick = { navController.navigate(Routes.WEB_SHARE) },
                    onSettingsClick = { navController.navigate(Routes.SETTINGS) }
                )
            }
            composable(Routes.FILES) {
                FileBrowserScreen(
                    viewModel = viewModel,
                    onProceedToSend = {
                        if (viewModel.sendSelectedFiles()) {
                            navController.navigate(Routes.TRANSFERS)
                        } else {
                            navController.navigate(Routes.SEND_RADAR)
                        }
                    }
                )
            }
            composable(Routes.TRANSFERS) {
                TransferQueueScreen(viewModel = viewModel)
            }
            composable(Routes.HISTORY) {
                HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToSendRadar = { navController.navigate(Routes.SEND_RADAR) },
                    onNavigateToTransfers = { navController.navigate(Routes.TRANSFERS) }
                )
            }
            composable(Routes.SEND_RADAR) {
                SendRadarScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onScanQrClick = { navController.navigate(Routes.QR_SCAN) },
                    onOpenTransfers = {
                        navController.navigate(Routes.TRANSFERS) {
                            popUpTo(Routes.HOME)
                        }
                    }
                )
            }
            composable(Routes.RECEIVE_RADAR) {
                ReceiveRadarScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenTransfers = {
                        navController.navigate(Routes.TRANSFERS) {
                            popUpTo(Routes.HOME)
                        }
                    }
                )
            }
            composable(Routes.QR_SCAN) {
                QrScanScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onConnected = {
                        if (viewModel.sendSelectedFiles()) {
                            navController.navigate(Routes.TRANSFERS) {
                                popUpTo(Routes.HOME)
                            }
                        } else {
                            navController.popBackStack()
                        }
                    }
                )
            }
            composable(Routes.PHONE_CLONE) {
                PhoneCloneScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenSendRadar = { navController.navigate(Routes.SEND_RADAR) },
                    onOpenReceiveRadar = { navController.navigate(Routes.RECEIVE_RADAR) },
                    onOpenTransfers = { navController.navigate(Routes.TRANSFERS) }
                )
            }
            composable(Routes.WEB_SHARE) {
                WebShareScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onSelectFiles = { navController.navigate(Routes.FILES) }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
