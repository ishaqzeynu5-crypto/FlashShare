package com.flashshare.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.network.WifiDirectState
import com.flashshare.app.qr.QrCodeGenerator
import com.flashshare.app.qr.QrScannerView
import com.flashshare.app.ui.components.RadarAnimationView
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.ui.permissions.PermissionRationaleDialog
import com.flashshare.app.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendRadarScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onScanQrClick: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val context = LocalContext.current
    val peers by viewModel.nearbyPeers.collectAsState()
    val wifiState by viewModel.wifiDirectState.collectAsState()
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val isWifiEnabled by viewModel.isWifiP2pEnabled.collectAsState()

    var manualIp by remember { mutableStateOf("") }
    var showPermissionDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) {
            viewModel.startNearbyDiscovery()
        } else {
            showPermissionDialog = true
        }
    }

    LaunchedEffect(Unit) {
        val required = PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()
        if (PermissionHelper.hasAll(context, required)) {
            viewModel.startNearbyDiscovery()
        } else {
            showPermissionDialog = true
        }
    }

    if (showPermissionDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_nearby_title),
            description = stringResource(R.string.perm_nearby_desc),
            onGrantClick = {
                showPermissionDialog = false
                permissionLauncher.launch(
                    (PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()).distinct().toTypedArray()
                )
            },
            onOpenSettingsClick = {
                showPermissionDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = { showPermissionDialog = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.action_send)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.startNearbyDiscovery() }) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.action_refresh))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            RadarAnimationView(
                centerIcon = Icons.Default.Upload,
                isScanning = wifiState is WifiDirectState.Discovering || wifiState is WifiDirectState.Idle
            )

            if (!isWifiEnabled) {
                Text(
                    text = stringResource(R.string.error_wifi_disabled),
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            when (val st = wifiState) {
                is WifiDirectState.Connected -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = stringResource(R.string.radar_connected_to, st.peerName),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = st.groupOwnerIp, style = MaterialTheme.typography.bodySmall)
                            if (selectedFiles.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        if (viewModel.sendSelectedFiles()) {
                                            onOpenTransfers()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(stringResource(R.string.files_send_selected, selectedFiles.size))
                                }
                            }
                        }
                    }
                }
                is WifiDirectState.Error -> {
                    Text(
                        text = st.message,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                else -> {
                    Text(
                        text = stringResource(R.string.radar_searching),
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }

            Button(
                onClick = onScanQrClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.action_scan_qr))
            }

            // Discovered Nearby Devices
            if (peers.isEmpty()) {
                Text(
                    text = stringResource(R.string.radar_no_devices),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            } else {
                Text(
                    text = stringResource(R.string.radar_tap_to_connect),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.fillMaxWidth()
                )
                peers.forEach { peer ->
                    ElevatedCard(
                        onClick = { viewModel.connectToPeer(peer) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(peer.deviceName, fontWeight = FontWeight.SemiBold)
                                Text(
                                    peer.deviceAddress,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = stringResource(R.string.action_connect),
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // Manual IP fallback (local Wi-Fi / hotspot)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.qr_manual_ip),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manualIp,
                            onValueChange = { manualIp = it },
                            placeholder = { Text("192.168.49.1") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                viewModel.connectManually(manualIp)
                                if (selectedFiles.isNotEmpty() && viewModel.sendSelectedFiles()) {
                                    onOpenTransfers()
                                }
                            },
                            enabled = manualIp.isNotBlank()
                        ) {
                            Text(stringResource(R.string.action_connect))
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.radar_hotspot_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiveRadarScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val context = LocalContext.current
    val wifiState by viewModel.wifiDirectState.collectAsState()
    val isServerRunning by viewModel.isReceiveServerRunning.collectAsState()
    val lastVcfPath by viewModel.lastReceivedVcfPath.collectAsState()

    var showNearbyDialog by remember { mutableStateOf(false) }

    val nearbyLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.startReceiverMode()
    }

    val contactsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) {
            viewModel.importReceivedContacts { count ->
                viewModel.showMessage(context.getString(R.string.clone_contacts_imported, count))
            }
        }
    }

    LaunchedEffect(Unit) {
        val perms = PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()
        if (PermissionHelper.hasAll(context, perms)) {
            viewModel.startReceiverMode()
        } else {
            showNearbyDialog = true
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            // Keep server running while transfers are in progress; user can stop via back/disconnect
        }
    }

    if (showNearbyDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_nearby_title),
            description = stringResource(R.string.perm_nearby_desc),
            onGrantClick = {
                showNearbyDialog = false
                nearbyLauncher.launch(
                    (PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()).distinct().toTypedArray()
                )
            },
            onOpenSettingsClick = {
                showNearbyDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = {
                showNearbyDialog = false
                viewModel.startReceiverMode()
            }
        )
    }

    val qrPayload = remember(wifiState, isServerRunning) { viewModel.buildReceiverQrPayload() }
    val qrBitmap = remember(qrPayload) { QrCodeGenerator.generateBitmap(qrPayload, 512) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.action_receive)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            RadarAnimationView(
                centerIcon = Icons.Default.Download,
                isScanning = isServerRunning,
                size = 180.dp
            )

            Text(
                text = stringResource(R.string.radar_waiting_sender),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            if (qrBitmap != null) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Image(
                        bitmap = qrBitmap.asImageBitmap(),
                        contentDescription = stringResource(R.string.action_show_qr),
                        modifier = Modifier
                            .padding(16.dp)
                            .size(210.dp)
                    )
                }
            }

            Text(
                text = stringResource(R.string.qr_receiver_instruction),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            val ipText = when (val st = wifiState) {
                is WifiDirectState.HostingGroup -> st.ipAddress
                is WifiDirectState.Connected -> st.groupOwnerIp
                else -> com.flashshare.app.util.Formatters.getLocalIpAddress() ?: "192.168.49.1"
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "IP: $ipText : 8988",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (wifiState is WifiDirectState.HostingGroup) {
                        val host = wifiState as WifiDirectState.HostingGroup
                        if (!host.ssid.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Wi-Fi Direct: ${host.ssid}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            if (lastVcfPath != null) {
                Button(
                    onClick = {
                        if (PermissionHelper.hasAll(context, PermissionHelper.contactsPermissions())) {
                            viewModel.importReceivedContacts { count ->
                                viewModel.showMessage(context.getString(R.string.clone_contacts_imported, count))
                            }
                        } else {
                            contactsLauncher.launch(PermissionHelper.contactsPermissions())
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.clone_import_contacts))
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        viewModel.stopReceiverMode()
                        onBack()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.action_disconnect))
                }
                Button(
                    onClick = onOpenTransfers,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.nav_transfers))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScanScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onConnected: () -> Unit
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(PermissionHelper.hasAll(context, PermissionHelper.cameraPermissions()))
    }
    var showRationale by remember { mutableStateOf(!hasCameraPermission) }
    val invalidQrMessage = stringResource(R.string.error_invalid_qr)

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasCameraPermission = grants.values.all { it }
        if (!hasCameraPermission) showRationale = true
    }

    if (showRationale && !hasCameraPermission) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_camera_title),
            description = stringResource(R.string.perm_camera_desc),
            onGrantClick = {
                showRationale = false
                cameraLauncher.launch(PermissionHelper.cameraPermissions())
            },
            onOpenSettingsClick = {
                showRationale = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = {
                showRationale = false
                onBack()
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.action_scan_qr)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (hasCameraPermission) {
                QrScannerView(
                    modifier = Modifier.fillMaxSize(),
                    onQrScanned = { rawCode ->
                        if (viewModel.connectByQrPayload(rawCode)) {
                            onConnected()
                        } else {
                            viewModel.showMessage(invalidQrMessage)
                        }
                    }
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.65f))
                        .padding(20.dp)
                ) {
                    Text(
                        text = stringResource(R.string.qr_scan_instruction),
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
