package com.flashshare.app.ui.viewmodel

import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.flashshare.app.data.local.TransferHistoryEntity
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.ContactsRepository
import com.flashshare.app.data.repository.FileBrowserRepository
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.AppLanguage
import com.flashshare.app.domain.model.AppThemeMode
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.NearbyDevice
import com.flashshare.app.domain.model.PhoneCloneSelection
import com.flashshare.app.domain.model.PhoneCloneSummary
import com.flashshare.app.domain.model.QrConnectionPayload
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.network.WifiDirectManager
import com.flashshare.app.network.WifiDirectState
import com.flashshare.app.transfer.TransferManager
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.util.Formatters
import com.flashshare.app.webserver.LocalWebServer
import com.flashshare.app.webserver.WebServerState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val fileBrowserRepository: FileBrowserRepository,
    private val contactsRepository: ContactsRepository,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences,
    val storageOrganizer: StorageOrganizer,
    private val transferManager: TransferManager,
    private val wifiDirectManager: WifiDirectManager,
    private val localWebServer: LocalWebServer
) : ViewModel() {

    val themeMode: StateFlow<AppThemeMode> = userPreferences.themeMode.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppThemeMode.SYSTEM
    )

    val language: StateFlow<AppLanguage> = userPreferences.language.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppLanguage.ENGLISH
    )

    val deviceName: StateFlow<String> = userPreferences.deviceName.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        userPreferences.defaultDeviceName()
    )

    val wifiDirectState: StateFlow<WifiDirectState> = wifiDirectManager.state
    val nearbyPeers: StateFlow<List<NearbyDevice>> = wifiDirectManager.peers
    val isWifiP2pEnabled: StateFlow<Boolean> = wifiDirectManager.isWifiP2pEnabled

    val transfers: StateFlow<List<TransferItem>> = transferManager.transfers
    val isReceiveServerRunning: StateFlow<Boolean> = transferManager.isReceiveServerRunning
    val lastReceivedVcfPath: StateFlow<String?> = transferManager.lastReceivedVcfPath

    val webServerState: StateFlow<WebServerState> = localWebServer.state

    val history: StateFlow<List<TransferHistoryEntity>> = historyRepository.observeHistory().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    private val _selectedCategory = MutableStateFlow(FileCategory.APPS)
    val selectedCategory: StateFlow<FileCategory> = _selectedCategory.asStateFlow()

    private val _categoryFiles = MutableStateFlow<Map<FileCategory, List<ShareableFile>>>(emptyMap())
    val categoryFiles: StateFlow<Map<FileCategory, List<ShareableFile>>> = _categoryFiles.asStateFlow()

    private val _isLoadingCategory = MutableStateFlow(false)
    val isLoadingCategory: StateFlow<Boolean> = _isLoadingCategory.asStateFlow()

    private val _selectedFiles = MutableStateFlow<Map<String, ShareableFile>>(emptyMap())
    val selectedFiles: StateFlow<Map<String, ShareableFile>> = _selectedFiles.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _cloneSummary = MutableStateFlow(PhoneCloneSummary())
    val cloneSummary: StateFlow<PhoneCloneSummary> = _cloneSummary.asStateFlow()

    private val _isPreparingClone = MutableStateFlow(false)
    val isPreparingClone: StateFlow<Boolean> = _isPreparingClone.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    init {
        wifiDirectManager.initialize()
    }

    fun selectCategory(category: FileCategory) {
        _selectedCategory.value = category
        loadCategoryFiles(category)
    }

    fun loadCategoryFiles(category: FileCategory, forceRefresh: Boolean = false) {
        if (!forceRefresh && _categoryFiles.value.containsKey(category)) return
        viewModelScope.launch {
            _isLoadingCategory.value = true
            val loaded = fileBrowserRepository.loadCategory(category)
            _categoryFiles.update { it + (category to loaded) }
            _isLoadingCategory.value = false
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFileSelection(file: ShareableFile) {
        _selectedFiles.update { current ->
            if (current.containsKey(file.id)) {
                current - file.id
            } else {
                current + (file.id to file)
            }
        }
        syncWebServerFiles()
    }

    fun clearSelection() {
        _selectedFiles.value = emptyMap()
        syncWebServerFiles()
    }

    fun startNearbyDiscovery() {
        wifiDirectManager.startDiscovery()
    }

    fun startReceiverMode() {
        wifiDirectManager.startReceiverGroup()
        transferManager.startReceiveServer(TransferProtocol.DEFAULT_PORT)
    }

    fun stopReceiverMode() {
        transferManager.stopReceiveServer()
        wifiDirectManager.disconnect()
    }

    fun connectToPeer(device: NearbyDevice) {
        wifiDirectManager.connectToPeer(device)
    }

    fun connectByQrPayload(rawQr: String): Boolean {
        val payload = QrConnectionPayload.decode(rawQr) ?: return false
        wifiDirectManager.connectDirectlyByIp(payload.ipAddress, payload.deviceName)
        return true
    }

    fun connectManually(ipAddress: String) {
        val cleanIp = ipAddress.trim()
        if (cleanIp.isBlank()) return
        wifiDirectManager.connectDirectlyByIp(cleanIp, cleanIp)
    }

    fun disconnectPeer() {
        wifiDirectManager.disconnect()
    }

    fun buildReceiverQrPayload(): String {
        val state = wifiDirectState.value
        val ip = when (state) {
            is WifiDirectState.HostingGroup -> state.ipAddress
            is WifiDirectState.Connected -> state.groupOwnerIp
            else -> Formatters.getLocalIpAddress() ?: "192.168.49.1"
        }
        val ssid = (state as? WifiDirectState.HostingGroup)?.ssid
        val pass = (state as? WifiDirectState.HostingGroup)?.passphrase
        return QrConnectionPayload(
            deviceName = deviceName.value,
            ipAddress = ip,
            port = TransferProtocol.DEFAULT_PORT,
            ssid = ssid,
            passphrase = pass
        ).encode()
    }

    fun sendSelectedFiles(): Boolean {
        val files = _selectedFiles.value.values.toList()
        if (files.isEmpty()) return false
        val conn = wifiDirectState.value as? WifiDirectState.Connected ?: return false
        transferManager.sendFiles(
            targetIp = conn.groupOwnerIp,
            port = TransferProtocol.DEFAULT_PORT,
            peerName = conn.peerName,
            files = files
        )
        _selectedFiles.value = emptyMap()
        return true
    }

    fun resendHistoryItem(entry: TransferHistoryEntity): Boolean {
        val file = entry.localPath?.let { File(it) }?.takeIf { it.exists() }
        val uri = when {
            file != null -> Uri.fromFile(file)
            !entry.sourceUriString.isNullOrBlank() -> Uri.parse(entry.sourceUriString)
            else -> return false
        }
        val shareable = ShareableFile(
            id = "resend_${entry.id}_${System.currentTimeMillis()}",
            name = entry.fileName,
            sizeBytes = file?.length() ?: entry.sizeBytes,
            mimeType = entry.mimeType,
            category = entry.fileCategoryEnum(),
            uri = uri,
            filePath = file?.absolutePath
        )
        val conn = wifiDirectState.value as? WifiDirectState.Connected
        return if (conn != null) {
            transferManager.sendFiles(
                targetIp = conn.groupOwnerIp,
                port = TransferProtocol.DEFAULT_PORT,
                peerName = conn.peerName,
                files = listOf(shareable)
            )
            true
        } else {
            _selectedFiles.update { it + (shareable.id to shareable) }
            false
        }
    }

    fun pauseTransfer(id: String) = transferManager.pauseTransfer(id)
    fun resumeTransfer(id: String) = transferManager.resumeTransfer(id)
    fun cancelTransfer(id: String) = transferManager.cancelTransfer(id)
    fun clearFinishedTransfers() = transferManager.clearFinished()

    fun loadPhoneCloneSummary() {
        viewModelScope.launch {
            _isPreparingClone.value = true
            val contacts = contactsRepository.getContactCount()
            val photos = fileBrowserRepository.loadCategory(FileCategory.PHOTOS)
            val videos = fileBrowserRepository.loadCategory(FileCategory.VIDEOS)
            val music = fileBrowserRepository.loadCategory(FileCategory.MUSIC)
            _categoryFiles.update {
                it + mapOf(
                    FileCategory.PHOTOS to photos,
                    FileCategory.VIDEOS to videos,
                    FileCategory.MUSIC to music
                )
            }
            _cloneSummary.value = PhoneCloneSummary(
                contactCount = contacts,
                photoCount = photos.size,
                photoBytes = photos.sumOf { it.sizeBytes },
                videoCount = videos.size,
                videoBytes = videos.sumOf { it.sizeBytes },
                musicCount = music.size,
                musicBytes = music.sumOf { it.sizeBytes }
            )
            _isPreparingClone.value = false
        }
    }

    fun startPhoneCloneSend(selection: PhoneCloneSelection, onReadyToSend: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isPreparingClone.value = true
            val batch = mutableListOf<ShareableFile>()
            if (selection.includeContacts) {
                contactsRepository.exportContactsToVcf()?.let { batch.add(it) }
            }
            if (selection.includePhotos) {
                batch.addAll(_categoryFiles.value[FileCategory.PHOTOS] ?: fileBrowserRepository.loadCategory(FileCategory.PHOTOS))
            }
            if (selection.includeVideos) {
                batch.addAll(_categoryFiles.value[FileCategory.VIDEOS] ?: fileBrowserRepository.loadCategory(FileCategory.VIDEOS))
            }
            if (selection.includeMusic) {
                batch.addAll(_categoryFiles.value[FileCategory.MUSIC] ?: fileBrowserRepository.loadCategory(FileCategory.MUSIC))
            }
            _isPreparingClone.value = false

            if (batch.isEmpty()) {
                onReadyToSend(false)
                return@launch
            }

            val conn = wifiDirectState.value as? WifiDirectState.Connected
            if (conn != null) {
                transferManager.sendFiles(
                    targetIp = conn.groupOwnerIp,
                    port = TransferProtocol.DEFAULT_PORT,
                    peerName = conn.peerName,
                    files = batch
                )
                onReadyToSend(true)
            } else {
                _selectedFiles.value = batch.associateBy { it.id }
                onReadyToSend(false)
            }
        }
    }

    fun importReceivedContacts(onResult: (Int) -> Unit) {
        val path = lastReceivedVcfPath.value ?: return
        viewModelScope.launch {
            val count = contactsRepository.importContactsFromVcf(File(path))
            transferManager.clearLastReceivedVcf()
            onResult(count)
        }
    }

    fun startWebServer() {
        syncWebServerFiles()
        localWebServer.start()
    }

    fun stopWebServer() {
        localWebServer.stop()
    }

    private fun syncWebServerFiles() {
        localWebServer.setSharedFiles(_selectedFiles.value.values.toList())
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch {
            historyRepository.deleteEntry(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepository.clearAll()
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            userPreferences.setThemeMode(mode)
        }
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch {
            userPreferences.setLanguage(lang)
            val locales = LocaleListCompat.forLanguageTags(lang.tag)
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }

    fun setDeviceName(name: String) {
        viewModelScope.launch {
            userPreferences.setDeviceName(name)
        }
    }

    fun showMessage(message: String) {
        _statusBanner.value = message
    }

    fun clearMessage() {
        _statusBanner.value = null
    }

    override fun onCleared() {
        wifiDirectManager.release()
        super.onCleared()
    }
}
