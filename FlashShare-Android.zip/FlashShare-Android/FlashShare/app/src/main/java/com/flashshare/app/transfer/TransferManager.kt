package com.flashshare.app.transfer

import android.content.Context
import android.content.Intent
import android.os.Build
import com.flashshare.app.R
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.service.TransferForegroundService
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val storageOrganizer: StorageOrganizer,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _transfers = MutableStateFlow<List<TransferItem>>(emptyList())
    val transfers: StateFlow<List<TransferItem>> = _transfers.asStateFlow()

    private val _isReceiveServerRunning = MutableStateFlow(false)
    val isReceiveServerRunning: StateFlow<Boolean> = _isReceiveServerRunning.asStateFlow()

    private val _lastReceivedVcfPath = MutableStateFlow<String?>(null)
    val lastReceivedVcfPath: StateFlow<String?> = _lastReceivedVcfPath.asStateFlow()

    private val pauseFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val cancelFlags = ConcurrentHashMap<String, AtomicBoolean>()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    fun startReceiveServer(port: Int = TransferProtocol.DEFAULT_PORT) {
        if (_isReceiveServerRunning.value) return
        serverJob = scope.launch {
            try {
                val ss = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(port))
                }
                serverSocket = ss
                _isReceiveServerRunning.value = true
                while (isActive && !ss.isClosed) {
                    val client = try {
                        ss.accept()
                    } catch (_: Exception) {
                        break
                    }
                    launch { handleIncomingSocket(client) }
                }
            } catch (_: Exception) {
                _isReceiveServerRunning.value = false
            } finally {
                _isReceiveServerRunning.value = false
            }
        }
    }

    fun stopReceiveServer() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        _isReceiveServerRunning.value = false
    }

    fun sendFiles(
        targetIp: String,
        port: Int = TransferProtocol.DEFAULT_PORT,
        peerName: String,
        files: List<ShareableFile>
    ) {
        if (files.isEmpty()) return
        ensureForegroundService()

        val queuedItems = files.map { file ->
            val id = UUID.randomUUID().toString()
            pauseFlags[id] = AtomicBoolean(false)
            cancelFlags[id] = AtomicBoolean(false)
            TransferItem(
                id = id,
                fileName = file.name,
                sizeBytes = file.sizeBytes,
                mimeType = file.mimeType,
                category = file.category,
                direction = TransferDirection.SEND,
                status = TransferStatus.QUEUED,
                sourceUri = file.uri,
                localPath = file.filePath,
                peerName = peerName
            )
        }

        _transfers.update { queuedItems + it }

        scope.launch {
            val myName = userPreferences.deviceName.first()
            for (index in files.indices) {
                val file = files[index]
                val item = queuedItems[index]
                if (cancelFlags[item.id]?.get() == true) {
                    updateItem(item.id) { it.copy(status = TransferStatus.CANCELLED) }
                    continue
                }
                sendSingleFile(targetIp, port, myName, file, item)
            }
        }
    }

    fun pauseTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        updateItem(transferId) { item ->
            if (item.status == TransferStatus.RUNNING || item.status == TransferStatus.QUEUED) {
                item.copy(status = TransferStatus.PAUSED, speedBytesPerSec = 0L, etaSeconds = -1L)
            } else {
                item
            }
        }
    }

    fun resumeTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(false)
        updateItem(transferId) { item ->
            if (item.status == TransferStatus.PAUSED) {
                item.copy(status = TransferStatus.RUNNING)
            } else {
                item
            }
        }
    }

    fun cancelTransfer(transferId: String) {
        cancelFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        pauseFlags[transferId]?.set(false)
        updateItem(transferId) {
            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
        }
    }

    fun cancelAllActive() {
        _transfers.value.forEach { item ->
            if (item.status == TransferStatus.RUNNING ||
                item.status == TransferStatus.QUEUED ||
                item.status == TransferStatus.PAUSED
            ) {
                cancelTransfer(item.id)
            }
        }
    }

    fun clearFinished() {
        _transfers.update { list ->
            list.filter {
                it.status == TransferStatus.RUNNING ||
                    it.status == TransferStatus.QUEUED ||
                    it.status == TransferStatus.PAUSED
            }
        }
    }

    fun clearLastReceivedVcf() {
        _lastReceivedVcfPath.value = null
    }

    private suspend fun sendSingleFile(
        targetIp: String,
        port: Int,
        senderName: String,
        file: ShareableFile,
        initialItem: TransferItem
    ) {
        val transferId = initialItem.id
        var socket: Socket? = null
        try {
            updateItem(transferId) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }

            socket = Socket().apply {
                tcpNoDelay = true
                sendBufferSize = TransferProtocol.BUFFER_SIZE
                connect(InetSocketAddress(targetIp, port), 15_000)
                soTimeout = 30_000
            }

            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

            val header = TransferProtocol.FileHeader(
                transferId = transferId,
                fileName = file.name,
                mimeType = file.mimeType,
                categoryName = file.category.name,
                senderName = senderName,
                totalSizeBytes = file.sizeBytes
            )
            TransferProtocol.writeHeader(dataOut, header)

            val ack = TransferProtocol.readAck(dataIn)
            when (ack.status) {
                TransferProtocol.RESPONSE_LOW_STORAGE -> {
                    val needed = Formatters.formatBytes(file.sizeBytes)
                    val msg = context.getString(R.string.error_low_storage, needed)
                    val failed = updateAndReturn(transferId) {
                        it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                    return
                }
                TransferProtocol.RESPONSE_REJECTED -> {
                    val failed = updateAndReturn(transferId) {
                        it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                    return
                }
            }

            val resumeOffset = ack.offsetOrAvailableBytes.coerceIn(0L, file.sizeBytes)
            val inputStream = openSourceStream(file)
                ?: throw IllegalStateException(context.getString(R.string.error_file_unreadable))

            inputStream.use { rawStream ->
                if (resumeOffset > 0L) {
                    skipFully(rawStream, resumeOffset)
                }
                val buffer = ByteArray(TransferProtocol.BUFFER_SIZE)
                var sentBytes = resumeOffset
                var windowBytes = 0L
                var lastTickMs = System.currentTimeMillis()

                while (sentBytes < file.sizeBytes) {
                    if (cancelFlags[transferId]?.get() == true) {
                        val cancelled = updateAndReturn(transferId) {
                            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                        }
                        cancelled?.let { historyRepository.recordTransfer(it) }
                        return
                    }

                    while (pauseFlags[transferId]?.get() == true) {
                        if (cancelFlags[transferId]?.get() == true) break
                        delay(150L)
                        lastTickMs = System.currentTimeMillis()
                        windowBytes = 0L
                    }

                    if (cancelFlags[transferId]?.get() == true) {
                        val cancelled = updateAndReturn(transferId) {
                            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                        }
                        cancelled?.let { historyRepository.recordTransfer(it) }
                        return
                    }

                    val read = rawStream.read(buffer)
                    if (read == -1) break
                    dataOut.write(buffer, 0, read)
                    sentBytes += read
                    windowBytes += read

                    val now = System.currentTimeMillis()
                    val elapsed = now - lastTickMs
                    if (elapsed >= 250L || sentBytes >= file.sizeBytes) {
                        val speed = if (elapsed > 0L) (windowBytes * 1000L) / elapsed else 0L
                        val remaining = (file.sizeBytes - sentBytes).coerceAtLeast(0L)
                        val eta = if (speed > 0L) remaining / speed else -1L
                        updateItem(transferId) {
                            it.copy(
                                transferredBytes = sentBytes,
                                speedBytesPerSec = speed,
                                etaSeconds = eta,
                                status = TransferStatus.RUNNING
                            )
                        }
                        lastTickMs = now
                        windowBytes = 0L
                    }
                }
                dataOut.flush()
            }

            val completed = updateAndReturn(transferId) {
                it.copy(
                    transferredBytes = file.sizeBytes,
                    status = TransferStatus.COMPLETED,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L
                )
            }
            completed?.let { historyRepository.recordTransfer(it) }
        } catch (e: Exception) {
            if (cancelFlags[transferId]?.get() == true) {
                val cancelled = updateAndReturn(transferId) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
            } else {
                val message = e.message?.takeIf { it.isNotBlank() }
                    ?: context.getString(R.string.error_disconnected)
                val failed = updateAndReturn(transferId) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = message,
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
                failed?.let { historyRepository.recordTransfer(it) }
            }
        } finally {
            runCatching { socket?.close() }
        }
    }

    private suspend fun handleIncomingSocket(socket: Socket) {
        var transferId = UUID.randomUUID().toString()
        try {
            socket.tcpNoDelay = true
            socket.receiveBufferSize = TransferProtocol.BUFFER_SIZE
            socket.soTimeout = 30_000

            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream(), TransferProtocol.BUFFER_SIZE))
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

            val header = TransferProtocol.readHeader(dataIn)
            transferId = header.transferId.ifBlank { transferId }
            val category = runCatching { FileCategory.valueOf(header.categoryName) }
                .getOrElse { Formatters.inferCategory(header.fileName, header.mimeType) }

            val partialTarget = storageOrganizer.resolveTargetFile(
                fileName = header.fileName,
                category = category,
                allowResumeExisting = true
            )
            val resumeOffset = if (partialTarget.exists() && partialTarget.length() < header.totalSizeBytes) {
                partialTarget.length()
            } else {
                0L
            }
            val targetFile = if (resumeOffset > 0L) {
                partialTarget
            } else {
                storageOrganizer.resolveTargetFile(
                    fileName = header.fileName,
                    category = category,
                    allowResumeExisting = false
                )
            }

            val remainingNeeded = (header.totalSizeBytes - resumeOffset).coerceAtLeast(0L)
            if (!storageOrganizer.hasEnoughSpace(remainingNeeded)) {
                TransferProtocol.writeAck(
                    dataOut,
                    TransferProtocol.RESPONSE_LOW_STORAGE,
                    storageOrganizer.getAvailableBytes()
                )
                val failedItem = TransferItem(
                    id = transferId,
                    fileName = header.fileName,
                    sizeBytes = header.totalSizeBytes,
                    transferredBytes = resumeOffset,
                    mimeType = header.mimeType,
                    category = category,
                    direction = TransferDirection.RECEIVE,
                    status = TransferStatus.FAILED,
                    localPath = targetFile.absolutePath,
                    peerName = header.senderName,
                    errorMessage = context.getString(R.string.error_low_storage, Formatters.formatBytes(remainingNeeded))
                )
                _transfers.update { listOf(failedItem) + it }
                historyRepository.recordTransfer(failedItem)
                return
            }

            pauseFlags[transferId] = AtomicBoolean(false)
            cancelFlags[transferId] = AtomicBoolean(false)
            ensureForegroundService()

            val activeItem = TransferItem(
                id = transferId,
                fileName = header.fileName,
                sizeBytes = header.totalSizeBytes,
                transferredBytes = resumeOffset,
                mimeType = header.mimeType,
                category = category,
                direction = TransferDirection.RECEIVE,
                status = TransferStatus.RUNNING,
                localPath = targetFile.absolutePath,
                peerName = header.senderName
            )
            _transfers.update { listOf(activeItem) + it.filterNot { existing -> existing.id == transferId } }

            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, resumeOffset)

            RandomAccessFile(targetFile, "rw").use { raf ->
                if (resumeOffset > 0L) {
                    raf.seek(resumeOffset)
                }
                val buffer = ByteArray(TransferProtocol.BUFFER_SIZE)
                var receivedBytes = resumeOffset
                var windowBytes = 0L
                var lastTickMs = System.currentTimeMillis()

                while (receivedBytes < header.totalSizeBytes) {
                    if (cancelFlags[transferId]?.get() == true) {
                        val cancelled = updateAndReturn(transferId) {
                            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                        }
                        cancelled?.let { historyRepository.recordTransfer(it) }
                        return
                    }

                    while (pauseFlags[transferId]?.get() == true) {
                        if (cancelFlags[transferId]?.get() == true) break
                        delay(150L)
                        lastTickMs = System.currentTimeMillis()
                        windowBytes = 0L
                    }

                    val toRead = minOf(buffer.size.toLong(), header.totalSizeBytes - receivedBytes).toInt()
                    val read = dataIn.read(buffer, 0, toRead)
                    if (read == -1) {
                        throw IllegalStateException(context.getString(R.string.error_disconnected))
                    }
                    raf.write(buffer, 0, read)
                    receivedBytes += read
                    windowBytes += read

                    val now = System.currentTimeMillis()
                    val elapsed = now - lastTickMs
                    if (elapsed >= 250L || receivedBytes >= header.totalSizeBytes) {
                        val speed = if (elapsed > 0L) (windowBytes * 1000L) / elapsed else 0L
                        val remaining = (header.totalSizeBytes - receivedBytes).coerceAtLeast(0L)
                        val eta = if (speed > 0L) remaining / speed else -1L
                        updateItem(transferId) {
                            it.copy(
                                transferredBytes = receivedBytes,
                                speedBytesPerSec = speed,
                                etaSeconds = eta,
                                status = TransferStatus.RUNNING
                            )
                        }
                        lastTickMs = now
                        windowBytes = 0L
                    }
                }
            }

            storageOrganizer.scanReceivedFile(targetFile, header.mimeType)
            if (category == FileCategory.CONTACTS || targetFile.name.endsWith(".vcf", ignoreCase = true)) {
                _lastReceivedVcfPath.value = targetFile.absolutePath
            }

            val completed = updateAndReturn(transferId) {
                it.copy(
                    transferredBytes = header.totalSizeBytes,
                    status = TransferStatus.COMPLETED,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    localPath = targetFile.absolutePath
                )
            }
            completed?.let { historyRepository.recordTransfer(it) }
        } catch (e: Exception) {
            if (cancelFlags[transferId]?.get() == true) {
                val cancelled = updateAndReturn(transferId) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
            } else {
                val message = e.message?.takeIf { it.isNotBlank() }
                    ?: context.getString(R.string.error_disconnected)
                val failed = updateAndReturn(transferId) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = message,
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
                failed?.let { historyRepository.recordTransfer(it) }
            }
        } finally {
            runCatching { socket.close() }
        }
    }

    private fun openSourceStream(file: ShareableFile) =
        if (!file.filePath.isNullOrBlank() && File(file.filePath).canRead()) {
            FileInputStream(File(file.filePath))
        } else {
            context.contentResolver.openInputStream(file.uri)
        }

    private fun skipFully(stream: java.io.InputStream, bytesToSkip: Long) {
        var remaining = bytesToSkip
        val discard = ByteArray(64 * 1024)
        while (remaining > 0L) {
            val skipped = stream.skip(remaining)
            if (skipped > 0L) {
                remaining -= skipped
            } else {
                val read = stream.read(discard, 0, minOf(discard.size.toLong(), remaining).toInt())
                if (read == -1) break
                remaining -= read
            }
        }
    }

    private fun updateItem(id: String, transform: (TransferItem) -> TransferItem) {
        _transfers.update { list ->
            list.map { if (it.id == id) transform(it) else it }
        }
    }

    private fun updateAndReturn(id: String, transform: (TransferItem) -> TransferItem): TransferItem? {
        var updated: TransferItem? = null
        _transfers.update { list ->
            list.map {
                if (it.id == id) {
                    transform(it).also { next -> updated = next }
                } else {
                    it
                }
            }
        }
        return updated
    }

    private fun ensureForegroundService() {
        val intent = Intent(context, TransferForegroundService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
