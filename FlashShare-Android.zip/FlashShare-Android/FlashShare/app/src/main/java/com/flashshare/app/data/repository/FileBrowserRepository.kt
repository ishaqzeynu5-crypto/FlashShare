package com.flashshare.app.data.repository

import android.content.ContentUris
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FileBrowserRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    suspend fun loadCategory(category: FileCategory): List<ShareableFile> = withContext(Dispatchers.IO) {
        when (category) {
            FileCategory.APPS -> loadInstalledApps()
            FileCategory.PHOTOS -> loadPhotos()
            FileCategory.VIDEOS -> loadVideos()
            FileCategory.MUSIC -> loadMusic()
            FileCategory.DOCUMENTS -> loadDocuments()
            FileCategory.DOWNLOADS -> loadDownloads()
            FileCategory.CONTACTS, FileCategory.OTHER -> emptyList()
        }
    }

    private fun loadInstalledApps(): List<ShareableFile> {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        return packages
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .mapNotNull { appInfo ->
                val apkFile = File(appInfo.sourceDir)
                if (!apkFile.exists() || !apkFile.canRead()) return@mapNotNull null
                val label = pm.getApplicationLabel(appInfo).toString().trim().ifBlank { appInfo.packageName }
                ShareableFile(
                    id = "app_${appInfo.packageName}",
                    name = "$label.apk",
                    sizeBytes = apkFile.length(),
                    mimeType = "application/vnd.android.package-archive",
                    category = FileCategory.APPS,
                    uri = Uri.fromFile(apkFile),
                    filePath = apkFile.absolutePath,
                    packageName = appInfo.packageName,
                    lastModified = apkFile.lastModified()
                )
            }
            .sortedBy { it.name.lowercase() }
    }

    private fun loadPhotos(): List<ShareableFile> {
        val results = mutableListOf<ShareableFile>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.DATE_MODIFIED
        )
        runCatching {
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val mime = cursor.getString(mimeCol) ?: "image/jpeg"
                    val modified = cursor.getLong(dateCol) * 1000L
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    results.add(
                        ShareableFile(
                            id = "photo_$id",
                            name = name,
                            sizeBytes = size,
                            mimeType = mime,
                            category = FileCategory.PHOTOS,
                            uri = uri,
                            lastModified = modified
                        )
                    )
                }
            }
        }
        return results
    }

    private fun loadVideos(): List<ShareableFile> {
        val results = mutableListOf<ShareableFile>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.DURATION
        )
        runCatching {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val mime = cursor.getString(mimeCol) ?: "video/mp4"
                    val modified = cursor.getLong(dateCol) * 1000L
                    val duration = cursor.getLong(durCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    results.add(
                        ShareableFile(
                            id = "video_$id",
                            name = name,
                            sizeBytes = size,
                            mimeType = mime,
                            category = FileCategory.VIDEOS,
                            uri = uri,
                            lastModified = modified,
                            durationMs = duration
                        )
                    )
                }
            }
        }
        return results
    }

    private fun loadMusic(): List<ShareableFile> {
        val results = mutableListOf<ShareableFile>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DURATION
        )
        runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val mime = cursor.getString(mimeCol) ?: "audio/mpeg"
                    val modified = cursor.getLong(dateCol) * 1000L
                    val duration = cursor.getLong(durCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    results.add(
                        ShareableFile(
                            id = "audio_$id",
                            name = name,
                            sizeBytes = size,
                            mimeType = mime,
                            category = FileCategory.MUSIC,
                            uri = uri,
                            lastModified = modified,
                            durationMs = duration
                        )
                    )
                }
            }
        }
        return results
    }

    private fun loadDocuments(): List<ShareableFile> {
        val results = mutableListOf<ShareableFile>()
        val docExtensions = setOf(
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
            "txt", "csv", "epub", "zip", "rar", "vcf"
        )
        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )
        runCatching {
            context.contentResolver.query(
                uri,
                projection,
                "${MediaStore.Files.FileColumns.SIZE} > 0",
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameCol) ?: continue
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (ext !in docExtensions) continue
                    val id = cursor.getLong(idCol)
                    val size = cursor.getLong(sizeCol)
                    val mime = cursor.getString(mimeCol) ?: Formatters.inferMimeType(name)
                    val modified = cursor.getLong(dateCol) * 1000L
                    val itemUri = ContentUris.withAppendedId(uri, id)
                    results.add(
                        ShareableFile(
                            id = "doc_$id",
                            name = name,
                            sizeBytes = size,
                            mimeType = mime,
                            category = FileCategory.DOCUMENTS,
                            uri = itemUri,
                            lastModified = modified
                        )
                    )
                }
            }
        }
        return results
    }

    private fun loadDownloads(): List<ShareableFile> {
        val results = mutableListOf<ShareableFile>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.MIME_TYPE,
                MediaStore.Downloads.DATE_MODIFIED
            )
            runCatching {
                context.contentResolver.query(
                    collection,
                    projection,
                    "${MediaStore.Downloads.SIZE} > 0",
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: continue
                        val size = cursor.getLong(sizeCol)
                        val mime = cursor.getString(mimeCol) ?: Formatters.inferMimeType(name)
                        val modified = cursor.getLong(dateCol) * 1000L
                        val itemUri = ContentUris.withAppendedId(collection, id)
                        results.add(
                            ShareableFile(
                                id = "dl_$id",
                                name = name,
                                sizeBytes = size,
                                mimeType = mime,
                                category = FileCategory.DOWNLOADS,
                                uri = itemUri,
                                lastModified = modified
                            )
                        )
                    }
                }
            }
        }
        if (results.isEmpty()) {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (downloadsDir.exists() && downloadsDir.isDirectory) {
                downloadsDir.listFiles()
                    ?.filter { it.isFile && it.length() > 0L }
                    ?.sortedByDescending { it.lastModified() }
                    ?.forEach { file ->
                        results.add(
                            ShareableFile(
                                id = "dl_file_${file.absolutePath.hashCode()}",
                                name = file.name,
                                sizeBytes = file.length(),
                                mimeType = Formatters.inferMimeType(file.name),
                                category = FileCategory.DOWNLOADS,
                                uri = Uri.fromFile(file),
                                filePath = file.absolutePath,
                                lastModified = file.lastModified()
                            )
                        )
                    }
            }
        }
        return results
    }
}
