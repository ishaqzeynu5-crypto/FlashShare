package com.flashshare.app.transfer

import android.content.Context
import android.content.Intent
import android.os.Build
import com.flashshare.app.R
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.IncomingTransferRequest
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.service.TransferForegroundService
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.CRC32
import javax.crypto.SecretKey
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val storageOrganizer: StorageOrganizer,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Internal mutable store + ordered IDs; flushed to StateFlow at max 5 Hz (every 200 ms)
    private val itemMap = ConcurrentHashMap<String, TransferItem>()
    private val itemOrder = CopyOnWriteArrayList<String>()
    private val uiDirty = AtomicBoolean(false)

    private val _transfers = MutableStateFlow<List<TransferItem>>(emptyList())
    val transfers: StateFlow<List<TransferItem>> = _transfers.asStateFlow()

    private val _isReceiveServerRunning = MutableStateFlow(false)
    val isReceiveServerRunning: StateFlow<Boolean> = _isReceiveServerRunning.asStateFlow()

    private val _activePort = MutableStateFlow(TransferProtocol.DEFAULT_PORT)
    val activePort: StateFlow<Int> = _activePort.asStateFlow()

    private val _sessionEncryptionKey = MutableStateFlow(CryptoHelper.generateKeyBase64())
    val sessionEncryptionKey: StateFlow<String> = _sessionEncryptionKey.asStateFlow()

    private val _pendingIncomingRequest = MutableStateFlow<IncomingTransferRequest?>(null)
    val pendingIncomingRequest: StateFlow<IncomingTransferRequest?> = _pendingIncomingRequest.asStateFlow()

    private val _lastReceivedVcfPath = MutableStateFlow<String?>(null)
    val lastReceivedVcfPath: StateFlow<String?> = _lastReceivedVcfPath.asStateFlow()

    private val pauseFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val cancelFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val batchApprovals = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val parallelProgressBytes = ConcurrentHashMap<String, AtomicLong>()
    private val parallelRangeTargetFiles = ConcurrentHashMap<String, File>()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    init {
        // Throttled 5 Hz UI publisher: avoids copying the full TransferItem list on every 512 KB chunk
        scope.launch {
            while (isActive) {
                delay(200L)
                if (uiDirty.compareAndSet(true, false)) {
                    publishSnapshot()
                }
            }
        }
    }

    fun startReceiveServer(preferredPort: Int = TransferProtocol.DEFAULT_PORT) {
        if (_isReceiveServerRunning.value) return
        _sessionEncryptionKey.value = CryptoHelper.generateKeyBase64()

        serverJob = scope.launch {
            var boundSocket: ServerSocket? = null
            var boundPort = preferredPort
            for (port in preferredPort..TransferProtocol.MAX_PORT_FALLBACK) {
                try {
                    boundSocket = ServerSocket().apply {
                        reuseAddress = true
                        receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                        bind(InetSocketAddress(port))
                    }
                    boundPort = port
                    break
                } catch (_: Exception) {
                    // Port busy; try next fallback port
                }
            }

            if (boundSocket == null) {
                _isReceiveServerRunning.value = false
                return@launch
            }

            serverSocket = boundSocket
            _activePort.value = boundPort
            _isReceiveServerRunning.value = true

            try {
                while (isActive && !boundSocket.isClosed) {
                    val client = try {
                        boundSocket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    launch { handleIncomingSocket(client) }
                }
            } finally {
                _isReceiveServerRunning.value = false
            }
        }
    }

    fun stopReceiveServer() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        _isReceiveServerRunning.value = false
    }

    fun respondToIncomingRequest(batchId: String, accept: Boolean, trustDevice: Boolean) {
        val current = _pendingIncomingRequest.value
        if (current != null && current.batchId == batchId) {
            _pendingIncomingRequest.value = null
            if (accept && trustDevice) {
                scope.launch { userPreferences.addTrustedDevice(current.senderId) }
            }
        }
        batchApprovals[batchId]?.complete(accept)
    }

    /**
     * High-speed V2 batch sender:
     * - Reuses ONE persistent TCP connection per worker across the entire batch.
     * - Uses up to 3 parallel TCP streams for multi-file batches (eliminating per-file handshake latency).
     * - Splits single large files (>= 32 MB) into 3 parallel byte-range streams.
     */
    fun sendFiles(
        targetIp: String,
        port: Int = TransferProtocol.DEFAULT_PORT,
        peerName: String,
        files: List<ShareableFile>,
        encryptionKeyBase64: String? = null
    ) {
        if (files.isEmpty()) return
        ensureForegroundService()

        val batchId = UUID.randomUUID().toString()
        val totalBatchBytes = files.sumOf { it.sizeBytes }

        val queuedPairs = files.map { file ->
            val id = UUID.randomUUID().toString()
            pauseFlags[id] = AtomicBoolean(false)
            cancelFlags[id] = AtomicBoolean(false)
            val item = TransferItem(
                id = id,
                fileName = file.name,
                sizeBytes = file.sizeBytes,
                mimeType = file.mimeType,
                category = file.category,
                direction = TransferDirection.SEND,
                status = TransferStatus.QUEUED,
                sourceUri = file.uri,
                localPath = file.filePath,
                peerName = peerName
            )
            upsertItem(item, immediate = false)
            file to item
        }
        publishSnapshot()

        scope.launch {
            val senderName = userPreferences.deviceName.first()
            val senderId = userPreferences.getOrCreateDeviceId()
            val useEncryption = userPreferences.encryptionEnabled.first() && !encryptionKeyBase64.isNullOrBlank()
            val secretKey = if (useEncryption) CryptoHelper.decodeKey(encryptionKeyBase64) else null

            // Single large file: split into 3 parallel byte-range streams
            if (queuedPairs.size == 1 &&
                queuedPairs[0].first.sizeBytes >= TransferProtocol.LARGE_FILE_PARALLEL_THRESHOLD &&
                !queuedPairs[0].first.filePath.isNullOrBlank()
            ) {
                val (file, item) = queuedPairs[0]
                sendLargeFileParallel(
                    targetIp = targetIp,
                    port = port,
                    batchId = batchId,
                    senderId = senderId,
                    senderName = senderName,
                    file = file,
                    item = item,
                    secretKey = secretKey
                )
                return@launch
            }

            // Multi-file batch: partition across up to 3 persistent TCP streams (or 1 for small batches)
            val workerCount = when {
                queuedPairs.size >= 6 -> TransferProtocol.PARALLEL_STREAMS_DEFAULT
                queuedPairs.size >= 2 -> 2
                else -> 1
            }
            val partitions = List(workerCount) { mutableListOf<Pair<ShareableFile, TransferItem>>() }
            queuedPairs.forEachIndexed { idx, pair ->
                partitions[idx % workerCount].add(pair)
            }

            coroutineScope {
                partitions.filter { it.isNotEmpty() }.map { workerBatch ->
                    async(Dispatchers.IO) {
                        sendBatchOnReusedSocket(
                            targetIp = targetIp,
                            port = port,
                            batchId = batchId,
                            senderId = senderId,
                            senderName = senderName,
                            totalFilesInBatch = queuedPairs.size,
                            totalBatchBytes = totalBatchBytes,
                            workerItems = workerBatch,
                            secretKey = secretKey
                        )
                    }
                }.awaitAll()
            }
        }
    }

    private suspend fun sendLargeFileParallel(
        targetIp: String,
        port: Int,
        batchId: String,
        senderId: String,
        senderName: String,
        file: ShareableFile,
        item: TransferItem,
        secretKey: SecretKey?
    ) {
        val streams = TransferProtocol.PARALLEL_STREAMS_DEFAULT
        val chunkSize = file.sizeBytes / streams
        val totalTransferred = AtomicLong(0L)
        val startMs = System.currentTimeMillis()
        updateItem(item.id, immediate = true) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }

        val anyFailed = AtomicBoolean(false)
        var failureMessage: String? = null

        coroutineScope {
            (0 until streams).map { index ->
                val rangeStart = index * chunkSize
                val rangeEnd = if (index == streams - 1) file.sizeBytes else (index + 1) * chunkSize
                val rangeLen = rangeEnd - rangeStart
                async(Dispatchers.IO) {
                    var socket: Socket? = null
                    try {
                        socket = createOptimizedSocket(targetIp, port)
                        val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
                        val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

                        var flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_CHUNKED_RANGE
                        if (secretKey != null) flags = flags or TransferProtocol.FLAG_ENCRYPTED

                        TransferProtocol.writeBatchHeaderV2(
                            dataOut,
                            TransferProtocol.BatchHeaderV2(
                                flags = flags,
                                batchId = batchId,
                                senderId = senderId,
                                senderName = senderName,
                                totalFilesInBatch = 1,
                                streamFileCount = 1,
                                totalBatchBytes = file.sizeBytes
                            )
                        )
                        val batchAck = TransferProtocol.readAck(dataIn)
                        if (batchAck.status != TransferProtocol.RESPONSE_OK) {
                            anyFailed.set(true)
                            failureMessage = if (batchAck.status == TransferProtocol.RESPONSE_REJECTED) {
                                context.getString(R.string.incoming_rejected_by_peer)
                            } else {
                                context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                            }
                            return@async
                        }

                        val iv = if (secretKey != null) CryptoHelper.generateBaseIv() else ByteArray(0)
                        TransferProtocol.writeFileHeaderV2(
                            dataOut,
                            TransferProtocol.FileHeaderV2(
                                transferId = item.id,
                                fileName = file.name,
                                mimeType = file.mimeType,
                                categoryName = file.category.name,
                                totalSizeBytes = file.sizeBytes,
                                rangeStart = rangeStart,
                                rangeLength = rangeLen,
                                baseIv = iv
                            )
                        )
                        val fileAck = TransferProtocol.readAck(dataIn)
                        if (fileAck.status != TransferProtocol.RESPONSE_OK) {
                            anyFailed.set(true)
                            failureMessage = context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                            return@async
                        }

                        val crc = streamRangeOut(
                            file = file,
                            transferId = item.id,
                            rangeStart = rangeStart,
                            rangeLength = rangeLen,
                            dataOut = dataOut,
                            secretKey = secretKey,
                            baseIv = iv
                        ) { delta ->
                            val nowTotal = totalTransferred.addAndGet(delta)
                            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                            val speed = (nowTotal * 1000L) / elapsed
                            val remaining = (file.sizeBytes - nowTotal).coerceAtLeast(0L)
                            val eta = if (speed > 0L) remaining / speed else -1L
                            updateItem(item.id, immediate = false) {
                                it.copy(
                                    transferredBytes = nowTotal.coerceAtMost(file.sizeBytes),
                                    speedBytesPerSec = speed,
                                    etaSeconds = eta,
                                    status = TransferStatus.RUNNING
                                )
                            }
                        }

                        dataOut.writeLong(crc)
                        dataOut.flush()
                        val verify = dataIn.readByte()
                        if (verify != TransferProtocol.VERIFY_OK) {
                            anyFailed.set(true)
                            failureMessage = context.getString(R.string.error_checksum_mismatch)
                        }
                    } catch (e: Exception) {
                        anyFailed.set(true)
                        failureMessage = e.message ?: context.getString(R.string.error_disconnected)
                    } finally {
                        runCatching { socket?.close() }
                    }
                }
            }.awaitAll()
        }

        val finalItem = when {
            cancelFlags[item.id]?.get() == true -> updateAndReturn(item.id, immediate = true) {
                it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
            }
            anyFailed.get() -> updateAndReturn(item.id, immediate = true) {
                it.copy(status = TransferStatus.FAILED, errorMessage = failureMessage, speedBytesPerSec = 0L, etaSeconds = -1L)
            }
            else -> updateAndReturn(item.id, immediate = true) {
                it.copy(transferredBytes = file.sizeBytes, status = TransferStatus.COMPLETED, speedBytesPerSec = 0L, etaSeconds = 0L)
            }
        }
        finalItem?.let { historyRepository.recordTransfer(it) }
    }

    private suspend fun sendBatchOnReusedSocket(
        targetIp: String,
        port: Int,
        batchId: String,
        senderId: String,
        senderName: String,
        totalFilesInBatch: Int,
        totalBatchBytes: Long,
        workerItems: List<Pair<ShareableFile, TransferItem>>,
        secretKey: SecretKey?
    ) {
        var socket: Socket? = null
        try {
            socket = createOptimizedSocket(targetIp, port)
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

            var flags = TransferProtocol.FLAG_BATCH
            if (secretKey != null) flags = flags or TransferProtocol.FLAG_ENCRYPTED

            TransferProtocol.writeBatchHeaderV2(
                dataOut,
                TransferProtocol.BatchHeaderV2(
                    flags = flags,
                    batchId = batchId,
                    senderId = senderId,
                    senderName = senderName,
                    totalFilesInBatch = totalFilesInBatch,
                    streamFileCount = workerItems.size,
                    totalBatchBytes = totalBatchBytes
                )
            )

            val batchAck = TransferProtocol.readAck(dataIn)
            if (batchAck.status != TransferProtocol.RESPONSE_OK) {
                val msg = if (batchAck.status == TransferProtocol.RESPONSE_REJECTED) {
                    context.getString(R.string.incoming_rejected_by_peer)
                } else {
                    context.getString(R.string.error_low_storage, Formatters.formatBytes(totalBatchBytes))
                }
                workerItems.forEach { (_, item) ->
                    val failed = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                }
                return
            }

            // Stream every file in this worker's partition sequentially over the SAME TCP socket
            for ((file, item) in workerItems) {
                if (cancelFlags[item.id]?.get() == true) {
                    val cancelled = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                    }
                    cancelled?.let { historyRepository.recordTransfer(it) }
                    continue
                }

                updateItem(item.id, immediate = true) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }

                val iv = if (secretKey != null) CryptoHelper.generateBaseIv() else ByteArray(0)
                TransferProtocol.writeFileHeaderV2(
                    dataOut,
                    TransferProtocol.FileHeaderV2(
                        transferId = item.id,
                        fileName = file.name,
                        mimeType = file.mimeType,
                        categoryName = file.category.name,
                        totalSizeBytes = file.sizeBytes,
                        rangeStart = 0L,
                        rangeLength = file.sizeBytes,
                        baseIv = iv
                    )
                )

                val fileAck = TransferProtocol.readAck(dataIn)
                if (fileAck.status == TransferProtocol.RESPONSE_LOW_STORAGE) {
                    val msg = context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                    val failed = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                    continue
                }
                if (fileAck.status != TransferProtocol.RESPONSE_OK) {
                    val cancelled = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L)
                    }
                    cancelled?.let { historyRepository.recordTransfer(it) }
                    continue
                }

                val resumeOffset = fileAck.offsetOrAvailableBytes.coerceIn(0L, file.sizeBytes)
                var sent = resumeOffset
                val startMs = System.currentTimeMillis()

                val crc = streamRangeOut(
                    file = file,
                    transferId = item.id,
                    rangeStart = resumeOffset,
                    rangeLength = file.sizeBytes - resumeOffset,
                    dataOut = dataOut,
                    secretKey = secretKey,
                    baseIv = iv
                ) { delta ->
                    sent += delta
                    val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                    val transferredNow = (sent - resumeOffset).coerceAtLeast(0L)
                    val speed = (transferredNow * 1000L) / elapsed
                    val remaining = (file.sizeBytes - sent).coerceAtLeast(0L)
                    val eta = if (speed > 0L) remaining / speed else -1L
                    updateItem(item.id, immediate = false) {
                        it.copy(
                            transferredBytes = sent.coerceAtMost(file.sizeBytes),
                            speedBytesPerSec = speed,
                            etaSeconds = eta,
                            status = TransferStatus.RUNNING
                        )
                    }
                }

                if (cancelFlags[item.id]?.get() == true) {
                    val cancelled = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                    }
                    cancelled?.let { historyRepository.recordTransfer(it) }
                    break
                }

                dataOut.writeLong(crc)
                dataOut.flush()
                val verify = dataIn.readByte()
                val doneItem = if (verify == TransferProtocol.VERIFY_OK) {
                    updateAndReturn(item.id, immediate = true) {
                        it.copy(
                            transferredBytes = file.sizeBytes,
                            status = TransferStatus.COMPLETED,
                            speedBytesPerSec = 0L,
                            etaSeconds = 0L
                        )
                    }
                } else {
                    updateAndReturn(item.id, immediate = true) {
                        it.copy(
                            status = TransferStatus.FAILED,
                            errorMessage = context.getString(R.string.error_checksum_mismatch),
                            speedBytesPerSec = 0L,
                            etaSeconds = -1L
                        )
                    }
                }
                doneItem?.let { historyRepository.recordTransfer(it) }
            }
        } catch (e: Exception) {
            val msg = e.message?.takeIf { it.isNotBlank() } ?: context.getString(R.string.error_disconnected)
            workerItems.forEach { (_, item) ->
                val current = itemMap[item.id]
                if (current != null &&
                    current.status != TransferStatus.COMPLETED &&
                    current.status != TransferStatus.CANCELLED
                ) {
                    val failed = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L, etaSeconds = -1L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                }
            }
        } finally {
            runCatching { socket?.close() }
        }
    }

    /**
     * Streams a byte range from either a local FileChannel (direct ByteBuffer) or ContentResolver InputStream.
     * Computes CRC32 incrementally and supports optional per-chunk AES-256-GCM encryption + pause/cancel.
     */
    private suspend fun streamRangeOut(
        file: ShareableFile,
        transferId: String,
        rangeStart: Long,
        rangeLength: Long,
        dataOut: DataOutputStream,
        secretKey: SecretKey?,
        baseIv: ByteArray,
        onBytesSent: (Long) -> Unit
    ): Long {
        val crc = CRC32()
        var remaining = rangeLength
        var chunkIndex = 0L

        val localFile = file.filePath?.let { File(it) }?.takeIf { it.exists() && it.canRead() }
        if (localFile != null) {
            FileInputStream(localFile).use { fis ->
                val channel = fis.channel
                if (rangeStart > 0L) channel.position(rangeStart)
                val directBuf = ByteBuffer.allocateDirect(TransferProtocol.BUFFER_SIZE)
                val staging = ByteArray(TransferProtocol.BUFFER_SIZE)

                while (remaining > 0L) {
                    if (awaitPauseOrCancel(transferId)) break
                    directBuf.clear()
                    val limit = minOf(TransferProtocol.BUFFER_SIZE.toLong(), remaining).toInt()
                    directBuf.limit(limit)
                    val read = channel.read(directBuf)
                    if (read <= 0) break
                    directBuf.flip()
                    directBuf.get(staging, 0, read)
                    crc.update(staging, 0, read)

                    if (secretKey != null) {
                        val enc = CryptoHelper.encryptChunk(secretKey, baseIv, chunkIndex++, staging, read)
                        dataOut.writeInt(enc.size)
                        dataOut.write(enc)
                    } else {
                        dataOut.write(staging, 0, read)
                    }
                    remaining -= read
                    onBytesSent(read.toLong())
                }
            }
        } else {
            val stream = context.contentResolver.openInputStream(file.uri)
                ?: throw IllegalStateException(context.getString(R.string.error_file_unreadable))
            stream.use { input ->
                if (rangeStart > 0L) skipFully(input, rangeStart)
                val buffer = ByteArray(TransferProtocol.BUFFER_SIZE)
                while (remaining > 0L) {
                    if (awaitPauseOrCancel(transferId)) break
                    val toRead = minOf(buffer.size.toLong(), remaining).toInt()
                    val read = input.read(buffer, 0, toRead)
                    if (read <= 0) break
                    crc.update(buffer, 0, read)

                    if (secretKey != null) {
                        val enc = CryptoHelper.encryptChunk(secretKey, baseIv, chunkIndex++, buffer, read)
                        dataOut.writeInt(enc.size)
                        dataOut.write(enc)
                    } else {
                        dataOut.write(buffer, 0, read)
                    }
                    remaining -= read
                    onBytesSent(read.toLong())
                }
            }
        }
        dataOut.flush()
        return crc.value
    }

    private suspend fun handleIncomingSocket(socket: Socket) {
        try {
            socket.tcpNoDelay = true
            socket.receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
            socket.soTimeout = 60_000

            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream(), TransferProtocol.BUFFER_SIZE))
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

            when (val version = TransferProtocol.readPreambleVersion(dataIn)) {
                TransferProtocol.PROTOCOL_VERSION_V1 -> handleIncomingV1(dataIn, dataOut)
                TransferProtocol.PROTOCOL_VERSION_V2 -> handleIncomingV2(dataIn, dataOut)
                else -> throw IllegalStateException("Unsupported protocol version: $version")
            }
        } catch (_: Exception) {
            // Connection closed or failed; per-item errors already recorded
        } finally {
            runCatching { socket.close() }
        }
    }

    private suspend fun handleIncomingV2(dataIn: DataInputStream, dataOut: DataOutputStream) {
        val batch = TransferProtocol.readBatchHeaderV2Body(dataIn)

        // Check trusted devices or prompt user once per batchId
        val approved = awaitBatchApproval(batch)
        if (!approved) {
            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_REJECTED, 0L)
            return
        }

        if (!storageOrganizer.hasEnoughSpace(batch.totalBatchBytes)) {
            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
            return
        }

        TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, 0L)
        ensureForegroundService()

        val secretKey = if (batch.isEncrypted) CryptoHelper.decodeKey(_sessionEncryptionKey.value) else null

        for (i in 0 until batch.streamFileCount) {
            val header = TransferProtocol.readFileHeaderV2(dataIn)
            val transferId = header.transferId.ifBlank { UUID.randomUUID().toString() }
            val category = runCatching { FileCategory.valueOf(header.categoryName) }
                .getOrElse { Formatters.inferCategory(header.fileName, header.mimeType) }

            val targetFile: File
            val resumeOffset: Long
            if (batch.isChunkedRange) {
                targetFile = parallelRangeTargetFiles.getOrPut(transferId) {
                    storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = false)
                }
                resumeOffset = header.rangeStart
            } else {
                val partial = storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = true)
                resumeOffset = if (partial.exists() && partial.length() < header.totalSizeBytes) partial.length() else 0L
                targetFile = if (resumeOffset > 0L) {
                    partial
                } else {
                    storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = false)
                }
            }

            val bytesToReceive = if (batch.isChunkedRange) {
                header.rangeLength
            } else {
                (header.totalSizeBytes - resumeOffset).coerceAtLeast(0L)
            }

            if (!storageOrganizer.hasEnoughSpace(bytesToReceive)) {
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
                continue
            }

            pauseFlags.putIfAbsent(transferId, AtomicBoolean(false))
            cancelFlags.putIfAbsent(transferId, AtomicBoolean(false))

            if (!itemMap.containsKey(transferId)) {
                upsertItem(
                    TransferItem(
                        id = transferId,
                        fileName = header.fileName,
                        sizeBytes = header.totalSizeBytes,
                        transferredBytes = if (batch.isChunkedRange) 0L else resumeOffset,
                        mimeType = header.mimeType,
                        category = category,
                        direction = TransferDirection.RECEIVE,
                        status = TransferStatus.RUNNING,
                        localPath = targetFile.absolutePath,
                        peerName = batch.senderName
                    ),
                    immediate = true
                )
            }

            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, resumeOffset)

            val crc = CRC32()
            val progressCounter = parallelProgressBytes.getOrPut(transferId) {
                AtomicLong(if (batch.isChunkedRange) 0L else resumeOffset)
            }
            val startMs = System.currentTimeMillis()
            val directBuf = ByteBuffer.allocateDirect(TransferProtocol.BUFFER_SIZE)
            val staging = ByteArray(TransferProtocol.BUFFER_SIZE)

            var receivedInRange = 0L
            var chunkIndex = 0L

            RandomAccessFile(targetFile, "rw").use { raf ->
                val channel = raf.channel
                var writePos = resumeOffset

                while (receivedInRange < bytesToReceive) {
                    if (awaitPauseOrCancel(transferId)) break

                    val plainBytes: ByteArray
                    val plainLen: Int
                    if (batch.isEncrypted && secretKey != null) {
                        val encLen = dataIn.readInt()
                        val encBuf = ByteArray(encLen)
                        dataIn.readFully(encBuf)
                        plainBytes = CryptoHelper.decryptChunk(secretKey, header.baseIv, chunkIndex++, encBuf)
                        plainLen = plainBytes.size
                    } else {
                        val toRead = minOf(staging.size.toLong(), bytesToReceive - receivedInRange).toInt()
                        val read = dataIn.read(staging, 0, toRead)
                        if (read <= 0) throw IllegalStateException(context.getString(R.string.error_disconnected))
                        plainBytes = staging
                        plainLen = read
                    }

                    crc.update(plainBytes, 0, plainLen)
                    directBuf.clear()
                    var offset = 0
                    while (offset < plainLen) {
                        val step = minOf(directBuf.capacity(), plainLen - offset)
                        directBuf.clear()
                        directBuf.put(plainBytes, offset, step)
                        directBuf.flip()
                        while (directBuf.hasRemaining()) {
                            writePos += channel.write(directBuf, writePos)
                        }
                        offset += step
                    }

                    receivedInRange += plainLen
                    val totalNow = progressCounter.addAndGet(plainLen.toLong())
                    val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                    val speed = (receivedInRange * 1000L) / elapsed
                    val remaining = (header.totalSizeBytes - totalNow).coerceAtLeast(0L)
                    val eta = if (speed > 0L) remaining / speed else -1L
                    updateItem(transferId, immediate = false) {
                        it.copy(
                            transferredBytes = totalNow.coerceAtMost(header.totalSizeBytes),
                            speedBytesPerSec = speed,
                            etaSeconds = eta,
                            status = TransferStatus.RUNNING
                        )
                    }
                }
            }

            if (cancelFlags[transferId]?.get() == true) {
                val cancelled = updateAndReturn(transferId, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
                return
            }

            val expectedCrc = dataIn.readLong()
            val crcMatches = (crc.value == expectedCrc)
            dataOut.writeByte(if (crcMatches) TransferProtocol.VERIFY_OK.toInt() else TransferProtocol.VERIFY_CRC_MISMATCH.toInt())
            dataOut.flush()

            if (!crcMatches) {
                val failed = updateAndReturn(transferId, immediate = true) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = context.getString(R.string.error_checksum_mismatch),
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
                failed?.let { historyRepository.recordTransfer(it) }
                continue
            }

            val finishedAllBytes = progressCounter.get() >= header.totalSizeBytes
            if (finishedAllBytes) {
                parallelRangeTargetFiles.remove(transferId)
                parallelProgressBytes.remove(transferId)
                storageOrganizer.scanReceivedFile(targetFile, header.mimeType)
                if (category == FileCategory.CONTACTS || targetFile.name.endsWith(".vcf", ignoreCase = true)) {
                    _lastReceivedVcfPath.value = targetFile.absolutePath
                }
                val completed = updateAndReturn(transferId, immediate = true) {
                    it.copy(
                        transferredBytes = header.totalSizeBytes,
                        status = TransferStatus.COMPLETED,
                        speedBytesPerSec = 0L,
                        etaSeconds = 0L,
                        localPath = targetFile.absolutePath
                    )
                }
                completed?.let { historyRepository.recordTransfer(it) }
            }
        }
    }

    /**
     * Backward-compatible Protocol V1 receiver handler.
     */
    private suspend fun handleIncomingV1(dataIn: DataInputStream, dataOut: DataOutputStream) {
        val header = TransferProtocol.readHeaderV1Body(dataIn)
        val transferId = header.transferId.ifBlank { UUID.randomUUID().toString() }
        val category = runCatching { FileCategory.valueOf(header.categoryName) }
            .getOrElse { Formatters.inferCategory(header.fileName, header.mimeType) }

        val partial = storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = true)
        val resumeOffset = if (partial.exists() && partial.length() < header.totalSizeBytes) partial.length() else 0L
        val targetFile = if (resumeOffset > 0L) {
            partial
        } else {
            storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = false)
        }

        val remainingNeeded = (header.totalSizeBytes - resumeOffset).coerceAtLeast(0L)
        if (!storageOrganizer.hasEnoughSpace(remainingNeeded)) {
            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
            return
        }

        pauseFlags[transferId] = AtomicBoolean(false)
        cancelFlags[transferId] = AtomicBoolean(false)
        ensureForegroundService()

        upsertItem(
            TransferItem(
                id = transferId,
                fileName = header.fileName,
                sizeBytes = header.totalSizeBytes,
                transferredBytes = resumeOffset,
                mimeType = header.mimeType,
                category = category,
                direction = TransferDirection.RECEIVE,
                status = TransferStatus.RUNNING,
                localPath = targetFile.absolutePath,
                peerName = header.senderName
            ),
            immediate = true
        )

        TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, resumeOffset)

        val startMs = System.currentTimeMillis()
        RandomAccessFile(targetFile, "rw").use { raf ->
            if (resumeOffset > 0L) raf.seek(resumeOffset)
            val buffer = ByteArray(TransferProtocol.BUFFER_SIZE)
            var receivedBytes = resumeOffset
            while (receivedBytes < header.totalSizeBytes) {
                if (awaitPauseOrCancel(transferId)) return
                val toRead = minOf(buffer.size.toLong(), header.totalSizeBytes - receivedBytes).toInt()
                val read = dataIn.read(buffer, 0, toRead)
                if (read == -1) throw IllegalStateException(context.getString(R.string.error_disconnected))
                raf.write(buffer, 0, read)
                receivedBytes += read
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                val speed = ((receivedBytes - resumeOffset) * 1000L) / elapsed
                val remaining = (header.totalSizeBytes - receivedBytes).coerceAtLeast(0L)
                val eta = if (speed > 0L) remaining / speed else -1L
                updateItem(transferId, immediate = false) {
                    it.copy(
                        transferredBytes = receivedBytes,
                        speedBytesPerSec = speed,
                        etaSeconds = eta,
                        status = TransferStatus.RUNNING
                    )
                }
            }
        }

        storageOrganizer.scanReceivedFile(targetFile, header.mimeType)
        if (category == FileCategory.CONTACTS || targetFile.name.endsWith(".vcf", ignoreCase = true)) {
            _lastReceivedVcfPath.value = targetFile.absolutePath
        }
        val completed = updateAndReturn(transferId, immediate = true) {
            it.copy(
                transferredBytes = header.totalSizeBytes,
                status = TransferStatus.COMPLETED,
                speedBytesPerSec = 0L,
                etaSeconds = 0L,
                localPath = targetFile.absolutePath
            )
        }
        completed?.let { historyRepository.recordTransfer(it) }
    }

    private suspend fun awaitBatchApproval(batch: TransferProtocol.BatchHeaderV2): Boolean {
        val trusted = userPreferences.trustedDevices.first()
        if (batch.senderId in trusted) return true

        val existing = batchApprovals[batch.batchId]
        if (existing != null) {
            return withTimeoutOrNull(60_000L) { existing.await() } ?: false
        }

        val deferred = CompletableDeferred<Boolean>()
        val prev = batchApprovals.putIfAbsent(batch.batchId, deferred)
        if (prev != null) {
            return withTimeoutOrNull(60_000L) { prev.await() } ?: false
        }

        _pendingIncomingRequest.value = IncomingTransferRequest(
            batchId = batch.batchId,
            senderId = batch.senderId,
            senderName = batch.senderName,
            fileCount = batch.totalFilesInBatch,
            totalBytes = batch.totalBatchBytes
        )
        val decision = withTimeoutOrNull(60_000L) { deferred.await() } ?: false
        if (_pendingIncomingRequest.value?.batchId == batch.batchId) {
            _pendingIncomingRequest.value = null
        }
        return decision
    }

    fun pauseTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        updateItem(transferId, immediate = true) { item ->
            if (item.status == TransferStatus.RUNNING || item.status == TransferStatus.QUEUED) {
                item.copy(status = TransferStatus.PAUSED, speedBytesPerSec = 0L, etaSeconds = -1L)
            } else {
                item
            }
        }
    }

    fun resumeTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(false)
        updateItem(transferId, immediate = true) { item ->
            if (item.status == TransferStatus.PAUSED) {
                item.copy(status = TransferStatus.RUNNING)
            } else {
                item
            }
        }
    }

    fun cancelTransfer(transferId: String) {
        cancelFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        pauseFlags[transferId]?.set(false)
        updateItem(transferId, immediate = true) {
            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
        }
    }

    fun cancelAllActive() {
        _transfers.value.forEach { item ->
            if (item.status == TransferStatus.RUNNING ||
                item.status == TransferStatus.QUEUED ||
                item.status == TransferStatus.PAUSED
            ) {
                cancelTransfer(item.id)
            }
        }
    }

    fun clearFinished() {
        val activeIds = itemOrder.filter { id ->
            val st = itemMap[id]?.status
            st == TransferStatus.RUNNING || st == TransferStatus.QUEUED || st == TransferStatus.PAUSED
        }
        val keepSet = activeIds.toSet()
        itemMap.keys.filterNot { it in keepSet }.forEach { itemMap.remove(it) }
        itemOrder.clear()
        itemOrder.addAll(activeIds)
        publishSnapshot()
    }

    fun clearLastReceivedVcf() {
        _lastReceivedVcfPath.value = null
    }

    private suspend fun awaitPauseOrCancel(transferId: String): Boolean {
        if (cancelFlags[transferId]?.get() == true) return true
        while (pauseFlags[transferId]?.get() == true) {
            if (cancelFlags[transferId]?.get() == true) return true
            delay(150L)
        }
        return cancelFlags[transferId]?.get() == true
    }

    private fun createOptimizedSocket(ip: String, port: Int): Socket {
        return Socket().apply {
            tcpNoDelay = true
            sendBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
            receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
            connect(InetSocketAddress(ip, port), 15_000)
            soTimeout = 60_000
        }
    }

    private fun skipFully(stream: InputStream, bytesToSkip: Long) {
        var remaining = bytesToSkip
        val discard = ByteArray(64 * 1024)
        while (remaining > 0L) {
            val skipped = stream.skip(remaining)
            if (skipped > 0L) {
                remaining -= skipped
            } else {
                val read = stream.read(discard, 0, minOf(discard.size.toLong(), remaining).toInt())
                if (read == -1) break
                remaining -= read
            }
        }
    }

    private fun upsertItem(item: TransferItem, immediate: Boolean) {
        if (!itemMap.containsKey(item.id)) {
            itemOrder.add(0, item.id)
        }
        itemMap[item.id] = item
        if (immediate) publishSnapshot() else uiDirty.set(true)
    }

    private fun updateItem(id: String, immediate: Boolean, transform: (TransferItem) -> TransferItem) {
        val prev = itemMap[id] ?: return
        itemMap[id] = transform(prev)
        if (immediate) publishSnapshot() else uiDirty.set(true)
    }

    private fun updateAndReturn(id: String, immediate: Boolean, transform: (TransferItem) -> TransferItem): TransferItem? {
        val prev = itemMap[id] ?: return null
        val next = transform(prev)
        itemMap[id] = next
        if (immediate) publishSnapshot() else uiDirty.set(true)
        return next
    }

    private fun publishSnapshot() {
        _transfers.value = itemOrder.mapNotNull { itemMap[it] }
    }

    private fun ensureForegroundService() {
        val intent = Intent(context, TransferForegroundService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
