package com.flashshare.app.transfer

import android.util.Base64
import java.nio.ByteBuffer
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * High-throughput per-session AES-256-GCM encryption helper.
 * Uses ThreadLocal Cipher reuse and pre-allocated output buffers (zero per-chunk GC allocations)
 * so 1 MB chunks stream at full 5 GHz Wi-Fi Direct speed.
 */
object CryptoHelper {
    private const val AES_KEY_BYTES = 32
    const val BASE_IV_BYTES = 12
    const val GCM_TAG_BYTES = 16
    private const val GCM_TAG_BITS = 128
    private val secureRandom = SecureRandom()

    private val threadCipher = ThreadLocal.withInitial {
        Cipher.getInstance("AES/GCM/NoPadding")
    }

    fun generateKeyBase64(): String {
        val key = ByteArray(AES_KEY_BYTES)
        secureRandom.nextBytes(key)
        return Base64.encodeToString(key, Base64.URL_SAFE or Base64.NO_WRAP)
    }

    fun decodeKey(base64: String?): SecretKey? {
        if (base64.isNullOrBlank()) return null
        return runCatching {
            val bytes = Base64.decode(base64, Base64.URL_SAFE or Base64.NO_WRAP)
            if (bytes.size != AES_KEY_BYTES) null else SecretKeySpec(bytes, "AES")
        }.getOrNull()
    }

    fun generateEcdhKeyPair(): KeyPair {
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"), secureRandom)
        return kpg.generateKeyPair()
    }

    fun deriveSharedAesKey(privateKey: PrivateKey, peerPublicKeyEncoded: ByteArray): SecretKey {
        val kf = KeyFactory.getInstance("EC")
        val peerPub = kf.generatePublic(X509EncodedKeySpec(peerPublicKeyEncoded))
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(privateKey)
        ka.doPhase(peerPub, true)
        val sharedSecret = ka.generateSecret()
        val digest = MessageDigest.getInstance("SHA-256").digest(sharedSecret)
        return SecretKeySpec(digest, "AES")
    }

    fun generateBaseIv(): ByteArray = ByteArray(BASE_IV_BYTES).also { secureRandom.nextBytes(it) }

    /**
     * Encrypts [plain] (0..[length]) directly into [outBuf] without allocating a new ByteArray.
     * Returns number of ciphertext bytes written.
     */
    fun encryptChunkInto(
        key: SecretKey,
        baseIv: ByteArray,
        chunkIndex: Long,
        plain: ByteArray,
        length: Int,
        outBuf: ByteArray,
        nonceScratch: ByteArray
    ): Int {
        deriveNonceInto(baseIv, chunkIndex, nonceScratch)
        val cipher = threadCipher.get()!!
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonceScratch))
        return cipher.doFinal(plain, 0, length, outBuf, 0)
    }

    /**
     * Decrypts [ciphertext] (0..[length]) directly into [outBuf] without allocating a new ByteArray.
     * Returns number of plaintext bytes written.
     */
    fun decryptChunkInto(
        key: SecretKey,
        baseIv: ByteArray,
        chunkIndex: Long,
        ciphertext: ByteArray,
        length: Int,
        outBuf: ByteArray,
        nonceScratch: ByteArray
    ): Int {
        deriveNonceInto(baseIv, chunkIndex, nonceScratch)
        val cipher = threadCipher.get()!!
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonceScratch))
        return cipher.doFinal(ciphertext, 0, length, outBuf, 0)
    }

    private fun deriveNonceInto(baseIv: ByteArray, chunkIndex: Long, outNonce: ByteArray) {
        System.arraycopy(baseIv, 0, outNonce, 0, BASE_IV_BYTES)
        for (i in 0 until 8) {
            val shift = (7 - i) * 8
            val idxByte = ((chunkIndex ushr shift) and 0xFFL).toInt()
            outNonce[4 + i] = (outNonce[4 + i].toInt() xor idxByte).toByte()
        }
    }
}
