package com.flashshare.app.transfer

import android.content.Context
import android.content.Intent
import android.os.Build
import com.flashshare.app.R
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.IncomingTransferRequest
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.network.WifiDirectManager
import com.flashshare.app.service.TransferForegroundService
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.CRC32
import javax.crypto.SecretKey
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val storageOrganizer: StorageOrganizer,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences,
    private val wifiDirectManager: WifiDirectManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val itemMap = ConcurrentHashMap<String, TransferItem>()
    private val itemOrder = CopyOnWriteArrayList<String>()
    private val uiDirty = AtomicBoolean(false)

    private val _transfers = MutableStateFlow<List<TransferItem>>(emptyList())
    val transfers: StateFlow<List<TransferItem>> = _transfers.asStateFlow()

    private val _isReceiveServerRunning = MutableStateFlow(false)
    val isReceiveServerRunning: StateFlow<Boolean> = _isReceiveServerRunning.asStateFlow()

    private val _activePort = MutableStateFlow(TransferProtocol.DEFAULT_PORT)
    val activePort: StateFlow<Int> = _activePort.asStateFlow()

    private val _sessionEncryptionKey = MutableStateFlow(CryptoHelper.generateKeyBase64())
    val sessionEncryptionKey: StateFlow<String> = _sessionEncryptionKey.asStateFlow()

    private val _pendingIncomingRequest = MutableStateFlow<IncomingTransferRequest?>(null)
    val pendingIncomingRequest: StateFlow<IncomingTransferRequest?> = _pendingIncomingRequest.asStateFlow()

    private val _lastReceivedVcfPath = MutableStateFlow<String?>(null)
    val lastReceivedVcfPath: StateFlow<String?> = _lastReceivedVcfPath.asStateFlow()

    // Files staged by the sender when hosting a "Show QR code" session
    @Volatile
    private var stagedQrSendFiles: List<ShareableFile> = emptyList()

    private val pauseFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val cancelFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val batchApprovals = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val parallelProgressBytes = ConcurrentHashMap<String, AtomicLong>()
    private val parallelRangeTargetFiles = ConcurrentHashMap<String, File>()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    init {
        scope.launch {
            while (isActive) {
                delay(200L)
                if (uiDirty.compareAndSet(true, false)) {
                    publishSnapshot()
                }
            }
        }
    }

    fun stageFilesForQrPull(files: List<ShareableFile>) {
        stagedQrSendFiles = files
    }

    fun startReceiveServer(preferredPort: Int = TransferProtocol.DEFAULT_PORT) {
        if (_isReceiveServerRunning.value) return
        _sessionEncryptionKey.value = CryptoHelper.generateKeyBase64()

        serverJob = scope.launch {
            var boundSocket: ServerSocket? = null
            var boundPort = preferredPort
            for (port in preferredPort..TransferProtocol.MAX_PORT_FALLBACK) {
                try {
                    boundSocket = ServerSocket().apply {
                        reuseAddress = true
                        receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                        bind(InetSocketAddress(port))
                    }
                    boundPort = port
                    break
                } catch (_: Exception) {
                    // Port busy; try fallback
                }
            }

            if (boundSocket == null) {
                _isReceiveServerRunning.value = false
                return@launch
            }

            serverSocket = boundSocket
            _activePort.value = boundPort
            _isReceiveServerRunning.value = true

            try {
                while (isActive && !boundSocket.isClosed) {
                    val client = try {
                        boundSocket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    launch { handleIncomingSocket(client) }
                }
            } finally {
                _isReceiveServerRunning.value = false
            }
        }
    }

    fun stopReceiveServer() {
        stagedQrSendFiles = emptyList()
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        _isReceiveServerRunning.value = false
    }

    fun respondToIncomingRequest(batchId: String, accept: Boolean, trustDevice: Boolean) {
        val current = _pendingIncomingRequest.value
        if (current != null && current.batchId == batchId) {
            _pendingIncomingRequest.value = null
            if (accept && trustDevice) {
                scope.launch { userPreferences.addTrustedDevice(current.senderId) }
            }
        }
        batchApprovals[batchId]?.complete(accept)
    }

    /**
     * Pulls files hosted by a sender who showed a "Send via QR" code (QrRole.SEND).
     * Encrypted end-to-end with the one-time AES-256-GCM key from the QR payload.
     */
    fun pullFilesFromSender(
        hostIp: String,
        port: Int,
        peerName: String,
        encryptionKeyBase64: String?
    ) {
        ensureForegroundService()
        scope.launch {
            var socket: Socket? = null
            try {
                socket = createOptimizedSocket(hostIp, port)
                val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
                val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream(), TransferProtocol.BUFFER_SIZE))

                val myName = userPreferences.deviceName.first()
                val myId = userPreferences.getOrCreateDeviceId()
                val qrKey = CryptoHelper.decodeKey(encryptionKeyBase64)
                var flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED or TransferProtocol.FLAG_PULL_FROM_SENDER
                if (qrKey == null) flags = flags or TransferProtocol.FLAG_ECDH_KEY_EXCHANGE

                TransferProtocol.writeBatchHeader(
                    dataOut,
                    TransferProtocol.PROTOCOL_VERSION_V3,
                    TransferProtocol.BatchHeaderV2(
                        flags = flags,
                        batchId = UUID.randomUUID().toString(),
                        senderId = myId,
                        senderName = myName,
                        totalFilesInBatch = 0,
                        streamFileCount = 0,
                        totalBatchBytes = 0L
                    )
                )

                val sessionKey: SecretKey = if (qrKey != null) {
                    qrKey
                } else {
                    val kp = CryptoHelper.generateEcdhKeyPair()
                    TransferProtocol.writeBytesFrame(dataOut, kp.public.encoded)
                    val peerPub = TransferProtocol.readBytesFrame(dataIn)
                    CryptoHelper.deriveSharedAesKey(kp.private, peerPub)
                }

                val fileCount = dataIn.readInt()
                val totalBatchBytes = dataIn.readLong()
                if (fileCount <= 0) return@launch

                if (!storageOrganizer.hasEnoughSpace(totalBatchBytes)) {
                    TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
                    return@launch
                }
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, 0L)

                receiveFilesLoop(
                    dataIn = dataIn,
                    dataOut = dataOut,
                    streamFileCount = fileCount,
                    peerName = peerName,
                    isChunkedRange = false,
                    secretKey = sessionKey
                )
            } catch (_: Exception) {
                // Error recorded per item
            } finally {
                runCatching { socket?.close() }
            }
        }
    }

    /**
     * High-speed V3 batch sender — EVERY transfer is encrypted with AES-256-GCM
     * (either via QR one-time key or ephemeral ECDH P-256 key exchange).
     */
    fun sendFiles(
        targetIp: String,
        port: Int = TransferProtocol.DEFAULT_PORT,
        peerName: String,
        files: List<ShareableFile>,
        encryptionKeyBase64: String? = null
    ) {
        if (files.isEmpty()) return
        ensureForegroundService()

        val batchId = UUID.randomUUID().toString()
        val totalBatchBytes = files.sumOf { it.sizeBytes }

        val queuedPairs = files.map { file ->
            val id = UUID.randomUUID().toString()
            pauseFlags[id] = AtomicBoolean(false)
            cancelFlags[id] = AtomicBoolean(false)
            val item = TransferItem(
                id = id,
                fileName = file.name,
                sizeBytes = file.sizeBytes,
                mimeType = file.mimeType,
                category = file.category,
                direction = TransferDirection.SEND,
                status = TransferStatus.QUEUED,
                sourceUri = file.uri,
                localPath = file.filePath,
                peerName = peerName
            )
            upsertItem(item, immediate = false)
            file to item
        }
        publishSnapshot()

        scope.launch {
            val senderName = userPreferences.deviceName.first()
            val senderId = userPreferences.getOrCreateDeviceId()
            val qrKey = CryptoHelper.decodeKey(encryptionKeyBase64)

            if (queuedPairs.size == 1 &&
                queuedPairs[0].first.sizeBytes >= TransferProtocol.LARGE_FILE_PARALLEL_THRESHOLD &&
                !queuedPairs[0].first.filePath.isNullOrBlank()
            ) {
                val (file, item) = queuedPairs[0]
                sendLargeFileParallel(
                    targetIp = targetIp,
                    port = port,
                    batchId = batchId,
                    senderId = senderId,
                    senderName = senderName,
                    file = file,
                    item = item,
                    qrKey = qrKey
                )
                return@launch
            }

            val workerCount = when {
                queuedPairs.size >= 6 -> TransferProtocol.PARALLEL_STREAMS_DEFAULT
                queuedPairs.size >= 2 -> 2
                else -> 1
            }
            val partitions = List(workerCount) { mutableListOf<Pair<ShareableFile, TransferItem>>() }
            queuedPairs.forEachIndexed { idx, pair ->
                partitions[idx % workerCount].add(pair)
            }

            coroutineScope {
                partitions.filter { it.isNotEmpty() }.map { workerBatch ->
                    async(Dispatchers.IO) {
                        sendBatchOnReusedSocket(
                            targetIp = targetIp,
                            port = port,
                            batchId = batchId,
                            senderId = senderId,
                            senderName = senderName,
                            totalFilesInBatch = queuedPairs.size,
                            totalBatchBytes = totalBatchBytes,
                            workerItems = workerBatch,
                            qrKey = qrKey
                        )
                    }
                }.awaitAll()
            }
        }
    }

    private suspend fun sendLargeFileParallel(
        targetIp: String,
        port: Int,
        batchId: String,
        senderId: String,
        senderName: String,
        file: ShareableFile,
        item: TransferItem,
        qrKey: SecretKey?
    ) {
        val streams = TransferProtocol.PARALLEL_STREAMS_DEFAULT
        val chunkSize = file.sizeBytes / streams
        val totalTransferred = AtomicLong(0L)
        val startMs = System.currentTimeMillis()
        updateItem(item.id, immediate = true) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }

        val anyFailed = AtomicBoolean(false)
        var failureMessage: String? = null

        coroutineScope {
            (0 until streams).map { index ->
                val rangeStart = index * chunkSize
                val rangeEnd = if (index == streams - 1) file.sizeBytes else (index + 1) * chunkSize
                val rangeLen = rangeEnd - rangeStart
                async(Dispatchers.IO) {
                    var socket: Socket? = null
                    try {
                        socket = createOptimizedSocket(targetIp, port)
                        val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
                        val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

                        var flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_CHUNKED_RANGE or TransferProtocol.FLAG_ENCRYPTED
                        if (qrKey == null) flags = flags or TransferProtocol.FLAG_ECDH_KEY_EXCHANGE

                        TransferProtocol.writeBatchHeader(
                            dataOut,
                            TransferProtocol.PROTOCOL_VERSION_V3,
                            TransferProtocol.BatchHeaderV2(
                                flags = flags,
                                batchId = batchId,
                                senderId = senderId,
                                senderName = senderName,
                                totalFilesInBatch = 1,
                                streamFileCount = 1,
                                totalBatchBytes = file.sizeBytes
                            )
                        )

                        val sessionKey: SecretKey = if (qrKey != null) {
                            qrKey
                        } else {
                            val kp = CryptoHelper.generateEcdhKeyPair()
                            TransferProtocol.writeBytesFrame(dataOut, kp.public.encoded)
                            val peerPub = TransferProtocol.readBytesFrame(dataIn)
                            CryptoHelper.deriveSharedAesKey(kp.private, peerPub)
                        }

                        val batchAck = TransferProtocol.readAck(dataIn)
                        if (batchAck.status != TransferProtocol.RESPONSE_OK) {
                            anyFailed.set(true)
                            failureMessage = if (batchAck.status == TransferProtocol.RESPONSE_REJECTED) {
                                context.getString(R.string.incoming_rejected_by_peer)
                            } else {
                                context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                            }
                            return@async
                        }

                        val iv = CryptoHelper.generateBaseIv()
                        TransferProtocol.writeFileHeaderV2(
                            dataOut,
                            TransferProtocol.FileHeaderV2(
                                transferId = item.id,
                                fileName = file.name,
                                mimeType = file.mimeType,
                                categoryName = file.category.name,
                                totalSizeBytes = file.sizeBytes,
                                rangeStart = rangeStart,
                                rangeLength = rangeLen,
                                baseIv = iv
                            )
                        )
                        val fileAck = TransferProtocol.readAck(dataIn)
                        if (fileAck.status != TransferProtocol.RESPONSE_OK) {
                            anyFailed.set(true)
                            failureMessage = context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                            return@async
                        }

                        val crc = streamRangeOut(
                            file = file,
                            transferId = item.id,
                            rangeStart = rangeStart,
                            rangeLength = rangeLen,
                            dataOut = dataOut,
                            secretKey = sessionKey,
                            baseIv = iv
                        ) { delta ->
                            val nowTotal = totalTransferred.addAndGet(delta)
                            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                            val speed = (nowTotal * 1000L) / elapsed
                            val remaining = (file.sizeBytes - nowTotal).coerceAtLeast(0L)
                            val eta = if (speed > 0L) remaining / speed else -1L
                            updateItem(item.id, immediate = false) {
                                it.copy(
                                    transferredBytes = nowTotal.coerceAtMost(file.sizeBytes),
                                    speedBytesPerSec = speed,
                                    etaSeconds = eta,
                                    status = TransferStatus.RUNNING
                                )
                            }
                        }

                        dataOut.writeLong(crc)
                        dataOut.flush()
                        if (dataIn.readByte() != TransferProtocol.VERIFY_OK) {
                            anyFailed.set(true)
                            failureMessage = context.getString(R.string.error_checksum_mismatch)
                        }
                    } catch (e: Exception) {
                        anyFailed.set(true)
                        failureMessage = e.message ?: context.getString(R.string.error_disconnected)
                    } finally {
                        runCatching { socket?.close() }
                    }
                }
            }.awaitAll()
        }

        val finalItem = when {
            cancelFlags[item.id]?.get() == true -> updateAndReturn(item.id, immediate = true) {
                it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
            }
            anyFailed.get() -> updateAndReturn(item.id, immediate = true) {
                it.copy(status = TransferStatus.FAILED, errorMessage = failureMessage, speedBytesPerSec = 0L, etaSeconds = -1L)
            }
            else -> updateAndReturn(item.id, immediate = true) {
                it.copy(transferredBytes = file.sizeBytes, status = TransferStatus.COMPLETED, speedBytesPerSec = 0L, etaSeconds = 0L)
            }
        }
        finalItem?.let { historyRepository.recordTransfer(it) }
    }

    private suspend fun sendBatchOnReusedSocket(
        targetIp: String,
        port: Int,
        batchId: String,
        senderId: String,
        senderName: String,
        totalFilesInBatch: Int,
        totalBatchBytes: Long,
        workerItems: List<Pair<ShareableFile, TransferItem>>,
        qrKey: SecretKey?
    ) {
        var socket: Socket? = null
        try {
            socket = createOptimizedSocket(targetIp, port)
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

            var flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED
            if (qrKey == null) flags = flags or TransferProtocol.FLAG_ECDH_KEY_EXCHANGE

            TransferProtocol.writeBatchHeader(
                dataOut,
                TransferProtocol.PROTOCOL_VERSION_V3,
                TransferProtocol.BatchHeaderV2(
                    flags = flags,
                    batchId = batchId,
                    senderId = senderId,
                    senderName = senderName,
                    totalFilesInBatch = totalFilesInBatch,
                    streamFileCount = workerItems.size,
                    totalBatchBytes = totalBatchBytes
                )
            )

            val sessionKey: SecretKey = if (qrKey != null) {
                qrKey
            } else {
                val kp = CryptoHelper.generateEcdhKeyPair()
                TransferProtocol.writeBytesFrame(dataOut, kp.public.encoded)
                val peerPub = TransferProtocol.readBytesFrame(dataIn)
                CryptoHelper.deriveSharedAesKey(kp.private, peerPub)
            }

            val batchAck = TransferProtocol.readAck(dataIn)
            if (batchAck.status != TransferProtocol.RESPONSE_OK) {
                val msg = if (batchAck.status == TransferProtocol.RESPONSE_REJECTED) {
                    context.getString(R.string.incoming_rejected_by_peer)
                } else {
                    context.getString(R.string.error_low_storage, Formatters.formatBytes(totalBatchBytes))
                }
                workerItems.forEach { (_, item) ->
                    val failed = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                }
                return
            }

            streamFilesLoop(dataOut, dataIn, workerItems, sessionKey)
        } catch (e: Exception) {
            val msg = e.message?.takeIf { it.isNotBlank() } ?: context.getString(R.string.error_disconnected)
            workerItems.forEach { (_, item) ->
                val current = itemMap[item.id]
                if (current != null &&
                    current.status != TransferStatus.COMPLETED &&
                    current.status != TransferStatus.CANCELLED
                ) {
                    val failed = updateAndReturn(item.id, immediate = true) {
                        it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L, etaSeconds = -1L)
                    }
                    failed?.let { historyRepository.recordTransfer(it) }
                }
            }
        } finally {
            runCatching { socket?.close() }
        }
    }

    private suspend fun streamFilesLoop(
        dataOut: DataOutputStream,
        dataIn: DataInputStream,
        workerItems: List<Pair<ShareableFile, TransferItem>>,
        sessionKey: SecretKey
    ) {
        for ((file, item) in workerItems) {
            if (cancelFlags[item.id]?.get() == true) {
                val cancelled = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
                continue
            }

            updateItem(item.id, immediate = true) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }

            val iv = CryptoHelper.generateBaseIv()
            TransferProtocol.writeFileHeaderV2(
                dataOut,
                TransferProtocol.FileHeaderV2(
                    transferId = item.id,
                    fileName = file.name,
                    mimeType = file.mimeType,
                    categoryName = file.category.name,
                    totalSizeBytes = file.sizeBytes,
                    rangeStart = 0L,
                    rangeLength = file.sizeBytes,
                    baseIv = iv
                )
            )

            val fileAck = TransferProtocol.readAck(dataIn)
            if (fileAck.status == TransferProtocol.RESPONSE_LOW_STORAGE) {
                val msg = context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                val failed = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L)
                }
                failed?.let { historyRepository.recordTransfer(it) }
                continue
            }
            if (fileAck.status != TransferProtocol.RESPONSE_OK) {
                val cancelled = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
                continue
            }

            val resumeOffset = fileAck.offsetOrAvailableBytes.coerceIn(0L, file.sizeBytes)
            var sent = resumeOffset
            val startMs = System.currentTimeMillis()

            val crc = streamRangeOut(
                file = file,
                transferId = item.id,
                rangeStart = resumeOffset,
                rangeLength = file.sizeBytes - resumeOffset,
                dataOut = dataOut,
                secretKey = sessionKey,
                baseIv = iv
            ) { delta ->
                sent += delta
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                val transferredNow = (sent - resumeOffset).coerceAtLeast(0L)
                val speed = (transferredNow * 1000L) / elapsed
                val remaining = (file.sizeBytes - sent).coerceAtLeast(0L)
                val eta = if (speed > 0L) remaining / speed else -1L
                updateItem(item.id, immediate = false) {
                    it.copy(
                        transferredBytes = sent.coerceAtMost(file.sizeBytes),
                        speedBytesPerSec = speed,
                        etaSeconds = eta,
                        status = TransferStatus.RUNNING
                    )
                }
            }

            if (cancelFlags[item.id]?.get() == true) {
                val cancelled = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
                break
            }

            dataOut.writeLong(crc)
            dataOut.flush()
            val verify = dataIn.readByte()
            val doneItem = if (verify == TransferProtocol.VERIFY_OK) {
                updateAndReturn(item.id, immediate = true) {
                    it.copy(
                        transferredBytes = file.sizeBytes,
                        status = TransferStatus.COMPLETED,
                        speedBytesPerSec = 0L,
                        etaSeconds = 0L
                    )
                }
            } else {
                updateAndReturn(item.id, immediate = true) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = context.getString(R.string.error_checksum_mismatch),
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
            }
            doneItem?.let { historyRepository.recordTransfer(it) }
        }
    }

    private suspend fun streamRangeOut(
        file: ShareableFile,
        transferId: String,
        rangeStart: Long,
        rangeLength: Long,
        dataOut: DataOutputStream,
        secretKey: SecretKey?,
        baseIv: ByteArray,
        onBytesSent: (Long) -> Unit
    ): Long {
        val crc = CRC32()
        var remaining = rangeLength
        var chunkIndex = 0L

        val plainBuf = ByteArray(TransferProtocol.BUFFER_SIZE)
        val encOutBuf = if (secretKey != null) ByteArray(TransferProtocol.BUFFER_SIZE + CryptoHelper.GCM_TAG_BYTES + 32) else ByteArray(0)
        val nonceScratch = ByteArray(CryptoHelper.BASE_IV_BYTES)

        val localFile = file.filePath?.let { File(it) }?.takeIf { it.exists() && it.canRead() }
        if (localFile != null) {
            FileInputStream(localFile).use { fis ->
                val channel = fis.channel
                if (rangeStart > 0L) channel.position(rangeStart)
                val wrapped = ByteBuffer.wrap(plainBuf)

                while (remaining > 0L) {
                    if (awaitPauseOrCancel(transferId)) break
                    wrapped.clear()
                    val limit = minOf(TransferProtocol.BUFFER_SIZE.toLong(), remaining).toInt()
                    wrapped.limit(limit)
                    val read = channel.read(wrapped)
                    if (read <= 0) break
                    crc.update(plainBuf, 0, read)

                    if (secretKey != null) {
                        val encLen = CryptoHelper.encryptChunkInto(
                            secretKey, baseIv, chunkIndex++, plainBuf, read, encOutBuf, nonceScratch
                        )
                        dataOut.writeInt(encLen)
                        dataOut.write(encOutBuf, 0, encLen)
                    } else {
                        dataOut.write(plainBuf, 0, read)
                    }
                    remaining -= read
                    onBytesSent(read.toLong())
                }
            }
        } else {
            val stream = context.contentResolver.openInputStream(file.uri)
                ?: throw IllegalStateException(context.getString(R.string.error_file_unreadable))
            stream.use { input ->
                if (rangeStart > 0L) skipFully(input, rangeStart)
                while (remaining > 0L) {
                    if (awaitPauseOrCancel(transferId)) break
                    val toRead = minOf(plainBuf.size.toLong(), remaining).toInt()
                    val read = input.read(plainBuf, 0, toRead)
                    if (read <= 0) break
                    crc.update(plainBuf, 0, read)

                    if (secretKey != null) {
                        val encLen = CryptoHelper.encryptChunkInto(
                            secretKey, baseIv, chunkIndex++, plainBuf, read, encOutBuf, nonceScratch
                        )
                        dataOut.writeInt(encLen)
                        dataOut.write(encOutBuf, 0, encLen)
                    } else {
                        dataOut.write(plainBuf, 0, read)
                    }
                    remaining -= read
                    onBytesSent(read.toLong())
                }
            }
        }
        dataOut.flush()
        return crc.value
    }

    private suspend fun handleIncomingSocket(socket: Socket) {
        try {
            socket.tcpNoDelay = true
            socket.receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
            socket.soTimeout = 60_000

            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream(), TransferProtocol.BUFFER_SIZE))
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

            when (val version = TransferProtocol.readPreambleVersion(dataIn)) {
                TransferProtocol.PROTOCOL_VERSION_V1 -> handleIncomingV1(dataIn, dataOut)
                TransferProtocol.PROTOCOL_VERSION_V2 -> handleIncomingV2OrV3(dataIn, dataOut, isV3 = false)
                TransferProtocol.PROTOCOL_VERSION_V3 -> handleIncomingV2OrV3(dataIn, dataOut, isV3 = true)
                else -> throw IllegalStateException("Unsupported protocol version: $version")
            }
        } catch (_: Exception) {
            // Errors recorded per item
        } finally {
            runCatching { socket.close() }
        }
    }

    private suspend fun handleIncomingV2OrV3(dataIn: DataInputStream, dataOut: DataOutputStream, isV3: Boolean) {
        val batch = TransferProtocol.readBatchHeaderBody(dataIn)

        val sessionKey: SecretKey? = when {
            isV3 && batch.usesEcdh -> {
                val peerPub = TransferProtocol.readBytesFrame(dataIn)
                val kp = CryptoHelper.generateEcdhKeyPair()
                TransferProtocol.writeBytesFrame(dataOut, kp.public.encoded)
                CryptoHelper.deriveSharedAesKey(kp.private, peerPub)
            }
            batch.isEncrypted -> CryptoHelper.decodeKey(_sessionEncryptionKey.value)
            else -> null
        }

        // Sender-hosted QR pull request: the peer scanned our "Show QR code" and is pulling our staged files
        if (isV3 && batch.isPullRequest) {
            val files = stagedQrSendFiles
            dataOut.writeInt(files.size)
            dataOut.writeLong(files.sumOf { it.sizeBytes })
            dataOut.flush()
            if (files.isEmpty() || sessionKey == null) return

            val ack = TransferProtocol.readAck(dataIn)
            if (ack.status != TransferProtocol.RESPONSE_OK) return

            ensureForegroundService()
            val pairs = files.map { f ->
                val id = UUID.randomUUID().toString()
                pauseFlags[id] = AtomicBoolean(false)
                cancelFlags[id] = AtomicBoolean(false)
                val item = TransferItem(
                    id = id,
                    fileName = f.name,
                    sizeBytes = f.sizeBytes,
                    mimeType = f.mimeType,
                    category = f.category,
                    direction = TransferDirection.SEND,
                    status = TransferStatus.QUEUED,
                    sourceUri = f.uri,
                    localPath = f.filePath,
                    peerName = batch.senderName
                )
                upsertItem(item, immediate = false)
                f to item
            }
            publishSnapshot()
            streamFilesLoop(dataOut, dataIn, pairs, sessionKey)
            return
        }

        val approved = awaitBatchApproval(batch)
        if (!approved) {
            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_REJECTED, 0L)
            return
        }

        if (!storageOrganizer.hasEnoughSpace(batch.totalBatchBytes)) {
            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
            return
        }

        TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, 0L)
        ensureForegroundService()

        receiveFilesLoop(
            dataIn = dataIn,
            dataOut = dataOut,
            streamFileCount = batch.streamFileCount,
            peerName = batch.senderName,
            isChunkedRange = batch.isChunkedRange,
            secretKey = sessionKey
        )
    }

    private suspend fun receiveFilesLoop(
        dataIn: DataInputStream,
        dataOut: DataOutputStream,
        streamFileCount: Int,
        peerName: String,
        isChunkedRange: Boolean,
        secretKey: SecretKey?
    ) {
        for (i in 0 until streamFileCount) {
            val header = TransferProtocol.readFileHeaderV2(dataIn)
            val transferId = header.transferId.ifBlank { UUID.randomUUID().toString() }
            val category = runCatching { FileCategory.valueOf(header.categoryName) }
                .getOrElse { Formatters.inferCategory(header.fileName, header.mimeType) }

            val targetFile: File
            val resumeOffset: Long
            if (isChunkedRange) {
                targetFile = parallelRangeTargetFiles.getOrPut(transferId) {
                    storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = false)
                }
                resumeOffset = header.rangeStart
            } else {
                val partial = storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = true)
                resumeOffset = if (partial.exists() && partial.length() < header.totalSizeBytes) partial.length() else 0L
                targetFile = if (resumeOffset > 0L) {
                    partial
                } else {
                    storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = false)
                }
            }

            val bytesToReceive = if (isChunkedRange) {
                header.rangeLength
            } else {
                (header.totalSizeBytes - resumeOffset).coerceAtLeast(0L)
            }

            if (!storageOrganizer.hasEnoughSpace(bytesToReceive)) {
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
                continue
            }

            pauseFlags.putIfAbsent(transferId, AtomicBoolean(false))
            cancelFlags.putIfAbsent(transferId, AtomicBoolean(false))

            if (!itemMap.containsKey(transferId)) {
                upsertItem(
                    TransferItem(
                        id = transferId,
                        fileName = header.fileName,
                        sizeBytes = header.totalSizeBytes,
                        transferredBytes = if (isChunkedRange) 0L else resumeOffset,
                        mimeType = header.mimeType,
                        category = category,
                        direction = TransferDirection.RECEIVE,
                        status = TransferStatus.RUNNING,
                        localPath = targetFile.absolutePath,
                        peerName = peerName
                    ),
                    immediate = true
                )
            }

            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, resumeOffset)

            val crc = CRC32()
            val progressCounter = parallelProgressBytes.getOrPut(transferId) {
                AtomicLong(if (isChunkedRange) 0L else resumeOffset)
            }
            val startMs = System.currentTimeMillis()
            var encInBuf = ByteArray(TransferProtocol.BUFFER_SIZE + CryptoHelper.GCM_TAG_BYTES + 32)
            val plainOutBuf = ByteArray(TransferProtocol.BUFFER_SIZE + 64)
            val nonceScratch = ByteArray(CryptoHelper.BASE_IV_BYTES)

            var receivedInRange = 0L
            var chunkIndex = 0L

            RandomAccessFile(targetFile, "rw").use { raf ->
                val channel = raf.channel
                var writePos = resumeOffset

                while (receivedInRange < bytesToReceive) {
                    if (awaitPauseOrCancel(transferId)) break

                    val plainLen: Int
                    if (secretKey != null) {
                        val encLen = dataIn.readInt()
                        if (encLen > encInBuf.size) encInBuf = ByteArray(encLen)
                        dataIn.readFully(encInBuf, 0, encLen)
                        plainLen = CryptoHelper.decryptChunkInto(
                            secretKey, header.baseIv, chunkIndex++, encInBuf, encLen, plainOutBuf, nonceScratch
                        )
                    } else {
                        val toRead = minOf(plainOutBuf.size.toLong(), bytesToReceive - receivedInRange).toInt()
                        val read = dataIn.read(plainOutBuf, 0, toRead)
                        if (read <= 0) throw IllegalStateException(context.getString(R.string.error_disconnected))
                        plainLen = read
                    }

                    crc.update(plainOutBuf, 0, plainLen)
                    val writeBuf = ByteBuffer.wrap(plainOutBuf, 0, plainLen)
                    while (writeBuf.hasRemaining()) {
                        writePos += channel.write(writeBuf, writePos)
                    }

                    receivedInRange += plainLen
                    val totalNow = progressCounter.addAndGet(plainLen.toLong())
                    val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                    val speed = (receivedInRange * 1000L) / elapsed
                    val remaining = (header.totalSizeBytes - totalNow).coerceAtLeast(0L)
                    val eta = if (speed > 0L) remaining / speed else -1L
                    updateItem(transferId, immediate = false) {
                        it.copy(
                            transferredBytes = totalNow.coerceAtMost(header.totalSizeBytes),
                            speedBytesPerSec = speed,
                            etaSeconds = eta,
                            status = TransferStatus.RUNNING
                        )
                    }
                }
            }

            if (cancelFlags[transferId]?.get() == true) {
                val cancelled = updateAndReturn(transferId, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cancelled?.let { historyRepository.recordTransfer(it) }
                return
            }

            val expectedCrc = dataIn.readLong()
            val crcMatches = (crc.value == expectedCrc)
            dataOut.writeByte(if (crcMatches) TransferProtocol.VERIFY_OK.toInt() else TransferProtocol.VERIFY_CRC_MISMATCH.toInt())
            dataOut.flush()

            if (!crcMatches) {
                val failed = updateAndReturn(transferId, immediate = true) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = context.getString(R.string.error_checksum_mismatch),
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
                failed?.let { historyRepository.recordTransfer(it) }
                continue
            }

            if (progressCounter.get() >= header.totalSizeBytes) {
                parallelRangeTargetFiles.remove(transferId)
                parallelProgressBytes.remove(transferId)
                storageOrganizer.scanReceivedFile(targetFile, header.mimeType)
                if (category == FileCategory.CONTACTS || targetFile.name.endsWith(".vcf", ignoreCase = true)) {
                    _lastReceivedVcfPath.value = targetFile.absolutePath
                }
                val completed = updateAndReturn(transferId, immediate = true) {
                    it.copy(
                        transferredBytes = header.totalSizeBytes,
                        status = TransferStatus.COMPLETED,
                        speedBytesPerSec = 0L,
                        etaSeconds = 0L,
                        localPath = targetFile.absolutePath
                    )
                }
                completed?.let { historyRepository.recordTransfer(it) }
            }
        }
    }

    private suspend fun handleIncomingV1(dataIn: DataInputStream, dataOut: DataOutputStream) {
        val header = TransferProtocol.readHeaderV1Body(dataIn)
        val transferId = header.transferId.ifBlank { UUID.randomUUID().toString() }
        val category = runCatching { FileCategory.valueOf(header.categoryName) }
            .getOrElse { Formatters.inferCategory(header.fileName, header.mimeType) }

        val partial = storageOrganizer.resolveTargetFile(header.fileName, category, allowResumeExisting = true)
        val resumeOffset = if (partial.exists() && partial.length() < header.totalSizeBytes) partial.length() else 0L
        val targetFile = if (resumeOffset > 0L) partial else storageOrganizer.resolveTargetFile(header.fileName, category, false)

        val remainingNeeded = (header.totalSizeBytes - resumeOffset).coerceAtLeast(0L)
        if (!storageOrganizer.hasEnoughSpace(remainingNeeded)) {
            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
            return
        }

        pauseFlags[transferId] = AtomicBoolean(false)
        cancelFlags[transferId] = AtomicBoolean(false)
        ensureForegroundService()

        upsertItem(
            TransferItem(
                id = transferId,
                fileName = header.fileName,
                sizeBytes = header.totalSizeBytes,
                transferredBytes = resumeOffset,
                mimeType = header.mimeType,
                category = category,
                direction = TransferDirection.RECEIVE,
                status = TransferStatus.RUNNING,
                localPath = targetFile.absolutePath,
                peerName = header.senderName
            ),
            immediate = true
        )
        TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, resumeOffset)

        val startMs = System.currentTimeMillis()
        RandomAccessFile(targetFile, "rw").use { raf ->
            if (resumeOffset > 0L) raf.seek(resumeOffset)
            val buffer = ByteArray(TransferProtocol.BUFFER_SIZE)
            var receivedBytes = resumeOffset
            while (receivedBytes < header.totalSizeBytes) {
                if (awaitPauseOrCancel(transferId)) return
                val toRead = minOf(buffer.size.toLong(), header.totalSizeBytes - receivedBytes).toInt()
                val read = dataIn.read(buffer, 0, toRead)
                if (read == -1) throw IllegalStateException(context.getString(R.string.error_disconnected))
                raf.write(buffer, 0, read)
                receivedBytes += read
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                val speed = ((receivedBytes - resumeOffset) * 1000L) / elapsed
                val remaining = (header.totalSizeBytes - receivedBytes).coerceAtLeast(0L)
                val eta = if (speed > 0L) remaining / speed else -1L
                updateItem(transferId, immediate = false) {
                    it.copy(
                        transferredBytes = receivedBytes,
                        speedBytesPerSec = speed,
                        etaSeconds = eta,
                        status = TransferStatus.RUNNING
                    )
                }
            }
        }

        storageOrganizer.scanReceivedFile(targetFile, header.mimeType)
        if (category == FileCategory.CONTACTS || targetFile.name.endsWith(".vcf", ignoreCase = true)) {
            _lastReceivedVcfPath.value = targetFile.absolutePath
        }
        val completed = updateAndReturn(transferId, immediate = true) {
            it.copy(
                transferredBytes = header.totalSizeBytes,
                status = TransferStatus.COMPLETED,
                speedBytesPerSec = 0L,
                etaSeconds = 0L,
                localPath = targetFile.absolutePath
            )
        }
        completed?.let { historyRepository.recordTransfer(it) }
    }

    private suspend fun awaitBatchApproval(batch: TransferProtocol.BatchHeaderV2): Boolean {
        val trusted = userPreferences.trustedDevices.first()
        if (batch.senderId in trusted) return true

        val existing = batchApprovals[batch.batchId]
        if (existing != null) {
            return withTimeoutOrNull(60_000L) { existing.await() } ?: false
        }

        val deferred = CompletableDeferred<Boolean>()
        val prev = batchApprovals.putIfAbsent(batch.batchId, deferred)
        if (prev != null) {
            return withTimeoutOrNull(60_000L) { prev.await() } ?: false
        }

        _pendingIncomingRequest.value = IncomingTransferRequest(
            batchId = batch.batchId,
            senderId = batch.senderId,
            senderName = batch.senderName,
            fileCount = batch.totalFilesInBatch,
            totalBytes = batch.totalBatchBytes
        )
        val decision = withTimeoutOrNull(60_000L) { deferred.await() } ?: false
        if (_pendingIncomingRequest.value?.batchId == batch.batchId) {
            _pendingIncomingRequest.value = null
        }
        batchApprovals.remove(batch.batchId)
        return decision
    }

    fun pauseTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        updateItem(transferId, immediate = true) { item ->
            if (item.status == TransferStatus.RUNNING || item.status == TransferStatus.QUEUED) {
                item.copy(status = TransferStatus.PAUSED, speedBytesPerSec = 0L, etaSeconds = -1L)
            } else item
        }
    }

    fun resumeTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(false)
        updateItem(transferId, immediate = true) { item ->
            if (item.status == TransferStatus.PAUSED) item.copy(status = TransferStatus.RUNNING) else item
        }
    }

    fun cancelTransfer(transferId: String) {
        cancelFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        pauseFlags[transferId]?.set(false)
        updateItem(transferId, immediate = true) {
            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
        }
    }

    fun pauseAllActive() {
        _transfers.value.forEach {
            if (it.status == TransferStatus.RUNNING || it.status == TransferStatus.QUEUED) pauseTransfer(it.id)
        }
    }

    fun resumeAllPaused() {
        _transfers.value.forEach {
            if (it.status == TransferStatus.PAUSED) resumeTransfer(it.id)
        }
    }

    fun cancelAllActive() {
        _transfers.value.forEach { item ->
            if (item.status == TransferStatus.RUNNING ||
                item.status == TransferStatus.QUEUED ||
                item.status == TransferStatus.PAUSED
            ) {
                cancelTransfer(item.id)
            }
        }
    }

    fun clearFinished() {
        val activeIds = itemOrder.filter { id ->
            val st = itemMap[id]?.status
            st == TransferStatus.RUNNING || st == TransferStatus.QUEUED || st == TransferStatus.PAUSED
        }
        val keepSet = activeIds.toSet()
        itemMap.keys.filterNot { it in keepSet }.forEach { itemMap.remove(it) }
        itemOrder.clear()
        itemOrder.addAll(activeIds)
        publishSnapshot()
    }

    fun clearLastReceivedVcf() {
        _lastReceivedVcfPath.value = null
    }

    private suspend fun awaitPauseOrCancel(transferId: String): Boolean {
        if (cancelFlags[transferId]?.get() == true) return true
        while (pauseFlags[transferId]?.get() == true) {
            if (cancelFlags[transferId]?.get() == true) return true
            delay(150L)
        }
        return cancelFlags[transferId]?.get() == true
    }

    private fun createOptimizedSocket(ip: String, port: Int): Socket {
        var lastError: Exception? = null
        val preferredNet = wifiDirectManager.getPreferredTransferNetwork()
        for (attempt in 1..3) {
            val socket = try {
                if (preferredNet != null && attempt <= 2) {
                    preferredNet.socketFactory.createSocket()
                } else {
                    Socket()
                }
            } catch (_: Exception) {
                Socket()
            }
            try {
                socket.tcpNoDelay = true
                socket.sendBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                socket.receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                socket.connect(InetSocketAddress(ip, port), 12_000)
                socket.soTimeout = 60_000
                return socket
            } catch (e: Exception) {
                lastError = e
                runCatching { socket.close() }
                if (attempt < 3) {
                    try { Thread.sleep(800L) } catch (_: InterruptedException) { break }
                }
            }
        }
        throw lastError ?: IllegalStateException(context.getString(R.string.error_disconnected))
    }

    private fun skipFully(stream: InputStream, bytesToSkip: Long) {
        var remaining = bytesToSkip
        val discard = ByteArray(64 * 1024)
        while (remaining > 0L) {
            val skipped = stream.skip(remaining)
            if (skipped > 0L) remaining -= skipped
            else {
                val read = stream.read(discard, 0, minOf(discard.size.toLong(), remaining).toInt())
                if (read == -1) break
                remaining -= read
            }
        }
    }

    private fun upsertItem(item: TransferItem, immediate: Boolean) {
        if (!itemMap.containsKey(item.id)) itemOrder.add(0, item.id)
        itemMap[item.id] = item
        if (immediate) publishSnapshot() else uiDirty.set(true)
    }

    private fun updateItem(id: String, immediate: Boolean, transform: (TransferItem) -> TransferItem) {
        val prev = itemMap[id] ?: return
        itemMap[id] = transform(prev)
        if (immediate) publishSnapshot() else uiDirty.set(true)
    }

    private fun updateAndReturn(id: String, immediate: Boolean, transform: (TransferItem) -> TransferItem): TransferItem? {
        val prev = itemMap[id] ?: return null
        val next = transform(prev)
        itemMap[id] = next
        if (immediate) publishSnapshot() else uiDirty.set(true)
        return next
    }

    private fun publishSnapshot() {
        _transfers.value = itemOrder.mapNotNull { itemMap[it] }
    }

    private fun ensureForegroundService() {
        val intent = Intent(context, TransferForegroundService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
