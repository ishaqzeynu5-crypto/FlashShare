package com.flashshare.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.flashshare.app.R

val BgBlack = Color(0xFF0A0A0B)
val SurfaceDark = Color(0xFF151618)
val SurfaceContainerDark = Color(0xFF1E1F23)
val OutlineSubtle = Color(0xFF2A2C31)
val OutlineStrong = Color(0xFF4A4D55)
val TextPrimary = Color(0xFFF2F3F5)
val TextSecondary = Color(0xFF9AA0AA)

private val MonochromeDarkScheme = darkColorScheme(
    primary = TextPrimary,
    onPrimary = BgBlack,
    primaryContainer = SurfaceContainerDark,
    onPrimaryContainer = TextPrimary,
    secondary = SurfaceContainerDark,
    onSecondary = TextPrimary,
    secondaryContainer = SurfaceDark,
    onSecondaryContainer = TextPrimary,
    tertiary = TextPrimary,
    onTertiary = BgBlack,
    background = BgBlack,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceContainerDark,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = SurfaceContainerDark,
    surfaceContainerLow = SurfaceDark,
    surfaceContainerHigh = SurfaceContainerDark,
    outline = OutlineStrong,
    outlineVariant = OutlineSubtle,
    error = TextPrimary,
    onError = BgBlack
)

val FlashShareFontFamily = FontFamily(
    Font(R.font.noto_sans_regular, FontWeight.Normal),
    Font(R.font.noto_sans_bold, FontWeight.Bold)
)

private val baseTypography = Typography()

val FlashShareTypography = Typography(
    displayLarge = baseTypography.displayLarge.copy(fontFamily = FlashShareFontFamily),
    displayMedium = baseTypography.displayMedium.copy(fontFamily = FlashShareFontFamily),
    displaySmall = baseTypography.displaySmall.copy(fontFamily = FlashShareFontFamily),
    headlineLarge = baseTypography.headlineLarge.copy(fontFamily = FlashShareFontFamily),
    headlineMedium = baseTypography.headlineMedium.copy(fontFamily = FlashShareFontFamily),
    headlineSmall = baseTypography.headlineSmall.copy(fontFamily = FlashShareFontFamily),
    titleLarge = baseTypography.titleLarge.copy(fontFamily = FlashShareFontFamily),
    titleMedium = baseTypography.titleMedium.copy(fontFamily = FlashShareFontFamily),
    titleSmall = baseTypography.titleSmall.copy(fontFamily = FlashShareFontFamily),
    bodyLarge = baseTypography.bodyLarge.copy(fontFamily = FlashShareFontFamily),
    bodyMedium = baseTypography.bodyMedium.copy(fontFamily = FlashShareFontFamily),
    bodySmall = baseTypography.bodySmall.copy(fontFamily = FlashShareFontFamily),
    labelLarge = baseTypography.labelLarge.copy(fontFamily = FlashShareFontFamily),
    labelMedium = baseTypography.labelMedium.copy(fontFamily = FlashShareFontFamily),
    labelSmall = baseTypography.labelSmall.copy(fontFamily = FlashShareFontFamily)
)

@Composable
fun FlashShareTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MonochromeDarkScheme,
        typography = FlashShareTypography,
        content = content
    )
}
