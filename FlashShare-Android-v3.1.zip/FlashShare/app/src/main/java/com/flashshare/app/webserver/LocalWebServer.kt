package com.flashshare.app.webserver

import android.content.Context
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLEncoder
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton

data class WebServerState(
    val isRunning: Boolean = false,
    val url: String = "",
    val qrUrl: String = "",
    val pin: String = "",
    val remainingTimeoutSeconds: Long = 0L,
    val sharedFiles: List<ShareableFile> = emptyList(),
    val error: String? = null
)

/**
 * Pure-Kotlin local HTTP/1.1 server for Share via Browser:
 * - Protected by a 6-digit one-time Access PIN (embedded in QR or entered in browser)
 * - Auto-stops after 15 minutes of inactivity
 * - Streams >4 GB files with HTTP 206 Range support
 */
@Singleton
class LocalWebServer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val INACTIVITY_TIMEOUT_SECONDS = 15L * 60L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val random = SecureRandom()
    private val lastActivityMs = AtomicLong(System.currentTimeMillis())

    private val _state = MutableStateFlow(WebServerState())
    val state: StateFlow<WebServerState> = _state.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var timeoutJob: Job? = null

    fun setSharedFiles(files: List<ShareableFile>) {
        _state.value = _state.value.copy(sharedFiles = files)
    }

    fun start(preferredPort: Int = 8080) {
        if (_state.value.isRunning) return
        val generatedPin = (100_000 + random.nextInt(900_000)).toString()
        lastActivityMs.set(System.currentTimeMillis())

        serverJob = scope.launch {
            val ip = Formatters.getLocalIpAddress() ?: "127.0.0.1"
            var boundSocket: ServerSocket? = null
            var boundPort = preferredPort

            for (port in preferredPort..(preferredPort + 10)) {
                try {
                    boundSocket = ServerSocket().apply {
                        reuseAddress = true
                        bind(InetSocketAddress(port))
                    }
                    boundPort = port
                    break
                } catch (_: Exception) {
                    // Try next port
                }
            }

            if (boundSocket == null) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    error = "Could not bind local port $preferredPort"
                )
                return@launch
            }

            serverSocket = boundSocket
            val baseUrl = "http://$ip:$boundPort"
            val qrUrl = "$baseUrl/?pin=$generatedPin"
            _state.value = _state.value.copy(
                isRunning = true,
                url = baseUrl,
                qrUrl = qrUrl,
                pin = generatedPin,
                remainingTimeoutSeconds = INACTIVITY_TIMEOUT_SECONDS,
                error = null
            )

            startTimeoutWatcher()

            try {
                while (isActive && !boundSocket.isClosed) {
                    val client = try {
                        boundSocket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    launch { handleHttpClient(client, generatedPin) }
                }
            } finally {
                _state.value = _state.value.copy(isRunning = false, remainingTimeoutSeconds = 0L)
            }
        }
    }

    fun stop() {
        timeoutJob?.cancel()
        timeoutJob = null
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        _state.value = _state.value.copy(
            isRunning = false,
            url = "",
            qrUrl = "",
            pin = "",
            remainingTimeoutSeconds = 0L
        )
    }

    private fun startTimeoutWatcher() {
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            while (isActive && _state.value.isRunning) {
                delay(1_000L)
                val idleSec = (System.currentTimeMillis() - lastActivityMs.get()) / 1000L
                val remaining = (INACTIVITY_TIMEOUT_SECONDS - idleSec).coerceAtLeast(0L)
                _state.value = _state.value.copy(remainingTimeoutSeconds = remaining)
                if (remaining == 0L) {
                    stop()
                    break
                }
            }
        }
    }

    private fun handleHttpClient(socket: Socket, expectedPin: String) {
        try {
            socket.soTimeout = 30_000
            socket.tcpNoDelay = true
            socket.sendBufferSize = 2 * 1024 * 1024
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val rawTarget = parts[1]
            val path = rawTarget.substringBefore("?")
            val query = rawTarget.substringAfter("?", "")

            val headers = mutableMapOf<String, String>()
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) break
                val idx = line.indexOf(':')
                if (idx > 0) {
                    headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
                }
            }

            val out = BufferedOutputStream(socket.getOutputStream(), 512 * 1024)
            if (method != "GET" && method != "HEAD") {
                sendSimpleResponse(out, 405, "Method Not Allowed", "text/plain", "Method Not Allowed")
                return
            }

            val queryPin = extractQueryParam(query, "pin")
            val cookieAuthorized = headers["cookie"]?.contains("fs_pin=$expectedPin") == true
            val pinValid = (queryPin == expectedPin) || cookieAuthorized

            if (!pinValid) {
                val html = buildPinPromptHtml(wrongPin = !queryPin.isNullOrBlank())
                sendSimpleResponse(out, 200, "OK", "text/html; charset=utf-8", html)
                return
            }

            lastActivityMs.set(System.currentTimeMillis())
            val setCookie = if (queryPin == expectedPin) "Set-Cookie: fs_pin=$expectedPin; Path=/; HttpOnly\r\n" else ""

            when {
                path == "/" || path == "/index.html" -> {
                    val html = buildIndexHtml(_state.value.sharedFiles, expectedPin)
                    sendSimpleResponse(out, 200, "OK", "text/html; charset=utf-8", html, setCookie)
                }
                path.startsWith("/download/") -> {
                    val index = path.removePrefix("/download/").toIntOrNull()
                    val files = _state.value.sharedFiles
                    if (index == null || index !in files.indices) {
                        sendSimpleResponse(out, 404, "Not Found", "text/plain", "File not found")
                    } else {
                        streamFileResponse(out, files[index], headers["range"], method == "HEAD")
                    }
                }
                else -> {
                    sendSimpleResponse(out, 404, "Not Found", "text/plain", "Not Found")
                }
            }
        } catch (_: Exception) {
            // Client disconnected
        } finally {
            runCatching { socket.close() }
        }
    }

    private fun extractQueryParam(query: String, key: String): String? {
        if (query.isBlank()) return null
        return query.split("&")
            .mapNotNull { kv ->
                val pair = kv.split("=", limit = 2)
                if (pair.size == 2 && pair[0] == key) pair[1] else null
            }
            .firstOrNull()
    }

    private fun sendSimpleResponse(
        out: BufferedOutputStream,
        code: Int,
        reason: String,
        contentType: String,
        body: String,
        extraHeaders: String = ""
    ) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val header = buildString {
            append("HTTP/1.1 $code $reason\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            append(extraHeaders)
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(bytes)
        out.flush()
    }

    private fun streamFileResponse(
        out: BufferedOutputStream,
        file: ShareableFile,
        rangeHeader: String?,
        headOnly: Boolean
    ) {
        val totalSize = file.sizeBytes
        var start = 0L
        var end = (totalSize - 1L).coerceAtLeast(0L)
        var isPartial = false

        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(",")
            val bounds = rangeSpec.split("-")
            val parsedStart = bounds.getOrNull(0)?.toLongOrNull()
            val parsedEnd = bounds.getOrNull(1)?.toLongOrNull()
            if (parsedStart != null && parsedStart in 0L until totalSize) {
                start = parsedStart
                end = (parsedEnd ?: (totalSize - 1L)).coerceIn(start, totalSize - 1L)
                isPartial = true
            }
        }

        val contentLength = (end - start + 1L).coerceAtLeast(0L)
        val encodedName = URLEncoder.encode(file.name, "UTF-8").replace("+", "%20")
        val statusLine = if (isPartial) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"

        val headers = buildString {
            append("$statusLine\r\n")
            append("Content-Type: ${file.mimeType}\r\n")
            append("Content-Length: $contentLength\r\n")
            append("Accept-Ranges: bytes\r\n")
            if (isPartial) {
                append("Content-Range: bytes $start-$end/$totalSize\r\n")
            }
            append("Content-Disposition: attachment; filename*=UTF-8''$encodedName\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(headers.toByteArray(Charsets.US_ASCII))
        out.flush()
        if (headOnly) return

        val stream = if (!file.filePath.isNullOrBlank() && File(file.filePath).canRead()) {
            FileInputStream(File(file.filePath))
        } else {
            context.contentResolver.openInputStream(file.uri)
        } ?: return

        stream.use { input ->
            if (start > 0L) {
                var toSkip = start
                val discard = ByteArray(64 * 1024)
                while (toSkip > 0L) {
                    val skipped = input.skip(toSkip)
                    if (skipped > 0L) toSkip -= skipped
                    else {
                        val read = input.read(discard, 0, minOf(discard.size.toLong(), toSkip).toInt())
                        if (read == -1) break
                        toSkip -= read
                    }
                }
            }
            val buffer = ByteArray(512 * 1024)
            var remaining = contentLength
            while (remaining > 0L) {
                val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read == -1) break
                out.write(buffer, 0, read)
                remaining -= read
                lastActivityMs.set(System.currentTimeMillis())
            }
            out.flush()
        }
    }

    private fun buildPinPromptHtml(wrongPin: Boolean): String {
        val errHtml = if (wrongPin) "<p class='err'>Incorrect PIN. Check the PIN shown on FlashShare.</p>" else ""
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>FlashShare — Enter PIN</title>
                <style>
                    body { font-family: system-ui, sans-serif; margin: 0; padding: 24px; background: #0A0A0B; color: #F2F3F5; display: flex; justify-content: center; align-items: center; min-height: 90vh; }
                    .box { width: 100%; max-width: 380px; background: #151618; border: 1px solid #2A2C31; border-radius: 20px; padding: 24px; }
                    h1 { margin: 0 0 8px; font-size: 1.4rem; }
                    p { color: #9AA0AA; font-size: 0.92rem; margin: 0 0 18px; }
                    input { width: 100%; box-sizing: border-box; padding: 14px; font-size: 1.2rem; letter-spacing: 4px; text-align: center; background: #1E1F23; color: #F2F3F5; border: 1px solid #4A4D55; border-radius: 12px; margin-bottom: 14px; }
                    button { width: 100%; padding: 14px; font-size: 1rem; font-weight: 600; background: #F2F3F5; color: #0A0A0B; border: none; border-radius: 12px; cursor: pointer; }
                    .err { color: #F2F3F5; background: #1E1F23; border: 1px solid #4A4D55; padding: 10px; border-radius: 10px; }
                </style>
            </head>
            <body>
                <form class="box" method="GET" action="/">
                    <h1>FlashShare</h1>
                    <p>Enter the 6-digit PIN shown on the sending phone.</p>
                    $errHtml
                    <input name="pin" type="tel" maxlength="6" placeholder="000000" required autofocus />
                    <button type="submit">Unlock files</button>
                </form>
            </body>
            </html>
        """.trimIndent()
    }

    private fun buildIndexHtml(files: List<ShareableFile>, pin: String): String {
        val itemsHtml = if (files.isEmpty()) {
            "<p class='empty'>No files selected on the host phone.</p>"
        } else {
            files.mapIndexed { index, file ->
                val safeName = escapeHtml(file.name)
                val sizeStr = Formatters.formatBytes(file.sizeBytes)
                val catStr = file.category.folderName
                """
                <div class="card">
                    <div class="info">
                        <div class="name">$safeName</div>
                        <div class="meta">$catStr &bull; $sizeStr</div>
                    </div>
                    <a class="btn" href="/download/$index?pin=$pin">Download</a>
                </div>
                """.trimIndent()
            }.joinToString("\n")
        }

        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>FlashShare — Browser Download</title>
                <style>
                    body { font-family: system-ui, sans-serif; margin: 0; padding: 20px; background: #0A0A0B; color: #F2F3F5; }
                    .container { max-width: 720px; margin: 0 auto; }
                    header { margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #2A2C31; }
                    h1 { margin: 0 0 6px; font-size: 1.5rem; }
                    p.sub { margin: 0; color: #9AA0AA; font-size: 0.92rem; }
                    .card { display: flex; align-items: center; justify-content: space-between; gap: 12px; background: #151618; border: 1px solid #2A2C31; padding: 14px 16px; border-radius: 18px; margin-bottom: 12px; }
                    .info { min-width: 0; flex: 1; }
                    .name { font-weight: 600; word-break: break-word; margin-bottom: 4px; }
                    .meta { font-size: 0.82rem; color: #9AA0AA; }
                    .btn { display: inline-block; background: #F2F3F5; color: #0A0A0B; text-decoration: none; padding: 10px 16px; border-radius: 10px; font-weight: 600; white-space: nowrap; }
                    .empty { text-align: center; color: #9AA0AA; padding: 40px 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <header>
                        <h1>FlashShare</h1>
                        <p class="sub">Offline local transfer &bull; ${files.size} file(s)</p>
                    </header>
                    $itemsHtml
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    private fun escapeHtml(text: String): String =
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
}
