package com.flashshare.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.network.WifiDirectState
import com.flashshare.app.qr.QrCodeGenerator
import com.flashshare.app.qr.QrScannerView
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.ui.components.RadarAnimationView
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.ui.permissions.PermissionRationaleDialog
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineStrong
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceContainerDark
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SendRadarScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onShowQrClick: () -> Unit,
    onScanQrClick: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val context = LocalContext.current
    val peers by viewModel.nearbyPeers.collectAsState()
    val wifiState by viewModel.wifiDirectState.collectAsState()
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val isWifiEnabled by viewModel.isWifiP2pEnabled.collectAsState()
    val deviceName by viewModel.deviceName.collectAsState()

    var hasNearbyPerm by remember {
        mutableStateOf(PermissionHelper.hasAll(context, PermissionHelper.nearbyPermissions()))
    }
    var showPermissionDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasNearbyPerm = grants.values.all { it }
        if (hasNearbyPerm) {
            viewModel.startNearbyDiscovery()
        }
    }

    LaunchedEffect(wifiState, selectedFiles) {
        if (wifiState is WifiDirectState.Connected && selectedFiles.isNotEmpty()) {
            if (viewModel.sendSelectedFiles()) {
                onOpenTransfers()
            }
        }
    }

    LaunchedEffect(Unit) {
        val required = PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()
        if (PermissionHelper.hasAll(context, required)) {
            hasNearbyPerm = true
            viewModel.startNearbyDiscovery()
        }
    }

    if (showPermissionDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_nearby_title),
            description = stringResource(R.string.perm_nearby_desc),
            onGrantClick = {
                showPermissionDialog = false
                permissionLauncher.launch(
                    (PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()).distinct().toTypedArray()
                )
            },
            onOpenSettingsClick = {
                showPermissionDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = { showPermissionDialog = false }
        )
    }

    Scaffold(
        containerColor = BgBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
                title = { Text(stringResource(R.string.radar_title), color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.startNearbyDiscovery() }, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = stringResource(R.string.action_refresh),
                            tint = TextPrimary
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Inline guidance when Wi-Fi or permission is off
                if (!isWifiEnabled) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        border = BorderStroke(1.dp, OutlineStrong),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.radar_wifi_off_guidance),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                } else if (!hasNearbyPerm) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        border = BorderStroke(1.dp, OutlineStrong),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.radar_perm_off_guidance),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f).padding(end = 10.dp)
                            )
                            OutlinedButton(
                                onClick = { showPermissionDialog = true },
                                border = BorderStroke(1.dp, OutlineStrong),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(stringResource(R.string.action_grant), color = TextPrimary)
                            }
                        }
                    }
                }

                RadarAnimationView(
                    avatarLabel = deviceName,
                    isScanning = wifiState is WifiDirectState.Discovering || wifiState is WifiDirectState.Idle
                )

                val statusLabel = when (val st = wifiState) {
                    is WifiDirectState.Connecting -> stringResource(R.string.radar_connecting, st.targetName)
                    is WifiDirectState.Connected -> stringResource(R.string.radar_connected_to, st.peerName)
                    is WifiDirectState.Error -> st.message
                    else -> stringResource(R.string.radar_searching)
                }
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )

                // Discovered nearby devices as circular avatars
                if (peers.isEmpty()) {
                    Text(
                        text = stringResource(R.string.radar_no_devices),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        text = stringResource(R.string.radar_tap_to_connect),
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        peers.forEach { peer ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(84.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { viewModel.connectToPeer(peer) }
                                    .padding(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(SurfaceContainerDark, CircleShape)
                                        .border(1.5.dp, OutlineStrong, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = peer.deviceName.take(1).uppercase(),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = peer.deviceName,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom QR buttons: Show QR code & Scan QR code (always reachable!)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onShowQrClick,
                    border = BorderStroke(1.dp, OutlineStrong),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 52.dp)
                ) {
                    Text(stringResource(R.string.action_show_qr), color = TextPrimary)
                }
                Button(
                    onClick = onScanQrClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TextPrimary,
                        contentColor = BgBlack
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 52.dp)
                ) {
                    Text(stringResource(R.string.action_scan_qr), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrHubScreen(
    viewModel: MainViewModel,
    initialShowTab: Boolean,
    onBack: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val context = LocalContext.current
    val wifiState by viewModel.wifiDirectState.collectAsState()
    val isServerRunning by viewModel.isReceiveServerRunning.collectAsState()
    val activePort by viewModel.activePort.collectAsState()
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val lastVcfPath by viewModel.lastReceivedVcfPath.collectAsState()
    val pendingPull by viewModel.pendingQrPullPayload.collectAsState()

    var showCodeTab by remember { mutableStateOf(initialShowTab) }
    var manualIp by remember { mutableStateOf("") }
    var hasCameraPerm by remember {
        mutableStateOf(PermissionHelper.hasAll(context, PermissionHelper.cameraPermissions()))
    }
    var showCameraDialog by remember { mutableStateOf(false) }

    val invalidQrMsg = stringResource(R.string.error_invalid_qr)

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasCameraPerm = grants.values.all { it }
    }

    val nearbyLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.startQrHostSession()
    }

    val contactsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) {
            viewModel.importReceivedContacts { count ->
                viewModel.showMessage(context.getString(R.string.clone_contacts_imported, count))
            }
        }
    }

    // Automatically start host session when Show Code tab is active
    LaunchedEffect(showCodeTab) {
        if (showCodeTab) {
            val perms = PermissionHelper.nearbyPermissions() + PermissionHelper.notificationPermissions()
            if (PermissionHelper.hasAll(context, perms)) {
                viewModel.startQrHostSession()
            } else {
                nearbyLauncher.launch(perms.distinct().toTypedArray())
                viewModel.startQrHostSession()
            }
        } else if (!hasCameraPerm) {
            showCameraDialog = true
        }
    }

    // Auto-start pull or push once QR connection finishes joining Wi-Fi Direct / LAN
    LaunchedEffect(wifiState, pendingPull) {
        if (wifiState is WifiDirectState.Connected) {
            if (viewModel.consumePendingQrPullIfConnected()) {
                onOpenTransfers()
            } else if (!showCodeTab && selectedFiles.isNotEmpty() && viewModel.sendSelectedFiles()) {
                onOpenTransfers()
            }
        }
    }

    if (showCameraDialog && !hasCameraPerm) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_camera_title),
            description = stringResource(R.string.perm_camera_desc),
            onGrantClick = {
                showCameraDialog = false
                cameraLauncher.launch(PermissionHelper.cameraPermissions())
            },
            onOpenSettingsClick = {
                showCameraDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = { showCameraDialog = false }
        )
    }

    Scaffold(
        containerColor = BgBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
                title = { Text(stringResource(R.string.qr_screen_title), color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = TextPrimary
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Segmented control: Show code / Scan code
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = showCodeTab,
                    onClick = { showCodeTab = true },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = TextPrimary,
                        activeContentColor = BgBlack,
                        inactiveContainerColor = SurfaceDark,
                        inactiveContentColor = TextPrimary,
                        activeBorderColor = OutlineStrong,
                        inactiveBorderColor = OutlineSubtle
                    )
                ) {
                    Text(stringResource(R.string.qr_tab_show))
                }
                SegmentedButton(
                    selected = !showCodeTab,
                    onClick = { showCodeTab = false },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = TextPrimary,
                        activeContentColor = BgBlack,
                        inactiveContainerColor = SurfaceDark,
                        inactiveContentColor = TextPrimary,
                        activeBorderColor = OutlineStrong,
                        inactiveBorderColor = OutlineSubtle
                    )
                ) {
                    Text(stringResource(R.string.qr_tab_scan))
                }
            }

            if (showCodeTab) {
                val qrPayload = remember(wifiState, isServerRunning, activePort, selectedFiles) {
                    viewModel.buildHostQrPayload()
                }
                val qrBitmap = remember(qrPayload) {
                    qrPayload?.let { QrCodeGenerator.generateBitmap(it, 560) }
                }
                val totalSize = selectedFiles.values.sumOf { it.sizeBytes }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (qrBitmap != null) {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Image(
                                bitmap = qrBitmap.asImageBitmap(),
                                contentDescription = stringResource(R.string.action_show_qr),
                                modifier = Modifier
                                    .padding(18.dp)
                                    .size(236.dp)
                            )
                        }
                    } else {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                            border = BorderStroke(1.dp, OutlineSubtle),
                            modifier = Modifier.size(236.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    text = stringResource(R.string.qr_waiting_ip),
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = stringResource(R.string.qr_show_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )

                    // Status chips: "N files · size" and "AES-256 encrypted"
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (selectedFiles.isNotEmpty()) {
                            MonochromeChip(
                                text = stringResource(
                                    R.string.qr_chip_files_size,
                                    selectedFiles.size,
                                    Formatters.formatBytes(totalSize)
                                )
                            )
                        }
                        MonochromeChip(text = stringResource(R.string.qr_chip_encrypted))
                    }

                    val ipText = when (val st = wifiState) {
                        is WifiDirectState.HostingGroup -> st.ipAddress
                        is WifiDirectState.Connected -> st.groupOwnerIp
                        else -> Formatters.getLocalIpAddress()
                    }
                    if (!ipText.isNullOrBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                            border = BorderStroke(1.dp, OutlineSubtle),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = stringResource(R.string.qr_ip_port_label, ipText, activePort),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                val host = wifiState as? WifiDirectState.HostingGroup
                                if (host != null && !host.ssid.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (host.band5GhzRequested) {
                                            stringResource(R.string.qr_wifi_direct_5ghz, host.ssid)
                                        } else {
                                            stringResource(R.string.qr_wifi_direct_label, host.ssid)
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    if (lastVcfPath != null) {
                        Button(
                            onClick = {
                                if (PermissionHelper.hasAll(context, PermissionHelper.contactsPermissions())) {
                                    viewModel.importReceivedContacts { count ->
                                        viewModel.showMessage(context.getString(R.string.clone_contacts_imported, count))
                                    }
                                } else {
                                    contactsLauncher.launch(PermissionHelper.contactsPermissions())
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.clone_import_contacts))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.stopHostSession()
                                onBack()
                            },
                            border = BorderStroke(1.dp, OutlineStrong),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.action_disconnect), color = TextPrimary)
                        }
                        Button(
                            onClick = onOpenTransfers,
                            colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.nav_transfers), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                // Scan code tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(SurfaceDark)
                        .border(1.dp, OutlineSubtle, RoundedCornerShape(22.dp))
                ) {
                    if (hasCameraPerm) {
                        QrScannerView(
                            modifier = Modifier.fillMaxSize(),
                            onQrScanned = { rawCode ->
                                if (!viewModel.handleScannedQr(rawCode)) {
                                    viewModel.showMessage(invalidQrMsg)
                                }
                            }
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(BgBlack.copy(alpha = 0.78f))
                                .padding(14.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.qr_scan_instruction),
                                color = TextPrimary,
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = stringResource(R.string.perm_camera_desc),
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { cameraLauncher.launch(PermissionHelper.cameraPermissions()) },
                                colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(stringResource(R.string.action_grant))
                            }
                        }
                    }
                }

                // Manual IP:port fallback
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = manualIp,
                        onValueChange = { manualIp = it },
                        placeholder = { Text(stringResource(R.string.qr_manual_ip_hint)) },
                        label = { Text(stringResource(R.string.qr_manual_ip)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val parts = manualIp.trim().split(":")
                            val ip = parts[0]
                            val port = parts.getOrNull(1)?.toIntOrNull() ?: TransferProtocol.DEFAULT_PORT
                            viewModel.connectManually(ip, port)
                            if (selectedFiles.isNotEmpty() && viewModel.sendSelectedFiles()) {
                                onOpenTransfers()
                            }
                        },
                        enabled = manualIp.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                        modifier = Modifier.heightIn(min = 52.dp)
                    ) {
                        Text(stringResource(R.string.action_connect))
                    }
                }
            }
        }
    }
}

@Composable
private fun MonochromeChip(text: String) {
    Surface(
        color = SurfaceContainerDark,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, OutlineSubtle)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
