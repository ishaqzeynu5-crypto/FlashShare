package com.flashshare.app.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.flashshare.app.data.local.TransferHistoryEntity
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.ContactsRepository
import com.flashshare.app.data.repository.FileBrowserRepository
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.AppLanguage
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.IncomingTransferRequest
import com.flashshare.app.domain.model.NearbyDevice
import com.flashshare.app.domain.model.PhoneCloneSelection
import com.flashshare.app.domain.model.PhoneCloneSummary
import com.flashshare.app.domain.model.QrConnectionPayload
import com.flashshare.app.domain.model.QrRole
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.network.WifiDirectManager
import com.flashshare.app.network.WifiDirectState
import com.flashshare.app.transfer.TransferManager
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.util.Formatters
import com.flashshare.app.webserver.LocalWebServer
import com.flashshare.app.webserver.WebServerState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val fileBrowserRepository: FileBrowserRepository,
    private val contactsRepository: ContactsRepository,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences,
    val storageOrganizer: StorageOrganizer,
    private val transferManager: TransferManager,
    private val wifiDirectManager: WifiDirectManager,
    private val localWebServer: LocalWebServer
) : ViewModel() {

    val language: StateFlow<AppLanguage> = userPreferences.language.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppLanguage.ENGLISH
    )

    val deviceName: StateFlow<String> = userPreferences.deviceName.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        userPreferences.defaultDeviceName()
    )

    val trustedDevices: StateFlow<Set<String>> = userPreferences.trustedDevices.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptySet()
    )

    val wifiDirectState: StateFlow<WifiDirectState> = wifiDirectManager.state
    val nearbyPeers: StateFlow<List<NearbyDevice>> = wifiDirectManager.peers
    val isWifiP2pEnabled: StateFlow<Boolean> = wifiDirectManager.isWifiP2pEnabled

    val transfers: StateFlow<List<TransferItem>> = transferManager.transfers
    val isReceiveServerRunning: StateFlow<Boolean> = transferManager.isReceiveServerRunning
    val activePort: StateFlow<Int> = transferManager.activePort
    val pendingIncomingRequest: StateFlow<IncomingTransferRequest?> = transferManager.pendingIncomingRequest
    val lastReceivedVcfPath: StateFlow<String?> = transferManager.lastReceivedVcfPath

    val webServerState: StateFlow<WebServerState> = localWebServer.state

    val history: StateFlow<List<TransferHistoryEntity>> = historyRepository.observeHistory().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    private val _selectedCategory = MutableStateFlow(FileCategory.PHOTOS)
    val selectedCategory: StateFlow<FileCategory> = _selectedCategory.asStateFlow()

    private val _categoryFiles = MutableStateFlow<Map<FileCategory, List<ShareableFile>>>(emptyMap())
    val categoryFiles: StateFlow<Map<FileCategory, List<ShareableFile>>> = _categoryFiles.asStateFlow()

    private val _isLoadingCategory = MutableStateFlow(false)
    val isLoadingCategory: StateFlow<Boolean> = _isLoadingCategory.asStateFlow()

    private val _selectedFiles = MutableStateFlow<Map<String, ShareableFile>>(emptyMap())
    val selectedFiles: StateFlow<Map<String, ShareableFile>> = _selectedFiles.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _cloneSummary = MutableStateFlow(PhoneCloneSummary())
    val cloneSummary: StateFlow<PhoneCloneSummary> = _cloneSummary.asStateFlow()

    private val _isPreparingClone = MutableStateFlow(false)
    val isPreparingClone: StateFlow<Boolean> = _isPreparingClone.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _deviceId = MutableStateFlow("")
    val deviceId: StateFlow<String> = _deviceId.asStateFlow()

    private val _pendingQrPullPayload = MutableStateFlow<QrConnectionPayload?>(null)
    val pendingQrPullPayload: StateFlow<QrConnectionPayload?> = _pendingQrPullPayload.asStateFlow()

    init {
        wifiDirectManager.initialize()
        viewModelScope.launch {
            _deviceId.value = userPreferences.getOrCreateDeviceId()
        }
    }

    fun selectCategory(category: FileCategory) {
        _selectedCategory.value = category
        loadCategoryFiles(category)
    }

    fun loadCategoryFiles(category: FileCategory, forceRefresh: Boolean = false) {
        if (!forceRefresh && _categoryFiles.value.containsKey(category)) return
        viewModelScope.launch {
            _isLoadingCategory.value = true
            val loaded = fileBrowserRepository.loadCategory(category)
            _categoryFiles.update { it + (category to loaded) }
            _isLoadingCategory.value = false
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFileSelection(file: ShareableFile) {
        _selectedFiles.update { current ->
            if (current.containsKey(file.id)) current - file.id else current + (file.id to file)
        }
        syncStagedAndWebFiles()
    }

    fun selectAllFiles(files: List<ShareableFile>) {
        _selectedFiles.update { current ->
            val allSelected = files.isNotEmpty() && files.all { current.containsKey(it.id) }
            if (allSelected) {
                current - files.map { it.id }.toSet()
            } else {
                current + files.associateBy { it.id }
            }
        }
        syncStagedAndWebFiles()
    }

    /**
     * Adds non-media files chosen via Android Storage Access Framework (SAF) on Android 13-16.
     */
    fun addSafDocuments(context: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val added = mutableListOf<ShareableFile>()
        uris.forEach { uri ->
            var displayName = "document_${System.currentTimeMillis()}"
            var sizeBytes = 0L
            runCatching {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) cursor.getString(nameIdx)?.let { displayName = it }
                        if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            }
            val mime = context.contentResolver.getType(uri) ?: Formatters.inferMimeType(displayName)
            val file = ShareableFile(
                id = "saf_${uri.toString().hashCode()}",
                name = displayName,
                sizeBytes = sizeBytes.coerceAtLeast(1L),
                mimeType = mime,
                category = Formatters.inferCategory(displayName, mime),
                uri = uri,
                lastModified = System.currentTimeMillis()
            )
            added.add(file)
        }
        _categoryFiles.update { current ->
            val existingDocs = current[FileCategory.DOCUMENTS].orEmpty()
            val merged = (added + existingDocs).distinctBy { it.id }
            current + (FileCategory.DOCUMENTS to merged)
        }
        _selectedFiles.update { current -> current + added.associateBy { it.id } }
        syncStagedAndWebFiles()
    }

    fun clearSelection() {
        _selectedFiles.value = emptyMap()
        syncStagedAndWebFiles()
    }

    fun startNearbyDiscovery() {
        wifiDirectManager.startDiscovery()
    }

    fun startQrHostSession() {
        val staged = _selectedFiles.value.values.toList()
        transferManager.stageFilesForQrPull(staged)
        wifiDirectManager.startReceiverGroup()
        transferManager.startReceiveServer(TransferProtocol.DEFAULT_PORT)
    }

    fun stopHostSession() {
        transferManager.stopReceiveServer()
        wifiDirectManager.disconnect()
    }

    fun connectToPeer(device: NearbyDevice) {
        wifiDirectManager.connectToPeer(device)
    }

    fun handleScannedQr(rawQr: String): Boolean {
        val payload = QrConnectionPayload.decode(rawQr) ?: return false
        if (payload.role == QrRole.SEND) {
            _pendingQrPullPayload.value = payload
        } else {
            _pendingQrPullPayload.value = null
        }
        wifiDirectManager.connectByQrPayload(payload)
        return true
    }

    fun consumePendingQrPullIfConnected(): Boolean {
        val pull = _pendingQrPullPayload.value ?: return false
        val conn = wifiDirectState.value as? WifiDirectState.Connected ?: return false
        _pendingQrPullPayload.value = null
        transferManager.pullFilesFromSender(
            hostIp = conn.groupOwnerIp,
            port = conn.port,
            peerName = conn.peerName,
            encryptionKeyBase64 = pull.encryptionKeyBase64 ?: conn.encryptionKeyBase64
        )
        return true
    }

    fun connectManually(ipAddress: String, port: Int = TransferProtocol.DEFAULT_PORT) {
        val cleanIp = ipAddress.trim()
        if (cleanIp.isBlank()) return
        wifiDirectManager.connectDirectlyByIp(cleanIp, cleanIp, port = port)
    }

    fun disconnectPeer() {
        _pendingQrPullPayload.value = null
        wifiDirectManager.disconnect()
    }

    fun respondToIncomingRequest(batchId: String, accept: Boolean, trustDevice: Boolean) {
        transferManager.respondToIncomingRequest(batchId, accept, trustDevice)
    }

    fun buildHostQrPayload(): String? {
        val state = wifiDirectState.value
        val ip = when (state) {
            is WifiDirectState.HostingGroup -> state.ipAddress
            is WifiDirectState.Connected -> state.groupOwnerIp
            else -> Formatters.getLocalIpAddress()
        } ?: return null

        val ssid = (state as? WifiDirectState.HostingGroup)?.ssid
        val pass = (state as? WifiDirectState.HostingGroup)?.passphrase
        val role = if (_selectedFiles.value.isNotEmpty()) QrRole.SEND else QrRole.RECEIVE
        return QrConnectionPayload(
            role = role,
            deviceId = _deviceId.value,
            deviceName = deviceName.value,
            ipAddress = ip,
            port = activePort.value,
            ssid = ssid,
            passphrase = pass,
            encryptionKeyBase64 = transferManager.sessionEncryptionKey.value
        ).encode()
    }

    fun sendSelectedFiles(): Boolean {
        val files = _selectedFiles.value.values.toList()
        if (files.isEmpty()) return false
        val conn = wifiDirectState.value as? WifiDirectState.Connected ?: return false
        transferManager.sendFiles(
            targetIp = conn.groupOwnerIp,
            port = conn.port,
            peerName = conn.peerName,
            files = files,
            encryptionKeyBase64 = conn.encryptionKeyBase64
        )
        _selectedFiles.value = emptyMap()
        syncStagedAndWebFiles()
        return true
    }

    fun resendHistoryItem(entry: TransferHistoryEntity): Boolean {
        val file = entry.localPath?.let { File(it) }?.takeIf { it.exists() }
        val uri = when {
            file != null -> Uri.fromFile(file)
            !entry.sourceUriString.isNullOrBlank() -> Uri.parse(entry.sourceUriString)
            else -> return false
        }
        val shareable = ShareableFile(
            id = "resend_${entry.id}_${System.currentTimeMillis()}",
            name = entry.fileName,
            sizeBytes = file?.length() ?: entry.sizeBytes,
            mimeType = entry.mimeType,
            category = entry.fileCategoryEnum(),
            uri = uri,
            filePath = file?.absolutePath
        )
        val conn = wifiDirectState.value as? WifiDirectState.Connected
        return if (conn != null) {
            transferManager.sendFiles(
                targetIp = conn.groupOwnerIp,
                port = conn.port,
                peerName = conn.peerName,
                files = listOf(shareable),
                encryptionKeyBase64 = conn.encryptionKeyBase64
            )
            true
        } else {
            _selectedFiles.update { it + (shareable.id to shareable) }
            syncStagedAndWebFiles()
            false
        }
    }

    fun pauseTransfer(id: String) = transferManager.pauseTransfer(id)
    fun resumeTransfer(id: String) = transferManager.resumeTransfer(id)
    fun cancelTransfer(id: String) = transferManager.cancelTransfer(id)
    fun pauseAllActive() = transferManager.pauseAllActive()
    fun resumeAllPaused() = transferManager.resumeAllPaused()
    fun cancelAllActive() = transferManager.cancelAllActive()
    fun clearFinishedTransfers() = transferManager.clearFinished()

    fun loadPhoneCloneSummary() {
        viewModelScope.launch {
            _isPreparingClone.value = true
            val contacts = contactsRepository.getContactCount()
            val photos = fileBrowserRepository.loadCategory(FileCategory.PHOTOS)
            val videos = fileBrowserRepository.loadCategory(FileCategory.VIDEOS)
            val music = fileBrowserRepository.loadCategory(FileCategory.MUSIC)
            _categoryFiles.update {
                it + mapOf(
                    FileCategory.PHOTOS to photos,
                    FileCategory.VIDEOS to videos,
                    FileCategory.MUSIC to music
                )
            }
            _cloneSummary.value = PhoneCloneSummary(
                contactCount = contacts,
                photoCount = photos.size,
                photoBytes = photos.sumOf { it.sizeBytes },
                videoCount = videos.size,
                videoBytes = videos.sumOf { it.sizeBytes },
                musicCount = music.size,
                musicBytes = music.sumOf { it.sizeBytes }
            )
            _isPreparingClone.value = false
        }
    }

    fun startPhoneCloneSend(selection: PhoneCloneSelection, onReadyToSend: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isPreparingClone.value = true
            val batch = mutableListOf<ShareableFile>()
            if (selection.includeContacts) {
                contactsRepository.exportContactsToVcf()?.let { batch.add(it) }
            }
            if (selection.includePhotos) {
                batch.addAll(_categoryFiles.value[FileCategory.PHOTOS] ?: fileBrowserRepository.loadCategory(FileCategory.PHOTOS))
            }
            if (selection.includeVideos) {
                batch.addAll(_categoryFiles.value[FileCategory.VIDEOS] ?: fileBrowserRepository.loadCategory(FileCategory.VIDEOS))
            }
            if (selection.includeMusic) {
                batch.addAll(_categoryFiles.value[FileCategory.MUSIC] ?: fileBrowserRepository.loadCategory(FileCategory.MUSIC))
            }
            _isPreparingClone.value = false

            if (batch.isEmpty()) {
                onReadyToSend(false)
                return@launch
            }

            val conn = wifiDirectState.value as? WifiDirectState.Connected
            if (conn != null) {
                transferManager.sendFiles(
                    targetIp = conn.groupOwnerIp,
                    port = conn.port,
                    peerName = conn.peerName,
                    files = batch,
                    encryptionKeyBase64 = conn.encryptionKeyBase64
                )
                onReadyToSend(true)
            } else {
                _selectedFiles.value = batch.associateBy { it.id }
                syncStagedAndWebFiles()
                onReadyToSend(false)
            }
        }
    }

    fun importReceivedContacts(onResult: (Int) -> Unit) {
        val path = lastReceivedVcfPath.value ?: return
        viewModelScope.launch {
            val count = contactsRepository.importContactsFromVcf(File(path))
            transferManager.clearLastReceivedVcf()
            onResult(count)
        }
    }

    fun startWebServer() {
        syncStagedAndWebFiles()
        localWebServer.start()
    }

    fun stopWebServer() {
        localWebServer.stop()
    }

    private fun syncStagedAndWebFiles() {
        val list = _selectedFiles.value.values.toList()
        localWebServer.setSharedFiles(list)
        transferManager.stageFilesForQrPull(list)
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch { historyRepository.deleteEntry(id) }
    }

    fun clearAllHistory() {
        viewModelScope.launch { historyRepository.clearAll() }
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch {
            userPreferences.setLanguage(lang)
            val locales = LocaleListCompat.forLanguageTags(lang.tag)
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }

    fun setDeviceName(name: String) {
        viewModelScope.launch { userPreferences.setDeviceName(name) }
    }

    fun clearTrustedDevices() {
        viewModelScope.launch { userPreferences.clearTrustedDevices() }
    }

    fun showMessage(message: String) {
        _statusBanner.value = message
    }

    fun clearMessage() {
        _statusBanner.value = null
    }

    override fun onCleared() {
        wifiDirectManager.release()
        super.onCleared()
    }
}
