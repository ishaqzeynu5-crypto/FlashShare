package com.flashshare.app.transfer

import java.io.DataInputStream
import java.io.DataOutputStream
import javax.crypto.SecretKey

/**
 * Hardened FlashShare Protocol V5 (rejects V1/V2/V3/V4; no legacy compatibility shim):
 * - ZRTP-style hash-commitment ECDH P-256 handshake preventing SAS grinding
 * - Mandatory AES-256-GCM encryption via HKDF-SHA256 over ECDH secret + optional QR PSK + transcript
 * - Constant-time HMAC-SHA256 proof-of-possession for BOTH QR push and QR pull BEFORE any state change
 * - Cryptographic ECDSA P-256 mutual identity signatures over the full handshake transcript
 * - Dual-phone SAS confirmation gate before any file header or file data flows
 * - VERIFY_PENDING keepalive during large-file SHA-256 verification and optional streaming SHA-256 trailer
 */
object TransferProtocol {
    const val DEFAULT_PORT: Int = 8988
    const val MAX_PORT_FALLBACK: Int = 8998
    const val MAGIC: Int = 0x46534831 // "FSH1"
    const val PROTOCOL_VERSION_V5: Int = 5

    const val BUFFER_SIZE: Int = 1024 * 1024          // 1 MB chunks
    const val SOCKET_BUFFER_SIZE: Int = 4 * 1024 * 1024 // 4 MB TCP socket buffers
    const val MAX_ENC_CHUNK_BYTES: Int = BUFFER_SIZE + CryptoHelper.GCM_TAG_BYTES + 64
    const val LARGE_FILE_PARALLEL_THRESHOLD: Long = 16L * 1024L * 1024L
    const val PARALLEL_STREAMS_DEFAULT: Int = 4

    // Strict security bounds
    const val MAX_FILES_PER_BATCH: Int = 2_000
    const val MAX_FILENAME_LENGTH: Int = 255
    const val MAX_HANDSHAKE_FRAME_BYTES: Int = 4_096
    const val MAX_CONCURRENT_CONNECTIONS: Int = 8
    const val HANDSHAKE_TIMEOUT_MS: Int = 15_000
    const val DATA_TIMEOUT_MS: Int = 60_000
    const val VERIFY_KEEPALIVE_INTERVAL_MS: Long = 5_000L

    // Flags
    const val FLAG_ENCRYPTED: Int = 0x01
    const val FLAG_BATCH: Int = 0x02
    const val FLAG_CHUNKED_RANGE: Int = 0x04
    const val FLAG_USES_QR_PSK: Int = 0x08
    const val FLAG_PULL_FROM_SENDER: Int = 0x10
    const val FLAG_STREAMING_SHA256_TRAILER: Int = 0x20
    const val FLAG_TURBO_RAW_PAYLOAD: Int = 0x40

    // Role labels bound into QR proof HMAC
    const val ROLE_PUSH: String = "PUSH"
    const val ROLE_PULL: String = "PULL"

    // Response codes
    const val RESPONSE_OK: Byte = 1
    const val RESPONSE_LOW_STORAGE: Byte = 2
    const val RESPONSE_REJECTED: Byte = 3
    const val RESPONSE_AUTH_FAILED: Byte = 4
    const val RESPONSE_SAS_MISMATCH: Byte = 5

    // Client SAS decision codes
    const val SAS_CONFIRMED: Byte = 20
    const val SAS_MISMATCH: Byte = 21

    // Integrity codes
    const val VERIFY_OK: Byte = 10
    const val VERIFY_HASH_MISMATCH: Byte = 11
    const val VERIFY_PENDING: Byte = 12
    const val VERIFY_STORAGE_ERROR: Byte = 13

    data class ReceiverAck(
        val status: Byte,
        val offsetOrAvailableBytes: Long
    )

    data class HandshakeResult(
        val sessionKey: SecretKey,
        val sasCode: String,
        val peerFingerprint: String,
        val qrPskVerified: Boolean,
        val usedQrPskBytes: ByteArray? = null
    )

    data class BatchHeaderV5(
        val flags: Int,
        val batchId: String,
        val senderName: String,
        val totalFilesInBatch: Int,
        val streamFileCount: Int,
        val totalBatchBytes: Long
    ) {
        val isEncrypted: Boolean get() = (flags and FLAG_ENCRYPTED) != 0
        val isChunkedRange: Boolean get() = (flags and FLAG_CHUNKED_RANGE) != 0
        val usesQrPsk: Boolean get() = (flags and FLAG_USES_QR_PSK) != 0
        val isPullRequest: Boolean get() = (flags and FLAG_PULL_FROM_SENDER) != 0
        val usesStreamingTrailer: Boolean get() = (flags and FLAG_STREAMING_SHA256_TRAILER) != 0
        val isTurboRawPayload: Boolean get() = (flags and FLAG_TURBO_RAW_PAYLOAD) != 0
        val roleLabel: String get() = if (isPullRequest) ROLE_PULL else ROLE_PUSH

        fun validate() {
            require(isEncrypted) { "Unencrypted V5 sessions are forbidden" }
            require(batchId.isNotBlank() && batchId.length <= 128) { "Invalid batchId" }
            require(senderName.length <= 128) { "Invalid senderName" }
            require(totalFilesInBatch in 0..MAX_FILES_PER_BATCH) { "File count exceeds limit" }
            require(streamFileCount in 0..MAX_FILES_PER_BATCH) { "Stream file count exceeds limit" }
            require(totalBatchBytes >= 0L) { "Negative totalBatchBytes" }
        }
    }

    data class FileHeaderV5(
        val transferId: String,
        val fileName: String,
        val mimeType: String,
        val categoryName: String,
        val totalSizeBytes: Long,
        val rangeStart: Long,
        val rangeLength: Long,
        val baseIv: ByteArray,
        val hasTrailerHash: Boolean,
        val wholeFileSha256: ByteArray
    ) {
        fun validate() {
            require(transferId.isNotBlank() && transferId.length <= 128) { "Invalid transferId" }
            require(fileName.isNotBlank() && fileName.length <= MAX_FILENAME_LENGTH) { "Invalid fileName length" }
            require(mimeType.length <= 128) { "Invalid mimeType" }
            require(totalSizeBytes >= 0L) { "Negative totalSizeBytes" }
            require(rangeStart >= 0L && rangeStart <= totalSizeBytes) { "Invalid rangeStart" }
            require(rangeLength >= 0L && rangeLength <= totalSizeBytes - rangeStart) { "Invalid rangeLength" }
            require(baseIv.size == CryptoHelper.BASE_IV_BYTES) { "Invalid IV size" }
            if (!hasTrailerHash) {
                require(wholeFileSha256.size == 32) { "Invalid SHA-256 hash size" }
            }
        }
    }

    fun readAndVerifyVersionV5(input: DataInputStream): Int {
        val magic = input.readInt()
        if (magic != MAGIC) throw IllegalStateException("Invalid FlashShare protocol magic")
        val version = input.readInt()
        if (version != PROTOCOL_VERSION_V5) {
            throw IllegalStateException("Unsupported protocol version: $version (V5 required)")
        }
        return version
    }

    fun writeBatchHeaderV5(out: DataOutputStream, header: BatchHeaderV5) {
        header.validate()
        out.writeInt(MAGIC)
        out.writeInt(PROTOCOL_VERSION_V5)
        out.writeByte(header.flags)
        out.writeUTF(header.batchId)
        out.writeUTF(header.senderName)
        out.writeInt(header.totalFilesInBatch)
        out.writeInt(header.streamFileCount)
        out.writeLong(header.totalBatchBytes)
        out.flush()
    }

    fun readBatchHeaderV5Body(input: DataInputStream): BatchHeaderV5 {
        val flags = input.readByte().toInt() and 0xFF
        val batchId = input.readUTF()
        val senderName = input.readUTF()
        val totalFiles = input.readInt()
        val streamFiles = input.readInt()
        val totalBytes = input.readLong()
        return BatchHeaderV5(
            flags = flags,
            batchId = batchId,
            senderName = senderName,
            totalFilesInBatch = totalFiles,
            streamFileCount = streamFiles,
            totalBatchBytes = totalBytes
        ).also { it.validate() }
    }

    fun writeBytesFrame(out: DataOutputStream, bytes: ByteArray) {
        require(bytes.size <= MAX_HANDSHAKE_FRAME_BYTES) { "Handshake frame too large" }
        out.writeInt(bytes.size)
        if (bytes.isNotEmpty()) out.write(bytes)
        out.flush()
    }

    fun readBytesFrame(input: DataInputStream): ByteArray {
        val len = input.readInt()
        if (len !in 0..MAX_HANDSHAKE_FRAME_BYTES) {
            throw IllegalStateException("Invalid handshake frame length: $len")
        }
        return if (len == 0) ByteArray(0) else ByteArray(len).also { input.readFully(it) }
    }

    fun writeAck(out: DataOutputStream, status: Byte, offsetOrAvailableBytes: Long) {
        out.writeByte(status.toInt())
        out.writeLong(offsetOrAvailableBytes)
        out.flush()
    }

    fun readAck(input: DataInputStream): ReceiverAck {
        return ReceiverAck(
            status = input.readByte(),
            offsetOrAvailableBytes = input.readLong()
        )
    }

    fun writeFileHeaderV5(out: DataOutputStream, header: FileHeaderV5) {
        header.validate()
        out.writeUTF(header.transferId)
        out.writeUTF(header.fileName)
        out.writeUTF(header.mimeType)
        out.writeUTF(header.categoryName)
        out.writeLong(header.totalSizeBytes)
        out.writeLong(header.rangeStart)
        out.writeLong(header.rangeLength)
        out.write(header.baseIv)
        out.writeBoolean(header.hasTrailerHash)
        if (!header.hasTrailerHash) {
            out.write(header.wholeFileSha256)
        }
        out.flush()
    }

    fun readFileHeaderV5(input: DataInputStream): FileHeaderV5 {
        val transferId = input.readUTF()
        val fileName = input.readUTF()
        val mimeType = input.readUTF()
        val categoryName = input.readUTF()
        val totalSize = input.readLong()
        val rangeStart = input.readLong()
        val rangeLength = input.readLong()
        val iv = ByteArray(CryptoHelper.BASE_IV_BYTES).also { input.readFully(it) }
        val hasTrailerHash = input.readBoolean()
        val sha256 = if (hasTrailerHash) {
            ByteArray(0)
        } else {
            ByteArray(32).also { input.readFully(it) }
        }
        return FileHeaderV5(
            transferId = transferId,
            fileName = fileName,
            mimeType = mimeType,
            categoryName = categoryName,
            totalSizeBytes = totalSize,
            rangeStart = rangeStart,
            rangeLength = rangeLength,
            baseIv = iv,
            hasTrailerHash = hasTrailerHash,
            wholeFileSha256 = sha256
        ).also { it.validate() }
    }

    fun validateEncryptedChunkLength(encLen: Int) {
        if (encLen !in 1..MAX_ENC_CHUNK_BYTES) {
            throw IllegalStateException("Invalid encrypted chunk size: $encLen")
        }
    }

    /**
     * Reads verify status bytes in a loop, ignoring VERIFY_PENDING keepalives until a final
     * status (VERIFY_OK, VERIFY_HASH_MISMATCH, VERIFY_STORAGE_ERROR) arrives.
     */
    fun readFinalVerifyByte(input: DataInputStream, onPending: () -> Unit = {}): Byte {
        while (true) {
            val code = input.readByte()
            if (code == VERIFY_PENDING) {
                onPending()
            } else {
                return code
            }
        }
    }

    /**
     * Protocol V5 Client (Initiator) Handshake:
     * 1. Send commit = SHA-256("FLASHSHARE-V5-COMMIT|" || clientEcdhPub || clientNonce) + clientIdPub
     * 2. Receive serverEcdhPub + serverIdPub
     * 3. Reveal clientEcdhPub + clientNonce (+ qrProof if usesQrPsk)
     * 4. Receive serverAuthStatus (RESPONSE_OK or RESPONSE_AUTH_FAILED) + serverSig
     * 5. Verify serverSig over full V5 transcript, send clientSig, derive HKDF session key + SAS
     */
    fun performClientHandshakeV5(
        dataOut: DataOutputStream,
        dataIn: DataInputStream,
        identity: DeviceIdentityProvider,
        flags: Int,
        batchId: String,
        roleLabel: String,
        qrPskBytes: ByteArray?
    ): HandshakeResult {
        val ecdhKp = CryptoHelper.generateEcdhKeyPair()
        val myEcdhPub = ecdhKp.public.encoded
        val myNonce = CryptoHelper.generateNonce32()
        val myCommit = CryptoHelper.computeCommitment(myEcdhPub, myNonce)
        val myIdPub = identity.getPublicKeyEncoded()

        // Step 1: Commitment + Identity PubKey
        writeBytesFrame(dataOut, myCommit)
        writeBytesFrame(dataOut, myIdPub)

        // Step 2: Server ephemeral ECDH PubKey + Server Identity PubKey
        val serverEcdhPub = readBytesFrame(dataIn)
        val serverIdPub = readBytesFrame(dataIn)

        // Step 3: Reveal ECDH PubKey + Nonce (+ QR proof of possession for BOTH push and pull)
        writeBytesFrame(dataOut, myEcdhPub)
        writeBytesFrame(dataOut, myNonce)
        val usesQrPsk = (flags and FLAG_USES_QR_PSK) != 0
        if (usesQrPsk) {
            val psk = qrPskBytes ?: throw SecurityException("QR PSK flag set without key")
            val proof = CryptoHelper.computeQrProof(psk, batchId, myEcdhPub, roleLabel)
            writeBytesFrame(dataOut, proof)
        }

        // Step 4: Check server pre-auth result before signature verification
        val authStatus = dataIn.readByte()
        if (authStatus != RESPONSE_OK) {
            throw SecurityException(
                if (authStatus == RESPONSE_AUTH_FAILED) "QR authentication failed (key rotated or invalid)"
                else "Handshake rejected by peer (status=$authStatus)"
            )
        }
        val serverSig = readBytesFrame(dataIn)

        val transcriptHash = buildTranscriptHashV5(
            flags = flags,
            batchId = batchId,
            commit = myCommit,
            clientEcdhPub = myEcdhPub,
            clientNonce = myNonce,
            serverEcdhPub = serverEcdhPub,
            clientIdPub = myIdPub,
            serverIdPub = serverIdPub
        )

        if (!DeviceIdentityManager.verifySignature(serverIdPub, transcriptHash, serverSig)) {
            throw SecurityException("Peer identity signature verification failed")
        }

        val mySig = identity.signTranscript(transcriptHash)
        writeBytesFrame(dataOut, mySig)

        val ecdhSecret = CryptoHelper.computeEcdhSharedSecret(ecdhKp.private, serverEcdhPub)
        val derived = CryptoHelper.deriveSessionMaterial(ecdhSecret, transcriptHash, qrPskBytes)
        return HandshakeResult(
            sessionKey = derived.aesKey,
            sasCode = derived.sasCode,
            peerFingerprint = DeviceIdentityManager.fingerprintHex(serverIdPub),
            qrPskVerified = usesQrPsk && qrPskBytes != null,
            usedQrPskBytes = qrPskBytes
        )
    }

    /**
     * Protocol V5 Server (Responder) Handshake:
     * Verifies ZRTP commitment AND constant-time QR proof BEFORE any state change, approval prompt, or rotation.
     * [resolveQrPskForBatch] returns candidate PSK bytes (active batch PSK or current session key) without mutating state.
     */
    fun performServerHandshakeV5(
        dataIn: DataInputStream,
        dataOut: DataOutputStream,
        identity: DeviceIdentityProvider,
        batch: BatchHeaderV5,
        resolveQrPskForBatch: (batchId: String) -> ByteArray?
    ): HandshakeResult {
        // Step 1: Read client commitment + client identity pubkey
        val clientCommit = readBytesFrame(dataIn)
        val clientIdPub = readBytesFrame(dataIn)
        if (clientCommit.size != 32) {
            throw SecurityException("Invalid commitment size")
        }

        // Step 2: Send server ephemeral ECDH pubkey + server identity pubkey (stateless)
        val ecdhKp = CryptoHelper.generateEcdhKeyPair()
        val myEcdhPub = ecdhKp.public.encoded
        val myIdPub = identity.getPublicKeyEncoded()
        writeBytesFrame(dataOut, myEcdhPub)
        writeBytesFrame(dataOut, myIdPub)

        // Step 3: Read client reveal (clientEcdhPub + clientNonce + optional qrProof)
        val clientEcdhPub = readBytesFrame(dataIn)
        val clientNonce = readBytesFrame(dataIn)
        if (clientNonce.size != CryptoHelper.COMMIT_NONCE_BYTES) {
            dataOut.writeByte(RESPONSE_AUTH_FAILED.toInt())
            dataOut.flush()
            throw SecurityException("Invalid commitment nonce size")
        }

        // Verify ZRTP commitment BEFORE deriving SAS or accepting session
        val expectedCommit = CryptoHelper.computeCommitment(clientEcdhPub, clientNonce)
        if (!CryptoHelper.constantTimeEquals(clientCommit, expectedCommit)) {
            dataOut.writeByte(RESPONSE_AUTH_FAILED.toInt())
            dataOut.flush()
            throw SecurityException("SAS commitment verification failed")
        }

        // Verify QR PSK proof in constant time BEFORE any state change, approval prompt, or rotation
        var verifiedQrPsk: ByteArray? = null
        if (batch.usesQrPsk || batch.isPullRequest) {
            if (!batch.usesQrPsk) {
                dataOut.writeByte(RESPONSE_AUTH_FAILED.toInt())
                dataOut.flush()
                throw SecurityException("QR PSK required for pull")
            }
            val proof = readBytesFrame(dataIn)
            val candidatePsk = resolveQrPskForBatch(batch.batchId)
            val expectedProof = candidatePsk?.let {
                CryptoHelper.computeQrProof(it, batch.batchId, clientEcdhPub, batch.roleLabel)
            }
            if (expectedProof == null || !CryptoHelper.constantTimeEquals(proof, expectedProof)) {
                dataOut.writeByte(RESPONSE_AUTH_FAILED.toInt())
                dataOut.flush()
                throw SecurityException("Invalid QR proof of possession")
            }
            verifiedQrPsk = candidatePsk
        }

        val transcriptHash = buildTranscriptHashV5(
            flags = batch.flags,
            batchId = batch.batchId,
            commit = clientCommit,
            clientEcdhPub = clientEcdhPub,
            clientNonce = clientNonce,
            serverEcdhPub = myEcdhPub,
            clientIdPub = clientIdPub,
            serverIdPub = myIdPub
        )

        val mySig = identity.signTranscript(transcriptHash)
        dataOut.writeByte(RESPONSE_OK.toInt())
        writeBytesFrame(dataOut, mySig)

        val clientSig = readBytesFrame(dataIn)
        if (!DeviceIdentityManager.verifySignature(clientIdPub, transcriptHash, clientSig)) {
            throw SecurityException("Client identity signature verification failed")
        }

        val ecdhSecret = CryptoHelper.computeEcdhSharedSecret(ecdhKp.private, clientEcdhPub)
        val derived = CryptoHelper.deriveSessionMaterial(ecdhSecret, transcriptHash, verifiedQrPsk)

        return HandshakeResult(
            sessionKey = derived.aesKey,
            sasCode = derived.sasCode,
            peerFingerprint = DeviceIdentityManager.fingerprintHex(clientIdPub),
            qrPskVerified = verifiedQrPsk != null,
            usedQrPskBytes = verifiedQrPsk
        )
    }

    fun buildTranscriptHashV5(
        flags: Int,
        batchId: String,
        commit: ByteArray,
        clientEcdhPub: ByteArray,
        clientNonce: ByteArray,
        serverEcdhPub: ByteArray,
        clientIdPub: ByteArray,
        serverIdPub: ByteArray
    ): ByteArray = CryptoHelper.sha256(
        "FLASHSHARE-V5-TRANSCRIPT|".toByteArray(Charsets.UTF_8),
        flags.toString().toByteArray(Charsets.UTF_8),
        batchId.toByteArray(Charsets.UTF_8),
        commit,
        clientEcdhPub,
        clientNonce,
        serverEcdhPub,
        clientIdPub,
        serverIdPub
    )
}
