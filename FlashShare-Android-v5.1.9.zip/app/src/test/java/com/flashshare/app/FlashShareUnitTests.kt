package com.flashshare.app

import com.flashshare.app.data.repository.ContactDedupeIndex
import com.flashshare.app.data.repository.ContactsRepository
import com.flashshare.app.data.repository.ParsedVCardContact
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.IncomingTransferRequest
import com.flashshare.app.domain.model.QrConnectionPayload
import com.flashshare.app.domain.model.QrRole
import com.flashshare.app.transfer.ApprovalCoordinator
import com.flashshare.app.transfer.Base64Url
import com.flashshare.app.transfer.CryptoHelper
import com.flashshare.app.transfer.DeviceIdentityManager
import com.flashshare.app.transfer.DeviceIdentityProvider
import com.flashshare.app.transfer.ParallelCompletionCoordinator
import com.flashshare.app.transfer.TransferManager
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.network.WifiDirectManager
import com.flashshare.app.webserver.LocalWebServer
import com.flashshare.app.webserver.WebServerAuthGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.util.concurrent.atomic.AtomicInteger

/**
 * In-memory ECDSA P-256 DeviceIdentityProvider for JVM unit tests (no Android Keystore required).
 */
class FakeDeviceIdentityProvider : DeviceIdentityProvider {
    private val keyPair = KeyPairGenerator.getInstance("EC").apply {
        initialize(ECGenParameterSpec("secp256r1"), SecureRandom())
    }.generateKeyPair()

    override fun getPublicKeyEncoded(): ByteArray = keyPair.public.encoded

    override fun getPublicKeyFingerprint(): String =
        DeviceIdentityManager.fingerprintHex(keyPair.public.encoded)

    override fun signTranscript(transcript: ByteArray): ByteArray {
        val sig = Signature.getInstance("SHA256withECDSA")
        sig.initSign(keyPair.private)
        sig.update(transcript)
        return sig.sign()
    }
}

class FlashShareUnitTests {

    // --- Item 1: Pure-Kotlin Base64URL & No java.util.Base64 guard ---

    @Test
    fun base64Url_roundTripAndInvalidInputs() {
        val rng = SecureRandom()
        for (len in listOf(0, 1, 2, 3, 4, 15, 16, 31, 32, 33, 64, 100)) {
            val bytes = ByteArray(len).also { rng.nextBytes(it) }
            val encoded = Base64Url.encodeNoPadding(bytes)
            assertFalse("No '=' padding expected", encoded.contains('='))
            assertFalse("No '+' expected", encoded.contains('+'))
            assertFalse("No '/' expected", encoded.contains('/'))
            assertArrayEquals(bytes, Base64Url.decode(encoded))
        }

        // Standard padded Base64URL should also decode cleanly
        assertArrayEquals("f".toByteArray(), Base64Url.decode("Zg=="))
        assertArrayEquals("fo".toByteArray(), Base64Url.decode("Zm8="))
        assertArrayEquals("foo".toByteArray(), Base64Url.decode("Zm9v"))

        // Invalid inputs must throw IllegalArgumentException
        val invalidInputs = listOf(
            "a",          // length % 4 == 1
            "abc+defg",   // non-URL-safe '+'
            "abc/defg",   // non-URL-safe '/'
            "ab===",      // excess padding
            "Zg=",        // invalid padded length
            "Z!",         // illegal character
            "Zh"          // non-zero trailing bits for 2-char remainder
        )
        invalidInputs.forEach { bad ->
            try {
                Base64Url.decode(bad)
                fail("Expected IllegalArgumentException for '$bad'")
            } catch (_: IllegalArgumentException) {
                // expected
            }
        }
    }

    @Test
    fun staticAudit_noJavaUtilBase64OrThreadLocalWithInitialInMainSources() {
        val candidates = listOf(
            File("src/main/java"),
            File("app/src/main/java")
        )
        val mainSrc = candidates.firstOrNull { it.exists() && it.isDirectory }
            ?: return // Skip if invoked from an unexpected working dir

        val offenders = mutableListOf<String>()
        mainSrc.walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .forEach { file ->
                val text = file.readText()
                if (text.contains("java.util.Base64")) {
                    offenders.add("${file.path}: uses java.util.Base64 (requires API 26)")
                }
                if (text.contains("ThreadLocal.withInitial")) {
                    offenders.add("${file.path}: uses ThreadLocal.withInitial (requires API 26)")
                }
            }
        assertTrue("API 26+ calls found in minSdk 24 sources:\n${offenders.joinToString("\n")}", offenders.isEmpty())
    }

    // --- Protocol V5 framing & version enforcement ---

    @Test
    fun transferProtocolV5_batchAndFileHeaderRoundTrip() {
        val baos = ByteArrayOutputStream()
        val out = DataOutputStream(baos)

        val batch = TransferProtocol.BatchHeaderV5(
            flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED,
            batchId = "batch-v5-123",
            senderName = "Pixel 9",
            totalFilesInBatch = 2,
            streamFileCount = 2,
            totalBatchBytes = 4096L
        )
        TransferProtocol.writeBatchHeaderV5(out, batch)

        val iv = CryptoHelper.generateBaseIv()
        val sha = CryptoHelper.sha256("sample".toByteArray())
        val fileHeader = TransferProtocol.FileHeaderV5(
            transferId = "tx-1",
            fileName = "photo.jpg",
            mimeType = "image/jpeg",
            categoryName = "PHOTOS",
            totalSizeBytes = 2048L,
            rangeStart = 0L,
            rangeLength = 2048L,
            baseIv = iv,
            hasTrailerHash = false,
            wholeFileSha256 = sha
        )
        TransferProtocol.writeFileHeaderV5(out, fileHeader)

        val input = DataInputStream(ByteArrayInputStream(baos.toByteArray()))
        assertEquals(TransferProtocol.PROTOCOL_VERSION_V5, TransferProtocol.readAndVerifyVersionV5(input))
        val decodedBatch = TransferProtocol.readBatchHeaderV5Body(input)
        assertEquals(batch.batchId, decodedBatch.batchId)
        assertEquals(batch.totalFilesInBatch, decodedBatch.totalFilesInBatch)

        val decodedFile = TransferProtocol.readFileHeaderV5(input)
        assertEquals("photo.jpg", decodedFile.fileName)
        assertFalse(decodedFile.hasTrailerHash)
        assertArrayEquals(iv, decodedFile.baseIv)
        assertArrayEquals(sha, decodedFile.wholeFileSha256)
    }

    @Test(expected = IllegalStateException::class)
    fun transferProtocolV5_rejectsVersion4() {
        val baos = ByteArrayOutputStream()
        DataOutputStream(baos).apply {
            writeInt(TransferProtocol.MAGIC)
            writeInt(4)
        }
        TransferProtocol.readAndVerifyVersionV5(DataInputStream(ByteArrayInputStream(baos.toByteArray())))
    }

    @Test(expected = IllegalStateException::class)
    fun transferProtocolV5_rejectsOversizedEncryptedChunk() {
        TransferProtocol.validateEncryptedChunkLength(TransferProtocol.MAX_ENC_CHUNK_BYTES + 1)
    }

    // --- Item 14: Loopback Socket Handshake Tests ---

    @Test
    fun loopbackHandshakeV5_successWithAndWithoutQrPsk(): Unit = runBlocking {
        val clientId = FakeDeviceIdentityProvider()
        val serverId = FakeDeviceIdentityProvider()
        val qrKeyB64 = CryptoHelper.generateKeyBase64()
        val qrKeyBytes = CryptoHelper.decodeKeyBytes(qrKeyB64)!!

        // 1. With QR PSK (PUSH)
        val (c1, s1) = runLoopbackHandshake(
            clientId = clientId,
            serverId = serverId,
            flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED or TransferProtocol.FLAG_USES_QR_PSK,
            batchId = "batch-qr-ok",
            clientPsk = qrKeyBytes,
            serverPskResolver = { qrKeyBytes }
        )
        assertArrayEquals(c1.sessionKey.encoded, s1.sessionKey.encoded)
        assertEquals(c1.sasCode, s1.sasCode)
        assertTrue(c1.qrPskVerified)
        assertTrue(s1.qrPskVerified)
        assertEquals(serverId.getPublicKeyFingerprint(), c1.peerFingerprint)
        assertEquals(clientId.getPublicKeyFingerprint(), s1.peerFingerprint)

        // 2. Without QR PSK (Nearby discovery SAS)
        val (c2, s2) = runLoopbackHandshake(
            clientId = clientId,
            serverId = serverId,
            flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED,
            batchId = "batch-nearby-sas",
            clientPsk = null,
            serverPskResolver = { null }
        )
        assertArrayEquals(c2.sessionKey.encoded, s2.sessionKey.encoded)
        assertEquals(c2.sasCode, s2.sasCode)
        assertFalse(c2.qrPskVerified)
        assertFalse(s2.qrPskVerified)
    }

    @Test
    fun loopbackHandshakeV5_pskMismatchFailsAndDoesNotRotateOrPrompt(): Unit = runBlocking {
        val clientId = FakeDeviceIdentityProvider()
        val serverId = FakeDeviceIdentityProvider()
        val serverKey = CryptoHelper.decodeKeyBytes(CryptoHelper.generateKeyBase64())!!
        val wrongClientKey = CryptoHelper.decodeKeyBytes(CryptoHelper.generateKeyBase64())!!
        val promptCount = AtomicInteger(0)
        val rotationCount = AtomicInteger(0)

        ServerSocket(0, 4, InetAddress.getLoopbackAddress()).apply { soTimeout = 5_000 }.use { serverSocket ->
            val serverJob = async(Dispatchers.IO) {
                serverSocket.accept().use { sock ->
                    val dataIn = DataInputStream(sock.getInputStream())
                    val dataOut = DataOutputStream(sock.getOutputStream())
                    TransferProtocol.readAndVerifyVersionV5(dataIn)
                    val batch = TransferProtocol.readBatchHeaderV5Body(dataIn)
                    try {
                        TransferProtocol.performServerHandshakeV5(
                            dataIn = dataIn,
                            dataOut = dataOut,
                            identity = serverId,
                            batch = batch,
                            resolveQrPskForBatch = { serverKey }
                        )
                        // Must NOT reach here on invalid proof
                        promptCount.incrementAndGet()
                        rotationCount.incrementAndGet()
                        false
                    } catch (_: SecurityException) {
                        true
                    }
                }
            }

            val clientFailed = Socket(InetAddress.getLoopbackAddress(), serverSocket.localPort).apply { soTimeout = 5_000 }.use { sock ->
                val dataOut = DataOutputStream(sock.getOutputStream())
                val dataIn = DataInputStream(sock.getInputStream())
                val flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED or TransferProtocol.FLAG_USES_QR_PSK
                TransferProtocol.writeBatchHeaderV5(
                    dataOut,
                    TransferProtocol.BatchHeaderV5(flags, "batch-bad-psk", "Attacker", 1, 1, 100L)
                )
                try {
                    TransferProtocol.performClientHandshakeV5(
                        dataOut, dataIn, clientId, flags, "batch-bad-psk", TransferProtocol.ROLE_PUSH, wrongClientKey
                    )
                    false
                } catch (_: SecurityException) {
                    true
                }
            }

            assertTrue("Server must reject invalid QR proof", serverJob.await())
            assertTrue("Client must fail on RESPONSE_AUTH_FAILED", clientFailed)
            assertEquals("Invalid proof must NOT prompt", 0, promptCount.get())
            assertEquals("Invalid proof must NOT rotate PSK", 0, rotationCount.get())
        }
    }

    @Test
    fun loopbackHandshakeV5_multipleSocketsSameBatchReuseQrPsk(): Unit = runBlocking {
        val clientId = FakeDeviceIdentityProvider()
        val serverId = FakeDeviceIdentityProvider()
        val batchPsk = CryptoHelper.decodeKeyBytes(CryptoHelper.generateKeyBase64())!!
        val flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED or TransferProtocol.FLAG_USES_QR_PSK
        val batchId = "multi-socket-batch-1"

        // Simulate 3 parallel worker sockets in the same batch authenticating with the same QR PSK
        val results = (1..3).map {
            runLoopbackHandshake(
                clientId = clientId,
                serverId = serverId,
                flags = flags,
                batchId = batchId,
                clientPsk = batchPsk,
                serverPskResolver = { id -> if (id == batchId) batchPsk else null }
            )
        }
        results.forEach { (c, s) ->
            assertArrayEquals(c.sessionKey.encoded, s.sessionKey.encoded)
            assertTrue(c.qrPskVerified && s.qrPskVerified)
        }
        // Ephemeral ECDH ensures each socket still gets a fresh unique AES session key
        assertNotEquals(
            Base64Url.encodeNoPadding(results[0].first.sessionKey.encoded),
            Base64Url.encodeNoPadding(results[1].first.sessionKey.encoded)
        )
    }

    @Test
    fun loopbackHandshakeV5_sasCommitmentMismatchAborts(): Unit = runBlocking {
        val clientId = FakeDeviceIdentityProvider()
        val serverId = FakeDeviceIdentityProvider()

        ServerSocket(0, 4, InetAddress.getLoopbackAddress()).apply { soTimeout = 5_000 }.use { serverSocket ->
            val serverAborted = async(Dispatchers.IO) {
                serverSocket.accept().use { sock ->
                    val dataIn = DataInputStream(sock.getInputStream())
                    val dataOut = DataOutputStream(sock.getOutputStream())
                    TransferProtocol.readAndVerifyVersionV5(dataIn)
                    val batch = TransferProtocol.readBatchHeaderV5Body(dataIn)
                    try {
                        TransferProtocol.performServerHandshakeV5(
                            dataIn = dataIn,
                            dataOut = dataOut,
                            identity = serverId,
                            batch = batch,
                            resolveQrPskForBatch = { null }
                        )
                        false
                    } catch (e: SecurityException) {
                        e.message?.contains("commitment", ignoreCase = true) == true
                    }
                }
            }

            Socket(InetAddress.getLoopbackAddress(), serverSocket.localPort).apply { soTimeout = 5_000 }.use { sock ->
                val dataOut = DataOutputStream(sock.getOutputStream())
                val dataIn = DataInputStream(sock.getInputStream())
                val flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_ENCRYPTED
                TransferProtocol.writeBatchHeaderV5(
                    dataOut,
                    TransferProtocol.BatchHeaderV5(flags, "batch-bad-commit", "Mallory", 1, 1, 100L)
                )

                // Send a fake commitment for kp1, then try to reveal kp2 after seeing server pubkey!
                val kp1 = CryptoHelper.generateEcdhKeyPair()
                val kp2 = CryptoHelper.generateEcdhKeyPair()
                val nonce = CryptoHelper.generateNonce32()
                val commit1 = CryptoHelper.computeCommitment(kp1.public.encoded, nonce)

                TransferProtocol.writeBytesFrame(dataOut, commit1)
                TransferProtocol.writeBytesFrame(dataOut, clientId.getPublicKeyEncoded())

                // Read server ephemeral pubkey + id
                TransferProtocol.readBytesFrame(dataIn)
                TransferProtocol.readBytesFrame(dataIn)

                // Reveal mismatched kp2!
                TransferProtocol.writeBytesFrame(dataOut, kp2.public.encoded)
                TransferProtocol.writeBytesFrame(dataOut, nonce)

                val status = dataIn.readByte()
                assertEquals(TransferProtocol.RESPONSE_AUTH_FAILED, status)
            }

            assertTrue("Server must abort on commitment mismatch", serverAborted.await())
        }
    }

    // --- Item 3 & 14: Approval Keyed by (batchId, peerFingerprint), Bounded Queue, IP Rate Limit ---

    @Test
    fun approvalCoordinator_keyedByBatchAndFingerprint_andRateLimited(): Unit = runBlocking {
        var now = 1_000L
        val coordinator = ApprovalCoordinator(
            maxPendingQueue = 3,
            maxPromptsPerIpWindow = 3,
            rateWindowMs = 60_000L,
            approvalTimeoutMs = 5_000L,
            clockMs = { now }
        )

        val batchId = "shared-batch-id"
        val reqAlice = IncomingTransferRequest(batchId, "fp-alice", "Alice", 2, 1024L, "123-456")
        val reqBobSameBatch = IncomingTransferRequest(batchId, "fp-bob", "Bob", 2, 1024L, "789-012")

        // Two sockets from Alice share one decision; Bob reusing batchId gets a separate prompt
        val aliceSock1 = async(Dispatchers.IO) { coordinator.awaitApproval(reqAlice, "192.168.49.10") }
        delay(30)
        val aliceSock2 = async(Dispatchers.IO) { coordinator.awaitApproval(reqAlice, "192.168.49.10") }
        val bobSock = async(Dispatchers.IO) { coordinator.awaitApproval(reqBobSameBatch, "192.168.49.20") }
        delay(30)

        assertEquals("Two distinct fingerprints = 2 queued requests", 2, coordinator.pendingCount())
        assertEquals("fp-alice", coordinator.currentPending.value?.senderFingerprint)

        // Approve Alice only -> both Alice sockets succeed; Bob is still pending and now head of queue
        coordinator.respond(batchId, "fp-alice", accept = true)
        assertTrue(aliceSock1.await())
        assertTrue(aliceSock2.await())

        assertEquals("fp-bob", coordinator.currentPending.value?.senderFingerprint)
        coordinator.respond(batchId, "fp-bob", accept = false)
        assertFalse(bobSock.await())

        // Per-IP rate limit: 4th prompt from same IP within window is dropped immediately
        val ip = "192.168.49.99"
        val jobs = (1..3).map { idx ->
            async(Dispatchers.IO) {
                coordinator.awaitApproval(
                    IncomingTransferRequest("b-$idx", "fp-$idx", "Spam", 1, 10L),
                    ip
                )
            }
        }
        delay(30)
        // 4th attempt exceeds both queue cap (3) and IP rate limit (3) -> immediately false
        val fourth = coordinator.awaitApproval(
            IncomingTransferRequest("b-4", "fp-4", "Spam", 1, 10L),
            ip
        )
        assertFalse(fourth)
        (1..3).forEach { idx -> coordinator.respond("b-$idx", "fp-$idx", false) }
        jobs.awaitAll()
    }

    // --- Item 10: Concurrent Parallel Range Completion Race Test ---

    @Test
    fun parallelCompletionCoordinator_exactlyOneWinnerRunsVerifyAndPublish(): Unit = runBlocking {
        val coordinator = ParallelCompletionCoordinator(followerTimeoutMs = 5_000L)
        val publishExecutions = AtomicInteger(0)

        val outcomes = (1..3).map {
            async(Dispatchers.IO) {
                coordinator.executeOnce("tx-parallel-race") {
                    publishExecutions.incrementAndGet()
                    delay(50)
                    TransferProtocol.VERIFY_OK
                }
            }
        }.awaitAll()

        assertEquals("Exactly one handler must hash & publish", 1, publishExecutions.get())
        assertEquals("Exactly one winner", 1, outcomes.count { it.first })
        assertTrue("All 3 handlers receive VERIFY_OK", outcomes.all { it.second == TransferProtocol.VERIFY_OK })
    }

    // --- Item 8 & 14: Stable transferId & .part Resume Test ---

    @Test
    fun partFileResume_stableTransferIdAndWholeFileSha256() {
        val id1 = TransferManager.computeStableTransferId("content://media/1", 1024L, 999L, "fp-recv")
        val id2 = TransferManager.computeStableTransferId("content://media/1", 1024L, 999L, "fp-recv")
        val idDifferent = TransferManager.computeStableTransferId("content://media/1", 2048L, 999L, "fp-recv")
        assertEquals(id1, id2)
        assertNotEquals(id1, idDifferent)

        val fullData = ByteArray(1024) { (it % 251).toByte() }
        val expectedSha = CryptoHelper.sha256(fullData)

        val tmpDir = createTempDir("flashshare_resume_test")
        try {
            val partFile = File(tmpDir, "$id1.part")
            // First attempt writes first 400 bytes then disconnects
            RandomAccessFile(partFile, "rw").use { raf ->
                raf.write(fullData, 0, 400)
            }
            assertEquals(400L, partFile.length())

            // Resumed attempt seeks to 400 and writes remaining 624 bytes
            val resumeOffset = partFile.length()
            RandomAccessFile(partFile, "rw").use { raf ->
                raf.seek(resumeOffset)
                raf.write(fullData, resumeOffset.toInt(), fullData.size - resumeOffset.toInt())
            }
            assertEquals(fullData.size.toLong(), partFile.length())
            assertArrayEquals(expectedSha, CryptoHelper.sha256(partFile.readBytes()))
        } finally {
            tmpDir.deleteRecursively()
        }
    }

    // --- Item 13 & 14: Web Server Rate Limit Lockout, Expiry Purge, IP-Bound Session ---

    @Test
    fun webServerAuthGuard_rateLimitLockoutIpBindingAndPurge() {
        var now = 10_000L
        val guard = WebServerAuthGuard(maxFailedAttempts = 5, lockoutMs = 60_000L, clockMs = { now })
        val token = CryptoHelper.generateRandomToken128Bit()

        // 5 failed attempts trigger lockout for attacker IP
        repeat(5) {
            assertFalse(guard.verifyTokenAndBindClient("wrong-token", token, "192.168.1.50"))
        }
        assertTrue(guard.isLockedOut("192.168.1.50"))
        // Even correct token is rejected while locked out
        assertFalse(guard.verifyTokenAndBindClient(token, token, "192.168.1.50"))

        // Legitimate first client binds session to its IP
        assertTrue(guard.verifyTokenAndBindClient(token, token, "192.168.1.20"))
        assertTrue(guard.verifyCookieForClient(token, token, "192.168.1.20"))
        // Different IP cannot steal the cookie or re-auth with the token
        assertFalse(guard.verifyCookieForClient(token, token, "192.168.1.30"))
        assertFalse(guard.verifyTokenAndBindClient(token, token, "192.168.1.30"))

        // Advance clock past lockout -> purgeExpiredRateLimits clears stale entries
        now += 61_000L
        guard.purgeExpiredRateLimits()
        assertFalse(guard.isLockedOut("192.168.1.50"))
        assertEquals(0, guard.rateLimitEntryCount())
    }

    // --- Existing Core Crypto, Sanitizer, QR v5, and vCard Tests ---

    @Test
    fun sanitizeFileName_blocksTraversalAndControlChars() {
        assertFalse(StorageOrganizer.sanitizeFileName("..").contains(".."))
        assertFalse(StorageOrganizer.sanitizeFileName(".") == ".")
        val traversal = StorageOrganizer.sanitizeFileName("../../etc/passwd")
        assertFalse(traversal.contains("/"))
        assertFalse(traversal.contains(".."))
        val overLong = "a".repeat(300) + ".mp4"
        val sanitizedLong = StorageOrganizer.sanitizeFileName(overLong)
        assertTrue(sanitizedLong.length <= StorageOrganizer.MAX_SANITIZED_NAME_LENGTH)
        assertTrue(sanitizedLong.endsWith(".mp4"))
    }

    @Test
    fun qrConnectionPayloadV5_roundTripAndRejectsLegacyV4() {
        val key = CryptoHelper.generateKeyBase64()
        val payload = QrConnectionPayload(
            role = QrRole.SEND,
            deviceId = "dev-fp-123",
            deviceName = "My Phone",
            ipAddress = "192.168.49.1",
            port = 8988,
            ssid = "DIRECT-FS-Flash1234",
            passphrase = "secretpass",
            encryptionKeyBase64 = key
        )
        val encoded = payload.encode()
        assertTrue(encoded.startsWith("FLASHSHARE|v5|"))
        val decoded = QrConnectionPayload.decode(encoded)
        assertNotNull(decoded)
        assertEquals(QrRole.SEND, decoded!!.role)
        assertEquals("192.168.49.1", decoded.ipAddress)
        assertEquals(8988, decoded.port)
        assertEquals(key, decoded.encryptionKeyBase64)

        assertNull(QrConnectionPayload.decode("https://example.com"))
        assertNull(QrConnectionPayload.decode("FLASHSHARE|v4|SEND|id|name|192.168.49.1|8988"))
    }

    @Test
    fun vCardExportAndImportRoundTrip() {
        val contacts = listOf(
            ParsedVCardContact("Abebe, Kebede", listOf("+251911000001"), listOf("abebe@example.com")),
            ParsedVCardContact("Bontu; Tola", listOf("+251922000002", "+251933000003"), emptyList())
        )
        val vcf = ContactsRepository.formatVCard30(contacts)
        val parsed = ContactsRepository.parseVCardLines(vcf.lineSequence())
        assertEquals(2, parsed.size)
        assertEquals("Abebe, Kebede", parsed[0].displayName)
        assertEquals(listOf("+251911000001"), parsed[0].phones)
        assertEquals(listOf("abebe@example.com"), parsed[0].emails)
        assertEquals("Bontu; Tola", parsed[1].displayName)
        assertEquals(2, parsed[1].phones.size)
    }


    // --- v5.1.0 Targeted Fix Unit Tests ---

    @Test
    fun wifiDirectPassphrase_is16CharsAlphanumericAndRandom() {
        val p1 = WifiDirectManager.generateStrongPassphrase()
        val p2 = WifiDirectManager.generateStrongPassphrase()
        assertEquals(16, p1.length)
        assertEquals(16, p2.length)
        assertTrue(p1.all { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' })
        assertTrue(p2.all { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' })
        assertNotEquals(p1, p2)
    }

    @Test
    fun transferManager_isAllowedPeerAddress_allowsOnlySiteLocalAndLinkLocal() {
        assertTrue(TransferManager.isAllowedPeerAddress(InetAddress.getByName("192.168.49.10")))
        assertTrue(TransferManager.isAllowedPeerAddress(InetAddress.getByName("10.0.0.5")))
        assertTrue(TransferManager.isAllowedPeerAddress(InetAddress.getByName("172.16.1.2")))
        assertTrue(TransferManager.isAllowedPeerAddress(InetAddress.getByName("169.254.10.20")))
        assertTrue(TransferManager.isAllowedPeerAddress(InetAddress.getByName("fe80::1")))
        assertFalse(TransferManager.isAllowedPeerAddress(InetAddress.getByName("8.8.8.8")))
        assertFalse(TransferManager.isAllowedPeerAddress(InetAddress.getByName("1.1.1.1")))
        assertFalse(TransferManager.isAllowedPeerAddress(null))
    }

    @Test
    fun localWebServer_buildContentDisposition_hasAsciiFallbackAndUtf8Star() {
        val header = LocalWebServer.buildContentDisposition("ፎቶ \"test\" 1.jpg")
        assertTrue(header.startsWith("attachment; filename=\""))
        assertTrue(header.contains("; filename*=UTF-8''"))
        val asciiPart = header.substringAfter("filename=\"").substringBefore("\";")
        assertTrue(asciiPart.all { it.code in 0x20..0x7E && it != '"' && it != '\\' })
        assertTrue(header.endsWith("%201.jpg"))
    }


    // --- Contacts Import Duplicate Detection Tests ---

    @Test
    fun contactsDedupe_phoneNormalizationMatchesCountryCodeAndLocal() {
        assertEquals("911223344", ContactsRepository.normalizePhone("+251911223344"))
        assertEquals("911223344", ContactsRepository.normalizePhone("0911223344"))
        assertEquals(
            ContactsRepository.normalizePhone("+251 911-223-344"),
            ContactsRepository.normalizePhone("0911 223 344")
        )
    }

    @Test
    fun contactsDedupe_sameNameAndSamePhoneIsDuplicate() {
        val index = ContactDedupeIndex()
        val first = ParsedVCardContact("Abebe", listOf("+251911223344"), emptyList())
        val second = ParsedVCardContact("  abebe ", listOf("0911223344"), emptyList())

        assertFalse(ContactsRepository.isDuplicateContact(first, index))
        ContactsRepository.registerContactInIndex(first, index)
        assertTrue(ContactsRepository.isDuplicateContact(second, index))
    }

    @Test
    fun contactsDedupe_differentNamesSharingPhoneAreNotDuplicates() {
        val index = ContactDedupeIndex()
        val mom = ParsedVCardContact("Mom", listOf("+251111223344"), emptyList())
        val home = ParsedVCardContact("Home", listOf("0111223344"), emptyList())

        assertFalse(ContactsRepository.isDuplicateContact(mom, index))
        ContactsRepository.registerContactInIndex(mom, index)
        assertFalse(ContactsRepository.isDuplicateContact(home, index))
    }

    @Test
    fun contactsDedupe_differentNamesSharingEmailAreNotDuplicates() {
        val index = ContactDedupeIndex()
        val first = ParsedVCardContact("Mom", emptyList(), listOf("family@example.com"))
        val second = ParsedVCardContact("Home", emptyList(), listOf("  FAMILY@EXAMPLE.COM "))

        ContactsRepository.registerContactInIndex(first, index)
        assertFalse(ContactsRepository.isDuplicateContact(second, index))
    }

    @Test
    fun contactsDedupe_emptyNameMatchesExistingEmptyNameByPhoneOnly() {
        val index = ContactDedupeIndex()
        val named = ParsedVCardContact("Mom", listOf("+251911223344"), emptyList())
        val unnamed1 = ParsedVCardContact("", listOf("+251922334455"), emptyList())
        val unnamedSameAsNamed = ParsedVCardContact("   ", listOf("0911223344"), emptyList())
        val unnamedDup = ParsedVCardContact("", listOf("0922334455"), emptyList())

        ContactsRepository.registerContactInIndex(named, index)
        ContactsRepository.registerContactInIndex(unnamed1, index)

        assertFalse(ContactsRepository.isDuplicateContact(unnamedSameAsNamed, index))
        assertTrue(ContactsRepository.isDuplicateContact(unnamedDup, index))
    }

    @Test
    fun contactsDedupe_nameOnlyContactMatchedByNormalizedName() {
        val index = ContactDedupeIndex()
        val existing = ParsedVCardContact("  Bontu   Tola ", emptyList(), emptyList())
        val incoming = ParsedVCardContact("bontu tola", emptyList(), emptyList())

        ContactsRepository.registerContactInIndex(existing, index)
        assertTrue(ContactsRepository.isDuplicateContact(incoming, index))
    }

    @Test
    fun contactsDedupe_differentPhoneAndEmailIsNotDuplicate() {
        val index = ContactDedupeIndex()
        val existing = ParsedVCardContact("Dawit", listOf("+251911223344"), listOf("dawit1@example.com"))
        val distinct = ParsedVCardContact("Dawit", listOf("+251922334455"), listOf("dawit2@example.com"))

        ContactsRepository.registerContactInIndex(existing, index)
        assertFalse(ContactsRepository.isDuplicateContact(distinct, index))
    }


    @Test
    fun webServerAuthGuard_accepts6DigitPinAndEnforcesLockout() {
        val guard = WebServerAuthGuard(maxFailedAttempts = 5, lockoutMs = 60_000L)
        val token = CryptoHelper.generateRandomToken128Bit()
        val pin = LocalWebServer.generatePin6()
        assertEquals(6, pin.length)
        assertTrue(pin.all { it in '0'..'9' })

        // Formatted PIN with space ("123 456") works for first client
        val formattedPin = pin.substring(0, 3) + " " + pin.substring(3)
        assertTrue(guard.verifyTokenOrPinAndBindClient(formattedPin, token, pin, "192.168.43.10"))
        assertTrue(guard.verifyCookieForClient(token, token, "192.168.43.10"))

        // Second IP cannot use PIN after first IP bound
        assertFalse(guard.verifyTokenOrPinAndBindClient(pin, token, pin, "192.168.43.20"))
    }

    private suspend fun runLoopbackHandshake(
        clientId: DeviceIdentityProvider,
        serverId: DeviceIdentityProvider,
        flags: Int,
        batchId: String,
        clientPsk: ByteArray?,
        serverPskResolver: (String) -> ByteArray?
    ): Pair<TransferProtocol.HandshakeResult, TransferProtocol.HandshakeResult> = kotlinx.coroutines.coroutineScope {
        ServerSocket(0, 4, InetAddress.getLoopbackAddress()).apply { soTimeout = 5_000 }.use { serverSocket ->
            val serverDeferred = async(Dispatchers.IO) {
                serverSocket.accept().use { sock ->
                    val dataIn = DataInputStream(sock.getInputStream())
                    val dataOut = DataOutputStream(sock.getOutputStream())
                    TransferProtocol.readAndVerifyVersionV5(dataIn)
                    val batch = TransferProtocol.readBatchHeaderV5Body(dataIn)
                    TransferProtocol.performServerHandshakeV5(
                        dataIn = dataIn,
                        dataOut = dataOut,
                        identity = serverId,
                        batch = batch,
                        resolveQrPskForBatch = serverPskResolver
                    )
                }
            }
            val clientResult = Socket(InetAddress.getLoopbackAddress(), serverSocket.localPort).apply { soTimeout = 5_000 }.use { sock ->
                val dataOut = DataOutputStream(sock.getOutputStream())
                val dataIn = DataInputStream(sock.getInputStream())
                val header = TransferProtocol.BatchHeaderV5(flags, batchId, "Sender", 1, 1, 512L)
                TransferProtocol.writeBatchHeaderV5(dataOut, header)
                TransferProtocol.performClientHandshakeV5(
                    dataOut = dataOut,
                    dataIn = dataIn,
                    identity = clientId,
                    flags = flags,
                    batchId = batchId,
                    roleLabel = header.roleLabel,
                    qrPskBytes = clientPsk
                )
            }
            clientResult to serverDeferred.await()
        }
    }
}
