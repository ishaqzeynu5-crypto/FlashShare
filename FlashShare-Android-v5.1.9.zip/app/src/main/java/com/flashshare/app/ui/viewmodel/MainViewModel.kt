package com.flashshare.app.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.flashshare.app.BuildConfig
import com.flashshare.app.R
import com.flashshare.app.data.local.TransferHistoryEntity
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.ContactsImportError
import com.flashshare.app.data.repository.ContactsImportResult
import com.flashshare.app.data.repository.ContactsRepository
import com.flashshare.app.data.repository.FileBrowserRepository
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.ApksInstallOutcome
import com.flashshare.app.data.storage.ApksInstaller
import com.flashshare.app.data.storage.InstallResultBus
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.AppLanguage
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.IncomingTransferRequest
import com.flashshare.app.domain.model.NearbyDevice
import com.flashshare.app.domain.model.PendingSasVerification
import com.flashshare.app.domain.model.PhoneCloneSelection
import com.flashshare.app.domain.model.PhoneCloneSummary
import com.flashshare.app.domain.model.QrConnectionPayload
import com.flashshare.app.domain.model.QrRole
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.network.WifiDirectManager
import com.flashshare.app.network.WifiDirectState
import com.flashshare.app.transfer.TransferManager
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.util.Formatters
import com.flashshare.app.webserver.LocalWebServer
import com.flashshare.app.webserver.WebServerState
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    @ApplicationContext private val appContext: Context,
    private val fileBrowserRepository: FileBrowserRepository,
    private val contactsRepository: ContactsRepository,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences,
    val storageOrganizer: StorageOrganizer,
    private val transferManager: TransferManager,
    private val wifiDirectManager: WifiDirectManager,
    private val localWebServer: LocalWebServer
) : ViewModel() {

    val language: StateFlow<AppLanguage> = userPreferences.language.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppLanguage.ENGLISH
    )

    val deviceName: StateFlow<String> = userPreferences.deviceName.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        userPreferences.defaultDeviceName()
    )

    val trustedDevices: StateFlow<Set<String>> = userPreferences.trustedDevices.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptySet()
    )

    val turboMode: StateFlow<Boolean> = userPreferences.turboMode.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        true
    )

    val wifiDirectState: StateFlow<WifiDirectState> = wifiDirectManager.state
    val nearbyPeers: StateFlow<List<NearbyDevice>> = wifiDirectManager.peers
    val isWifiP2pEnabled: StateFlow<Boolean> = wifiDirectManager.isWifiP2pEnabled

    val transfers: StateFlow<List<TransferItem>> = transferManager.transfers
    val isReceiveServerRunning: StateFlow<Boolean> = transferManager.isReceiveServerRunning
    val activePort: StateFlow<Int> = transferManager.activePort
    val sessionEncryptionKey: StateFlow<String> = transferManager.sessionEncryptionKey
    val pendingIncomingRequest: StateFlow<IncomingTransferRequest?> = transferManager.pendingIncomingRequest
    val pendingSenderSas: StateFlow<PendingSasVerification?> = transferManager.pendingSenderSas
    val lastReceivedVcfPath: StateFlow<String?> = transferManager.lastReceivedVcfLocation

    val webServerState: StateFlow<WebServerState> = localWebServer.state

    val history: StateFlow<List<TransferHistoryEntity>> = historyRepository.observeHistory().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    private val _selectedCategory = MutableStateFlow(FileCategory.PHOTOS)
    val selectedCategory: StateFlow<FileCategory> = _selectedCategory.asStateFlow()

    private val _categoryFiles = MutableStateFlow<Map<FileCategory, List<ShareableFile>>>(emptyMap())
    val categoryFiles: StateFlow<Map<FileCategory, List<ShareableFile>>> = _categoryFiles.asStateFlow()

    private val _isLoadingCategory = MutableStateFlow(false)
    val isLoadingCategory: StateFlow<Boolean> = _isLoadingCategory.asStateFlow()

    private val _selectedFiles = MutableStateFlow<Map<String, ShareableFile>>(emptyMap())
    val selectedFiles: StateFlow<Map<String, ShareableFile>> = _selectedFiles.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _cloneSummary = MutableStateFlow(PhoneCloneSummary())
    val cloneSummary: StateFlow<PhoneCloneSummary> = _cloneSummary.asStateFlow()

    private val _isPreparingClone = MutableStateFlow(false)
    val isPreparingClone: StateFlow<Boolean> = _isPreparingClone.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _deviceId = MutableStateFlow("")
    val deviceId: StateFlow<String> = _deviceId.asStateFlow()

    private val _pendingQrPullPayload = MutableStateFlow<QrConnectionPayload?>(null)
    val pendingQrPullPayload: StateFlow<QrConnectionPayload?> = _pendingQrPullPayload.asStateFlow()

    private val _pendingOpenSendRadar = MutableStateFlow(false)
    val pendingOpenSendRadar: StateFlow<Boolean> = _pendingOpenSendRadar.asStateFlow()

    private val _tempFilesSizeBytes = MutableStateFlow(0L)
    val tempFilesSizeBytes: StateFlow<Long> = _tempFilesSizeBytes.asStateFlow()

    private val isInstallingApks = AtomicBoolean(false)

    init {
        wifiDirectManager.initialize()
        viewModelScope.launch {
            _deviceId.value = userPreferences.getOrCreateDeviceId()
        }
        viewModelScope.launch {
            transferManager.securityAlerts.collect { alert ->
                _statusBanner.value = alert
            }
        }
        viewModelScope.launch {
            InstallResultBus.messages.collect { msg ->
                _statusBanner.value = msg
            }
        }
        refreshTempFilesSize()
    }

    fun refreshTempFilesSize() {
        viewModelScope.launch(Dispatchers.IO) {
            _tempFilesSizeBytes.value = storageOrganizer.getTemporaryFilesSizeBytes()
        }
    }

    fun clearTemporaryFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            storageOrganizer.clearAllTemporaryFiles()
            _tempFilesSizeBytes.value = storageOrganizer.getTemporaryFilesSizeBytes()
            _statusBanner.value = appContext.getString(R.string.settings_temp_files_cleared)
        }
    }

    /**
     * Installs a received .apks bundle off the main thread with a double-tap guard,
     * posting the localized status back to the main thread.
     */
    fun installApksBundle(pathOrUri: String) {
        if (!isInstallingApks.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val message = when (val outcome = ApksInstaller.installApksBundle(appContext, pathOrUri)) {
                    is ApksInstallOutcome.PermissionRequired -> appContext.getString(R.string.install_apks_permission_needed)
                    is ApksInstallOutcome.CommittedAwaitingUser -> appContext.getString(R.string.install_apks_starting)
                    is ApksInstallOutcome.Error -> outcome.message
                }
                withContext(Dispatchers.Main) {
                    showMessage(message)
                }
            } finally {
                isInstallingApks.set(false)
            }
        }
    }

    fun selectCategory(category: FileCategory) {
        _selectedCategory.value = category
        loadCategoryFiles(category)
    }

    fun loadCategoryFiles(category: FileCategory, forceRefresh: Boolean = false) {
        if (!forceRefresh && _categoryFiles.value.containsKey(category)) return
        viewModelScope.launch {
            _isLoadingCategory.value = true
            val loaded = fileBrowserRepository.loadCategory(category)
            _categoryFiles.update { it + (category to loaded) }
            _isLoadingCategory.value = false
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFileSelection(file: ShareableFile) {
        _selectedFiles.update { current ->
            if (current.containsKey(file.id)) current - file.id else current + (file.id to file)
        }
        syncStagedAndWebFiles()
    }

    fun selectAllFiles(files: List<ShareableFile>) {
        _selectedFiles.update { current ->
            val allSelected = files.isNotEmpty() && files.all { current.containsKey(it.id) }
            if (allSelected) {
                current - files.map { it.id }.toSet()
            } else {
                current + files.associateBy { it.id }
            }
        }
        syncStagedAndWebFiles()
    }

    /**
     * Adds non-media files chosen via Android Storage Access Framework (SAF) on Android 13-16.
     */
    fun addSafDocuments(context: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val added = mutableListOf<ShareableFile>()
        uris.distinct().forEach { uri ->
            var displayName = "document_${System.currentTimeMillis()}"
            var sizeBytes = 0L
            runCatching {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) cursor.getString(nameIdx)?.let { displayName = it }
                        if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            }
            val mime = context.contentResolver.getType(uri) ?: Formatters.inferMimeType(displayName)
            val file = ShareableFile(
                id = "saf_${uri.toString().hashCode()}",
                name = displayName,
                sizeBytes = sizeBytes.coerceAtLeast(1L),
                mimeType = mime,
                category = Formatters.inferCategory(displayName, mime),
                uri = uri,
                lastModified = System.currentTimeMillis()
            )
            added.add(file)
        }
        _categoryFiles.update { current ->
            val existingDocs = current[FileCategory.DOCUMENTS].orEmpty()
            val merged = (added + existingDocs).distinctBy { it.id }
            current + (FileCategory.DOCUMENTS to merged)
        }
        _selectedFiles.update { current -> current + added.associateBy { it.id } }
        syncStagedAndWebFiles()
    }

    /**
     * Handles ACTION_SEND / ACTION_SEND_MULTIPLE URIs from other apps.
     * Copies temporary-grant content:// URIs into share_cache (up to 512 MB cap) so grants do not
     * expire during long transfers if the activity is destroyed, and deduplicates by URI.
     */
    fun handleExternalShareUris(context: Context, uris: List<Uri>) {
        val uniqueUris = uris.distinct()
        if (uniqueUris.isEmpty()) return

        viewModelScope.launch {
            val prepared = mutableListOf<ShareableFile>()
            var oversizedCount = 0

            withContext(Dispatchers.IO) {
                uniqueUris.forEach { uri ->
                    var displayName = "shared_${System.currentTimeMillis()}"
                    var reportedSize = -1L
                    runCatching {
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (cursor.moveToFirst()) {
                                if (nameIdx >= 0) cursor.getString(nameIdx)?.let { displayName = it }
                                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) reportedSize = cursor.getLong(sizeIdx)
                            }
                        }
                    }

                    if (reportedSize > StorageOrganizer.MAX_SHARE_CACHE_COPY_BYTES) {
                        oversizedCount++
                        return@forEach
                    }

                    val safeName = StorageOrganizer.sanitizeFileName(displayName)
                    val mime = context.contentResolver.getType(uri) ?: Formatters.inferMimeType(safeName)
                    val stableId = "ext_${uri.toString().hashCode()}"

                    if (uri.scheme == "content") {
                        val cacheFile = File(
                            storageOrganizer.getShareCacheDir(),
                            "${stableId}_$safeName"
                        )
                        val copyResult = runCatching {
                            var copied = 0L
                            val buf = ByteArray(128 * 1024)
                            context.contentResolver.openInputStream(uri)?.use { input ->
                                FileOutputStream(cacheFile).use { output ->
                                    while (true) {
                                        val r = input.read(buf)
                                        if (r <= 0) break
                                        copied += r
                                        if (copied > StorageOrganizer.MAX_SHARE_CACHE_COPY_BYTES) {
                                            throw IllegalStateException("EXCEEDS_CAP")
                                        }
                                        output.write(buf, 0, r)
                                    }
                                }
                            } ?: throw IllegalStateException("UNREADABLE")
                            copied
                        }
                        if (copyResult.isFailure) {
                            cacheFile.delete()
                            if (copyResult.exceptionOrNull()?.message == "EXCEEDS_CAP") {
                                oversizedCount++
                            }
                            return@forEach
                        }
                        val actualSize = copyResult.getOrDefault(0L)
                        if (actualSize > 0L) {
                            prepared.add(
                                ShareableFile(
                                    id = stableId,
                                    name = safeName,
                                    sizeBytes = actualSize,
                                    mimeType = mime,
                                    category = Formatters.inferCategory(safeName, mime),
                                    uri = Uri.fromFile(cacheFile),
                                    filePath = cacheFile.absolutePath,
                                    lastModified = cacheFile.lastModified(),
                                    isCachedTempFile = true
                                )
                            )
                        }
                    } else {
                        prepared.add(
                            ShareableFile(
                                id = stableId,
                                name = safeName,
                                sizeBytes = reportedSize.coerceAtLeast(1L),
                                mimeType = mime,
                                category = Formatters.inferCategory(safeName, mime),
                                uri = uri,
                                filePath = uri.path,
                                lastModified = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }

            if (oversizedCount > 0) {
                _statusBanner.value = appContext.getString(
                    R.string.error_share_too_large,
                    Formatters.formatBytes(StorageOrganizer.MAX_SHARE_CACHE_COPY_BYTES)
                )
            }
            if (prepared.isNotEmpty()) {
                _selectedFiles.update { current ->
                    val updated = current.toMutableMap()
                    prepared.forEach { f ->
                        if (updated.values.none { it.uri == f.uri || it.id == f.id }) {
                            updated[f.id] = f
                        }
                    }
                    updated
                }
                syncStagedAndWebFiles()
                refreshTempFilesSize()
                _pendingOpenSendRadar.value = true
            }
        }
    }

    /**
     * Handles ACTION_SEND with EXTRA_TEXT (no EXTRA_STREAM) by writing UTF-8 text to
     * share_cache/shared_text_<timestamp>.txt off the main thread and staging it for transfer.
     */
    fun handleExternalSharedText(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val staged = withContext(Dispatchers.IO) {
                runCatching {
                    val ts = System.currentTimeMillis()
                    val fileName = "shared_text_$ts.txt"
                    val outFile = File(storageOrganizer.getShareCacheDir(), fileName)
                    outFile.writeText(text, Charsets.UTF_8)
                    ShareableFile(
                        id = "ext_text_$ts",
                        name = fileName,
                        sizeBytes = outFile.length().coerceAtLeast(1L),
                        mimeType = "text/plain",
                        category = FileCategory.DOCUMENTS,
                        uri = Uri.fromFile(outFile),
                        filePath = outFile.absolutePath,
                        lastModified = outFile.lastModified(),
                        isCachedTempFile = true
                    )
                }.getOrNull()
            } ?: return@launch

            _selectedFiles.update { current -> current + (staged.id to staged) }
            syncStagedAndWebFiles()
            refreshTempFilesSize()
            _pendingOpenSendRadar.value = true
        }
    }

    fun clearSelection() {
        _selectedFiles.value = emptyMap()
        syncStagedAndWebFiles()
    }

    fun startNearbyDiscovery() {
        wifiDirectManager.startDiscovery()
    }

    fun stopNearbyDiscovery() {
        wifiDirectManager.stopDiscovery()
    }

    fun startQrHostSession() {
        val staged = _selectedFiles.value.values.toList()
        transferManager.stageFilesForQrPull(staged)
        wifiDirectManager.startReceiverGroup()
        transferManager.startReceiveServer(TransferProtocol.DEFAULT_PORT)
    }

    fun stopHostSession() {
        transferManager.stopReceiveServer()
        wifiDirectManager.disconnect()
    }

    fun connectToPeer(device: NearbyDevice) {
        wifiDirectManager.connectToPeer(device)
    }

    fun handleScannedQr(rawQr: String): Boolean {
        val payload = QrConnectionPayload.decode(rawQr) ?: return false
        if (payload.role == QrRole.SEND) {
            _pendingQrPullPayload.value = payload
        } else {
            _pendingQrPullPayload.value = null
        }
        wifiDirectManager.connectByQrPayload(payload)
        return true
    }

    fun consumePendingQrPullIfConnected(): Boolean {
        val pull = _pendingQrPullPayload.value ?: return false
        val conn = wifiDirectState.value as? WifiDirectState.Connected ?: return false
        _pendingQrPullPayload.value = null
        transferManager.pullFilesFromSender(
            hostIp = conn.groupOwnerIp,
            port = conn.port,
            peerName = conn.peerName,
            encryptionKeyBase64 = pull.encryptionKeyBase64 ?: conn.encryptionKeyBase64
        )
        return true
    }

    fun connectManually(ipAddress: String, port: Int = TransferProtocol.DEFAULT_PORT) {
        val cleanIp = ipAddress.trim()
        if (cleanIp.isBlank()) return
        wifiDirectManager.connectDirectlyByIp(cleanIp, cleanIp, port = port)
    }

    fun disconnectPeer() {
        _pendingQrPullPayload.value = null
        wifiDirectManager.disconnect()
    }

    fun respondToIncomingRequest(
        batchId: String,
        senderFingerprint: String,
        accept: Boolean,
        trustDevice: Boolean
    ) {
        transferManager.respondToIncomingRequest(batchId, senderFingerprint, accept, trustDevice)
    }

    fun respondToSenderSas(
        batchId: String,
        peerFingerprint: String,
        peerName: String,
        codesMatch: Boolean,
        pinReceiver: Boolean
    ) {
        transferManager.respondToSenderSas(batchId, peerFingerprint, peerName, codesMatch, pinReceiver)
    }

    fun buildHostQrPayload(): String? {
        val state = wifiDirectState.value
        val ip = when (state) {
            is WifiDirectState.HostingGroup -> state.ipAddress
            is WifiDirectState.Connected -> state.groupOwnerIp
            else -> Formatters.getLocalIpAddress()
        } ?: return null

        val ssid = (state as? WifiDirectState.HostingGroup)?.ssid
        val pass = (state as? WifiDirectState.HostingGroup)?.passphrase
        val role = if (_selectedFiles.value.isNotEmpty()) QrRole.SEND else QrRole.RECEIVE
        return QrConnectionPayload(
            role = role,
            deviceId = _deviceId.value,
            deviceName = deviceName.value,
            ipAddress = ip,
            port = activePort.value,
            ssid = ssid,
            passphrase = pass,
            encryptionKeyBase64 = transferManager.sessionEncryptionKey.value
        ).encode()
    }

    /**
     * Sends selected files if connected with a valid session.
     * If the connection was QR-authenticated and its one-time key has rotated, prompts the user
     * to scan the new QR code rather than silently failing with a stale key.
     */
    fun sendSelectedFiles(): Boolean {
        val files = _selectedFiles.value.values.toList()
        if (files.isEmpty()) return false
        val conn = wifiDirectState.value as? WifiDirectState.Connected ?: return false
        if (conn.wasQrConnection && conn.encryptionKeyBase64.isNullOrBlank()) {
            _statusBanner.value = appContext.getString(R.string.error_qr_key_rotated)
            return false
        }
        _selectedFiles.value = emptyMap()
        syncStagedAndWebFiles()
        viewModelScope.launch {
            val prepared = files.map { f ->
                if (f.isSplitApk) fileBrowserRepository.prepareAppForTransfer(f) else f
            }
            transferManager.sendFiles(
                targetIp = conn.groupOwnerIp,
                port = conn.port,
                peerName = conn.peerName,
                files = prepared,
                encryptionKeyBase64 = conn.encryptionKeyBase64
            )
        }
        return true
    }

    /**
     * Resends a history item. If connected with a rotated QR key, shows "Scan the new QR code"
     * and stages the file so the user can rescan cleanly instead of failing silently.
     */
    fun resendHistoryItem(entry: TransferHistoryEntity): Boolean {
        val file = entry.localPath?.takeIf { !it.startsWith("content://") }?.let { File(it) }?.takeIf { it.exists() }
        val uri = when {
            file != null -> Uri.fromFile(file)
            entry.localPath?.startsWith("content://") == true -> Uri.parse(entry.localPath)
            !entry.sourceUriString.isNullOrBlank() -> Uri.parse(entry.sourceUriString)
            else -> {
                _statusBanner.value = appContext.getString(R.string.history_file_missing)
                return false
            }
        }
        val shareable = ShareableFile(
            id = "resend_${entry.id}_${System.currentTimeMillis()}",
            name = entry.fileName,
            sizeBytes = file?.length() ?: entry.sizeBytes,
            mimeType = entry.mimeType,
            category = entry.fileCategoryEnum(),
            uri = uri,
            filePath = file?.absolutePath,
            lastModified = file?.lastModified() ?: entry.timestamp
        )
        val conn = wifiDirectState.value as? WifiDirectState.Connected
        return if (conn != null && (!conn.wasQrConnection || !conn.encryptionKeyBase64.isNullOrBlank())) {
            transferManager.sendFiles(
                targetIp = conn.groupOwnerIp,
                port = conn.port,
                peerName = conn.peerName,
                files = listOf(shareable),
                encryptionKeyBase64 = conn.encryptionKeyBase64
            )
            true
        } else {
            if (conn != null && conn.wasQrConnection && conn.encryptionKeyBase64.isNullOrBlank()) {
                _statusBanner.value = appContext.getString(R.string.error_qr_key_rotated)
            }
            _selectedFiles.update { it + (shareable.id to shareable) }
            syncStagedAndWebFiles()
            false
        }
    }

    fun pauseTransfer(id: String) = transferManager.pauseTransfer(id)
    fun resumeTransfer(id: String) = transferManager.resumeTransfer(id)
    fun cancelTransfer(id: String) = transferManager.cancelTransfer(id)
    fun pauseAllActive() = transferManager.pauseAllActive()
    fun resumeAllPaused() = transferManager.resumeAllPaused()
    fun cancelAllActive() = transferManager.cancelAllActive()
    fun clearFinishedTransfers() = transferManager.clearFinished()

    fun loadPhoneCloneSummary() {
        viewModelScope.launch {
            _isPreparingClone.value = true
            val contacts = if (BuildConfig.ENABLE_CONTACTS_CLONE) contactsRepository.getContactCount() else 0
            val photos = fileBrowserRepository.loadCategory(FileCategory.PHOTOS)
            val videos = fileBrowserRepository.loadCategory(FileCategory.VIDEOS)
            val music = fileBrowserRepository.loadCategory(FileCategory.MUSIC)
            _categoryFiles.update {
                it + mapOf(
                    FileCategory.PHOTOS to photos,
                    FileCategory.VIDEOS to videos,
                    FileCategory.MUSIC to music
                )
            }
            _cloneSummary.value = PhoneCloneSummary(
                contactCount = contacts,
                photoCount = photos.size,
                photoBytes = photos.sumOf { it.sizeBytes },
                videoCount = videos.size,
                videoBytes = videos.sumOf { it.sizeBytes },
                musicCount = music.size,
                musicBytes = music.sumOf { it.sizeBytes }
            )
            _isPreparingClone.value = false
        }
    }

    fun startPhoneCloneSend(selection: PhoneCloneSelection, onReadyToSend: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isPreparingClone.value = true
            val batch = mutableListOf<ShareableFile>()
            if (BuildConfig.ENABLE_CONTACTS_CLONE && selection.includeContacts) {
                contactsRepository.exportContactsToVcf()?.let { batch.add(it) }
            }
            if (selection.includePhotos) {
                batch.addAll(_categoryFiles.value[FileCategory.PHOTOS] ?: fileBrowserRepository.loadCategory(FileCategory.PHOTOS))
            }
            if (selection.includeVideos) {
                batch.addAll(_categoryFiles.value[FileCategory.VIDEOS] ?: fileBrowserRepository.loadCategory(FileCategory.VIDEOS))
            }
            if (selection.includeMusic) {
                batch.addAll(_categoryFiles.value[FileCategory.MUSIC] ?: fileBrowserRepository.loadCategory(FileCategory.MUSIC))
            }
            _isPreparingClone.value = false

            if (batch.isEmpty()) {
                onReadyToSend(false)
                return@launch
            }

            val conn = wifiDirectState.value as? WifiDirectState.Connected
            if (conn != null && (!conn.wasQrConnection || !conn.encryptionKeyBase64.isNullOrBlank())) {
                transferManager.sendFiles(
                    targetIp = conn.groupOwnerIp,
                    port = conn.port,
                    peerName = conn.peerName,
                    files = batch,
                    encryptionKeyBase64 = conn.encryptionKeyBase64
                )
                onReadyToSend(true)
            } else {
                if (conn != null && conn.wasQrConnection && conn.encryptionKeyBase64.isNullOrBlank()) {
                    _statusBanner.value = appContext.getString(R.string.error_qr_key_rotated)
                }
                _selectedFiles.value = batch.associateBy { it.id }
                syncStagedAndWebFiles()
                onReadyToSend(false)
            }
        }
    }

    fun consumePendingOpenSendRadar() {
        _pendingOpenSendRadar.value = false
    }

    fun importReceivedContacts(onResult: (ContactsImportResult) -> Unit) {
        if (!BuildConfig.ENABLE_CONTACTS_CLONE) return
        val loc = lastReceivedVcfPath.value ?: return
        viewModelScope.launch {
            val result = contactsRepository.importContactsFromLocation(loc)
            transferManager.clearLastReceivedVcf()
            onResult(result)
        }
    }

    fun importResultMessage(result: ContactsImportResult): String {
        val summary = appContext.getString(
            R.string.clone_contacts_import_summary,
            result.imported,
            result.skippedDuplicates,
            result.failed
        )
        return when (result.error) {
            ContactsImportError.FILE_UNREADABLE ->
                appContext.getString(R.string.clone_contacts_import_error_unreadable)
            ContactsImportError.NO_CONTACTS_FOUND ->
                appContext.getString(R.string.clone_contacts_import_error_empty)
            ContactsImportError.PERMISSION_DENIED ->
                "${appContext.getString(R.string.clone_contacts_import_error_permission)}\n$summary"
            null -> summary
        }
    }

    fun startWebServer() {
        wifiDirectManager.stopDiscovery()
        syncStagedAndWebFiles()
        localWebServer.start()
    }

    fun stopWebServer() {
        localWebServer.stop()
    }

    private fun syncStagedAndWebFiles() {
        val list = _selectedFiles.value.values.toList()
        localWebServer.setSharedFiles(list)
        transferManager.stageFilesForQrPull(list)
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch { historyRepository.deleteEntry(id) }
    }

    fun clearAllHistory() {
        viewModelScope.launch { historyRepository.clearAll() }
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch {
            userPreferences.setLanguage(lang)
            val locales = LocaleListCompat.forLanguageTags(lang.tag)
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }

    fun setDeviceName(name: String) {
        viewModelScope.launch { userPreferences.setDeviceName(name) }
    }

    fun clearTrustedDevices() {
        viewModelScope.launch { userPreferences.clearTrustedDevices() }
    }

    fun setTurboMode(enabled: Boolean) {
        viewModelScope.launch { userPreferences.setTurboMode(enabled) }
    }

    fun showMessage(message: String) {
        _statusBanner.value = message
    }

    fun clearMessage() {
        _statusBanner.value = null
    }

    override fun onCleared() {
        wifiDirectManager.release()
        super.onCleared()
    }
}
