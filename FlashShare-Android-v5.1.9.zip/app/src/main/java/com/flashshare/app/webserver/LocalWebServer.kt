package com.flashshare.app.webserver

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import com.flashshare.app.R
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.transfer.CryptoHelper
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton

data class WebServerState(
    val isRunning: Boolean = false,
    val url: String = "",
    val qrUrl: String = "",
    val accessToken: String = "",
    val accessPin: String = "",
    val remainingTimeoutSeconds: Long = 0L,
    val sharedFiles: List<ShareableFile> = emptyList(),
    val connectedClients: List<String> = emptyList(),
    val error: String? = null
)

/**
 * Pure-Kotlin testable auth, IP-binding, and per-IP rate-limit guard for LocalWebServer.
 */
class WebServerAuthGuard(
    private val maxFailedAttempts: Int = 5,
    private val lockoutMs: Long = 5L * 60L * 1000L,
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private data class RateLimitEntry(val failures: Int, val lockedUntilMs: Long, val lastAttemptMs: Long)

    private val rateLimits = ConcurrentHashMap<String, RateLimitEntry>()
    private val lock = Any()

    @Volatile
    private var boundClientIp: String? = null

    fun isLockedOut(remoteIp: String): Boolean {
        val now = clockMs()
        val entry = rateLimits[remoteIp] ?: return false
        if (entry.lockedUntilMs > now) return true
        if (entry.lockedUntilMs in 1L..now) {
            rateLimits.remove(remoteIp, entry)
        }
        return false
    }

    fun verifyTokenAndBindClient(submittedToken: String?, expectedToken: String, remoteIp: String): Boolean =
        verifyTokenOrPinAndBindClient(submittedToken, expectedToken, expectedPin = null, remoteIp = remoteIp)

    fun verifyTokenOrPinAndBindClient(
        submitted: String?,
        expectedToken: String,
        expectedPin: String?,
        remoteIp: String
    ): Boolean {
        val now = clockMs()
        if (isLockedOut(remoteIp)) return false
        val clean = submitted?.trim()
        val tokenOk = clean != null && CryptoHelper.constantTimeEquals(clean, expectedToken)
        val pinOk = !expectedPin.isNullOrEmpty() && clean != null &&
            CryptoHelper.constantTimeEquals(clean.replace(" ", ""), expectedPin)
        if (!tokenOk && !pinOk) {
            recordAuthFailure(remoteIp, now)
            return false
        }
        synchronized(lock) {
            // Bind the authenticated cookie session to the first client IP
            val existingIp = boundClientIp
            if (existingIp != null && existingIp != remoteIp) {
                recordAuthFailure(remoteIp, now)
                return false
            }
            boundClientIp = remoteIp
            rateLimits.remove(remoteIp)
            return true
        }
    }

    fun verifyCookieForClient(cookieToken: String?, expectedToken: String, remoteIp: String): Boolean {
        if (cookieToken == null || !CryptoHelper.constantTimeEquals(cookieToken, expectedToken)) {
            return false
        }
        val bound = boundClientIp ?: return false
        return bound == remoteIp
    }

    fun getBoundClientIp(): String? = boundClientIp

    fun purgeExpiredRateLimits() {
        val now = clockMs()
        val iter = rateLimits.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next().value
            val expiredLockout = e.lockedUntilMs > 0L && e.lockedUntilMs <= now
            val staleFailures = e.lockedUntilMs == 0L && (now - e.lastAttemptMs) > lockoutMs
            if (expiredLockout || staleFailures) {
                iter.remove()
            }
        }
    }

    fun rateLimitEntryCount(): Int = rateLimits.size

    fun reset() {
        synchronized(lock) {
            boundClientIp = null
            rateLimits.clear()
        }
    }

    private fun recordAuthFailure(ip: String, nowMs: Long) {
        synchronized(lock) {
            val prev = rateLimits[ip]
            val failures = (prev?.failures ?: 0) + 1
            val lockedUntil = if (failures >= maxFailedAttempts) nowMs + lockoutMs else 0L
            rateLimits[ip] = RateLimitEntry(failures, lockedUntil, nowMs)
        }
    }
}

/**
 * Hardened local HTTP/1.1 file-sharing server:
 * - Binds strictly to the active Wi-Fi/hotspot interface IP (never 0.0.0.0)
 * - 128-bit cryptographic session token (valid until sharing stops) with constant-time verification
 * - Binds the authenticated cookie session to the first client IP
 * - Per-IP rate limiting with periodic expiry purge
 * - Exact Cookie parsing (SameSite=Strict, HttpOnly); strips token from browser URL via 303 redirect
 * - Strict header count/size limits & max 8 concurrent connections
 * - Opens file stream BEFORE sending headers; supports suffix ranges & HTTP 416
 * - Auto-stops after 15 minutes of inactivity
 */
@Singleton
class LocalWebServer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val TAG = "LocalWebServer"
        private const val INACTIVITY_TIMEOUT_SECONDS = 15L * 60L
        private const val MAX_HEADERS = 32
        private const val MAX_HEADER_LINE_LENGTH = 4_096
        private const val MAX_TOTAL_HEADER_BYTES = 16_384
        private const val MAX_CONCURRENT_CONNECTIONS = 8
        private const val RATE_LIMIT_PURGE_INTERVAL_SEC = 30L
        private const val CSP_HEADER = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'"
        private val pinRandom = SecureRandom()

        fun generatePin6(): String = "%06d".format(pinRandom.nextInt(1_000_000))

        fun buildContentDisposition(fileName: String): String {
            val asciiFallback = buildString(fileName.length) {
                for (ch in fileName) {
                    val code = ch.code
                    if (code in 0x20..0x7E && ch != '"' && ch != '\\' && ch != ';') {
                        append(ch)
                    } else {
                        append('_')
                    }
                }
            }.trim().ifBlank { "download" }
            val encodedName = URLEncoder.encode(fileName, "UTF-8").replace("+", "%20")
            return "attachment; filename=\"$asciiFallback\"; filename*=UTF-8''$encodedName"
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lastActivityMs = AtomicLong(System.currentTimeMillis())
    private val connectionLimiter = Semaphore(MAX_CONCURRENT_CONNECTIONS)
    private val authGuard = WebServerAuthGuard()
    private val connectedClientIps = ConcurrentHashMap.newKeySet<String>()

    private val _state = MutableStateFlow(WebServerState())
    val state: StateFlow<WebServerState> = _state.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var timeoutJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    fun setSharedFiles(files: List<ShareableFile>) {
        _state.value = _state.value.copy(sharedFiles = files)
    }

    fun start(preferredPort: Int = 8080) {
        if (_state.value.isRunning) return
        val token = CryptoHelper.generateRandomToken128Bit()
        val pin = generatePin6()
        lastActivityMs.set(System.currentTimeMillis())
        authGuard.reset()
        connectedClientIps.clear()

        serverJob = scope.launch {
            val ip = Formatters.getLocalIpAddress()
            if (ip.isNullOrBlank()) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    error = context.getString(R.string.error_server_start)
                )
                return@launch
            }

            val bindAddr = InetAddress.getByName(ip)
            var boundSocket: ServerSocket? = null
            var boundPort = preferredPort

            for (port in preferredPort..(preferredPort + 10)) {
                try {
                    boundSocket = ServerSocket().apply {
                        reuseAddress = true
                        bind(InetSocketAddress(bindAddr, port))
                    }
                    boundPort = port
                    break
                } catch (_: Exception) {
                    // Port busy; try next
                }
            }

            if (boundSocket == null) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    error = context.getString(R.string.error_server_start)
                )
                return@launch
            }

            serverSocket = boundSocket
            val baseUrl = "http://$ip:$boundPort"
            // QR uses /auth?token=... (token remains valid until sharing stops; 303 redirect strips it from URL bar)
            val qrUrl = "$baseUrl/auth?token=$token"
            _state.value = _state.value.copy(
                isRunning = true,
                url = baseUrl,
                qrUrl = qrUrl,
                accessToken = token,
                accessPin = pin,
                remainingTimeoutSeconds = INACTIVITY_TIMEOUT_SECONDS,
                connectedClients = emptyList(),
                error = null
            )

            acquireTransferLocks()
            startTimeoutWatcher()

            try {
                while (isActive && !boundSocket.isClosed) {
                    val client = try {
                        boundSocket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    if (!connectionLimiter.tryAcquire()) {
                        runCatching { client.close() }
                        continue
                    }
                    launch {
                        try {
                            runCatching {
                                client.tcpNoDelay = true
                                client.sendBufferSize = 1024 * 1024
                            }
                            handleHttpClient(client, token, pin)
                        } finally {
                            connectionLimiter.release()
                        }
                    }
                }
            } finally {
                releaseTransferLocks()
                _state.value = _state.value.copy(
                    isRunning = false,
                    remainingTimeoutSeconds = 0L,
                    connectedClients = emptyList()
                )
            }
        }
    }

    fun stop() {
        releaseTransferLocks()
        timeoutJob?.cancel()
        timeoutJob = null
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        authGuard.reset()
        connectedClientIps.clear()
        _state.value = _state.value.copy(
            isRunning = false,
            url = "",
            qrUrl = "",
            accessToken = "",
            accessPin = "",
            remainingTimeoutSeconds = 0L,
            connectedClients = emptyList()
        )
    }

    private fun startTimeoutWatcher() {
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            var tickCount = 0L
            while (isActive && _state.value.isRunning) {
                delay(1_000L)
                tickCount++
                if (tickCount % RATE_LIMIT_PURGE_INTERVAL_SEC == 0L) {
                    authGuard.purgeExpiredRateLimits()
                }
                val idleSec = (System.currentTimeMillis() - lastActivityMs.get()) / 1000L
                val remaining = (INACTIVITY_TIMEOUT_SECONDS - idleSec).coerceAtLeast(0L)
                _state.value = _state.value.copy(remainingTimeoutSeconds = remaining)
                if (remaining == 0L) {
                    stop()
                    break
                }
            }
        }
    }

    private fun handleHttpClient(socket: Socket, expectedToken: String, expectedPin: String) {
        try {
            socket.soTimeout = 15_000
            socket.tcpNoDelay = true
            socket.sendBufferSize = 2 * 1024 * 1024

            val remoteIp = socket.inetAddress?.hostAddress ?: "unknown"
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val out = BufferedOutputStream(socket.getOutputStream(), 1024 * 1024)

            val requestLine = readBoundedLine(reader) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                sendSimpleResponse(out, 400, "Bad Request", "text/plain", "Bad Request")
                return
            }
            val method = parts[0]
            val rawTarget = parts[1]
            val path = rawTarget.substringBefore("?")
            val query = rawTarget.substringAfter("?", "")

            val headers = mutableMapOf<String, String>()
            var totalHeaderBytes = requestLine.length
            var headerCount = 0
            while (true) {
                val line = readBoundedLine(reader) ?: break
                if (line.isEmpty()) break
                headerCount++
                totalHeaderBytes += line.length
                if (headerCount > MAX_HEADERS || totalHeaderBytes > MAX_TOTAL_HEADER_BYTES) {
                    sendSimpleResponse(out, 431, "Request Header Fields Too Large", "text/plain", "Headers too large")
                    return
                }
                val idx = line.indexOf(':')
                if (idx > 0) {
                    headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
                }
            }

            if (method != "GET" && method != "HEAD" && method != "POST") {
                sendSimpleResponse(out, 405, "Method Not Allowed", "text/plain", "Method Not Allowed")
                return
            }

            if (authGuard.isLockedOut(remoteIp)) {
                sendSimpleResponse(out, 429, "Too Many Requests", "text/plain", "Too many failed attempts. Try later.")
                return
            }

            val now = System.currentTimeMillis()

            // /auth endpoint: validates session token (valid until sharing stops), binds session to first client IP,
            // sets HttpOnly SameSite=Strict cookie, and 303 redirects to /
            if (path == "/auth") {
                val submitted = if (method == "POST") {
                    val contentLen = headers["content-length"]?.toIntOrNull()?.coerceIn(0, 1024) ?: 0
                    val bodyChars = CharArray(contentLen)
                    var readTotal = 0
                    while (readTotal < contentLen) {
                        val r = reader.read(bodyChars, readTotal, contentLen - readTotal)
                        if (r <= 0) break
                        readTotal += r
                    }
                    extractQueryParam(String(bodyChars, 0, readTotal), "token")
                } else {
                    extractQueryParam(query, "token")
                }

                if (authGuard.verifyTokenOrPinAndBindClient(submitted, expectedToken, expectedPin, remoteIp)) {
                    lastActivityMs.set(now)
                    if (connectedClientIps.add(remoteIp)) {
                        _state.value = _state.value.copy(connectedClients = connectedClientIps.toList())
                    }
                    if (method == "GET") {
                        // Return file list directly on QR scan (200 OK + Set-Cookie) so mobile browsers never drop cookie on redirect
                        val htmlBytes = buildIndexHtml(_state.value.sharedFiles).toByteArray(Charsets.UTF_8)
                        val directHeaders = buildString {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: text/html; charset=utf-8\r\n")
                            append("Content-Length: ${htmlBytes.size}\r\n")
                            append("Set-Cookie: fs_token=$expectedToken; Path=/; HttpOnly; SameSite=Strict\r\n")
                            append("Cache-Control: no-store\r\n")
                            append("X-Content-Type-Options: nosniff\r\n")
                            append("Referrer-Policy: no-referrer\r\n")
                            append("Content-Security-Policy: $CSP_HEADER\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(directHeaders.toByteArray(Charsets.US_ASCII))
                        out.write(htmlBytes)
                        out.flush()
                    } else {
                        val redirectHeaders = buildString {
                            append("HTTP/1.1 303 See Other\r\n")
                            append("Location: /\r\n")
                            append("Set-Cookie: fs_token=$expectedToken; Path=/; HttpOnly; SameSite=Strict\r\n")
                            append("Cache-Control: no-store\r\n")
                            append("X-Content-Type-Options: nosniff\r\n")
                            append("Referrer-Policy: no-referrer\r\n")
                            append("Content-Security-Policy: $CSP_HEADER\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(redirectHeaders.toByteArray(Charsets.US_ASCII))
                        out.flush()
                    }
                } else {
                    val html = buildTokenPromptHtml(wrongToken = true)
                    sendSimpleResponse(out, 401, "Unauthorized", "text/html; charset=utf-8", html)
                }
                return
            }

            // Exact cookie verification bound to the authenticated client IP (constant time, no .contains())
            val cookieToken = parseExactCookie(headers["cookie"], "fs_token")
            if (!authGuard.verifyCookieForClient(cookieToken, expectedToken, remoteIp)) {
                val html = buildTokenPromptHtml(wrongToken = false)
                sendSimpleResponse(out, 200, "OK", "text/html; charset=utf-8", html)
                return
            }

            lastActivityMs.set(now)

            when {
                path == "/" || path == "/index.html" -> {
                    val html = buildIndexHtml(_state.value.sharedFiles)
                    sendSimpleResponse(out, 200, "OK", "text/html; charset=utf-8", html)
                }
                path.startsWith("/download/") -> {
                    val index = path.removePrefix("/download/").toIntOrNull()
                    val files = _state.value.sharedFiles
                    if (index == null || index !in files.indices) {
                        sendSimpleResponse(out, 404, "Not Found", "text/plain", "File not found")
                    } else {
                        streamFileResponse(out, files[index], headers["range"], method == "HEAD")
                    }
                }
                else -> {
                    sendSimpleResponse(out, 404, "Not Found", "text/plain", "Not Found")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "HTTP client handling error", e)
        } finally {
            runCatching { socket.close() }
        }
    }

    private fun readBoundedLine(reader: BufferedReader): String? {
        val sb = StringBuilder()
        while (true) {
            val ch = reader.read()
            if (ch == -1) return if (sb.isEmpty()) null else sb.toString()
            if (ch == '\n'.code) break
            if (ch != '\r'.code) {
                if (sb.length >= MAX_HEADER_LINE_LENGTH) {
                    throw IllegalStateException("HTTP header line too long")
                }
                sb.append(ch.toChar())
            }
        }
        return sb.toString()
    }

    private fun parseExactCookie(cookieHeader: String?, name: String): String? {
        if (cookieHeader.isNullOrBlank()) return null
        return cookieHeader.split(";")
            .map { it.trim() }
            .firstNotNullOfOrNull { pair ->
                val eq = pair.indexOf('=')
                if (eq > 0 && pair.substring(0, eq).trim() == name) {
                    pair.substring(eq + 1).trim()
                } else null
            }
    }

    private fun extractQueryParam(query: String, key: String): String? {
        if (query.isBlank()) return null
        return query.split("&")
            .firstNotNullOfOrNull { kv ->
                val pair = kv.split("=", limit = 2)
                if (pair.size == 2 && pair[0] == key) {
                    runCatching { URLDecoder.decode(pair[1], "UTF-8") }.getOrNull()
                } else null
            }
    }

    private fun sendSimpleResponse(
        out: BufferedOutputStream,
        code: Int,
        reason: String,
        contentType: String,
        body: String
    ) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val header = buildString {
            append("HTTP/1.1 $code $reason\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            append("Cache-Control: no-store\r\n")
            append("X-Content-Type-Options: nosniff\r\n")
            append("Referrer-Policy: no-referrer\r\n")
            append("Content-Security-Policy: $CSP_HEADER\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(bytes)
        out.flush()
    }

    private fun streamFileResponse(
        out: BufferedOutputStream,
        file: ShareableFile,
        rangeHeader: String?,
        headOnly: Boolean
    ) {
        val totalSize = file.sizeBytes
        var start = 0L
        var end = (totalSize - 1L).coerceAtLeast(0L)
        var isPartial = false

        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(",").trim()
            val dash = rangeSpec.indexOf('-')
            if (dash < 0 || totalSize <= 0L) {
                sendRangeNotSatisfiable(out, totalSize)
                return
            }
            val startStr = rangeSpec.substring(0, dash).trim()
            val endStr = rangeSpec.substring(dash + 1).trim()
            if (startStr.isEmpty()) {
                val suffixLen = endStr.toLongOrNull()
                if (suffixLen == null || suffixLen <= 0L) {
                    sendRangeNotSatisfiable(out, totalSize)
                    return
                }
                start = (totalSize - suffixLen).coerceAtLeast(0L)
                end = totalSize - 1L
                isPartial = true
            } else {
                val parsedStart = startStr.toLongOrNull()
                val parsedEnd = if (endStr.isEmpty()) totalSize - 1L else endStr.toLongOrNull()
                if (parsedStart == null || parsedEnd == null || parsedStart < 0L || parsedStart >= totalSize || parsedEnd < parsedStart) {
                    sendRangeNotSatisfiable(out, totalSize)
                    return
                }
                start = parsedStart
                end = parsedEnd.coerceAtMost(totalSize - 1L)
                isPartial = true
            }
        }

        // Open stream BEFORE sending HTTP headers so unreadable files return 404 cleanly
        val stream = if (!headOnly) {
            runCatching {
                if (!file.filePath.isNullOrBlank() && File(file.filePath).canRead()) {
                    FileInputStream(File(file.filePath))
                } else {
                    context.contentResolver.openInputStream(file.uri)
                }
            }.getOrNull()
        } else null

        if (!headOnly && stream == null) {
            sendSimpleResponse(out, 404, "Not Found", "text/plain", "Cannot open requested file")
            return
        }

        val contentLength = if (totalSize <= 0L) 0L else (end - start + 1L).coerceAtLeast(0L)
        val contentDisposition = buildContentDisposition(file.name)
        val statusLine = if (isPartial) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"

        val headers = buildString {
            append("$statusLine\r\n")
            append("Content-Type: ${file.mimeType}\r\n")
            append("Content-Length: $contentLength\r\n")
            append("Accept-Ranges: bytes\r\n")
            if (isPartial) append("Content-Range: bytes $start-$end/$totalSize\r\n")
            append("Content-Disposition: $contentDisposition\r\n")
            append("X-Content-Type-Options: nosniff\r\n")
            append("Referrer-Policy: no-referrer\r\n")
            append("Content-Security-Policy: $CSP_HEADER\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(headers.toByteArray(Charsets.US_ASCII))
        out.flush()
        if (headOnly || stream == null) return

        stream.use { input ->
            if (start > 0L) {
                var toSkip = start
                val discard = ByteArray(64 * 1024)
                while (toSkip > 0L) {
                    val skipped = input.skip(toSkip)
                    if (skipped > 0L) toSkip -= skipped
                    else {
                        val read = input.read(discard, 0, minOf(discard.size.toLong(), toSkip).toInt())
                        if (read == -1) break
                        toSkip -= read
                    }
                }
            }
            val buffer = ByteArray(256 * 1024)
            var remaining = contentLength
            while (remaining > 0L) {
                val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read == -1) break
                out.write(buffer, 0, read)
                remaining -= read
                lastActivityMs.set(System.currentTimeMillis())
            }
            out.flush()
        }
    }

    private fun sendRangeNotSatisfiable(out: BufferedOutputStream, totalSize: Long) {
        val header = buildString {
            append("HTTP/1.1 416 Range Not Satisfiable\r\n")
            append("Content-Range: bytes */$totalSize\r\n")
            append("Content-Length: 0\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    private fun buildTokenPromptHtml(wrongToken: Boolean): String {
        val title = escapeHtml(context.getString(R.string.app_name))
        val prompt = escapeHtml(context.getString(R.string.web_html_enter_token))
        val unlockBtn = escapeHtml(context.getString(R.string.web_html_unlock))
        val errHtml = if (wrongToken) {
            "<p class='err'>${escapeHtml(context.getString(R.string.web_html_wrong_token))}</p>"
        } else ""

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>$title</title>
                <style>
                    body { font-family: system-ui, sans-serif; margin: 0; padding: 24px; background: #0A0A0B; color: #F2F3F5; display: flex; justify-content: center; align-items: center; min-height: 90vh; }
                    .box { width: 100%; max-width: 400px; background: #151618; border: 1px solid #2A2C31; border-radius: 20px; padding: 24px; }
                    h1 { margin: 0 0 8px; font-size: 1.4rem; }
                    p { color: #9AA0AA; font-size: 0.92rem; margin: 0 0 18px; }
                    input { width: 100%; box-sizing: border-box; padding: 14px; font-size: 1rem; text-align: center; background: #1E1F23; color: #F2F3F5; border: 1px solid #4A4D55; border-radius: 12px; margin-bottom: 14px; }
                    button { width: 100%; padding: 14px; font-size: 1rem; font-weight: 600; background: #F2F3F5; color: #0A0A0B; border: none; border-radius: 12px; cursor: pointer; }
                    .err { color: #F2F3F5; background: #1E1F23; border: 1px solid #4A4D55; padding: 10px; border-radius: 10px; }
                </style>
            </head>
            <body>
                <form class="box" method="POST" action="/auth">
                    <h1>$title</h1>
                    <p>$prompt</p>
                    $errHtml
                    <input name="token" type="text" inputmode="numeric" autocomplete="off" placeholder="000000" required autofocus />
                    <button type="submit">$unlockBtn</button>
                </form>
            </body>
            </html>
        """.trimIndent()
    }

    private fun buildIndexHtml(files: List<ShareableFile>): String {
        val title = escapeHtml(context.getString(R.string.app_name))
        val dlLabel = escapeHtml(context.getString(R.string.web_html_download))
        val emptyLabel = escapeHtml(context.getString(R.string.web_html_empty))
        val subLabel = escapeHtml(context.getString(R.string.web_share_shared_count, files.size))

        val itemsHtml = if (files.isEmpty()) {
            "<p class='empty'>$emptyLabel</p>"
        } else {
            files.mapIndexed { index, file ->
                val safeName = escapeHtml(file.name)
                val sizeStr = Formatters.formatBytes(file.sizeBytes)
                val catStr = file.category.folderName
                """
                <div class="card">
                    <div class="info">
                        <div class="name">$safeName</div>
                        <div class="meta">$catStr &bull; $sizeStr</div>
                    </div>
                    <a class="btn" href="/download/$index">$dlLabel</a>
                </div>
                """.trimIndent()
            }.joinToString("\n")
        }

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>$title</title>
                <style>
                    body { font-family: system-ui, sans-serif; margin: 0; padding: 20px; background: #0A0A0B; color: #F2F3F5; }
                    .container { max-width: 720px; margin: 0 auto; }
                    header { margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #2A2C31; }
                    h1 { margin: 0 0 6px; font-size: 1.5rem; }
                    p.sub { margin: 0; color: #9AA0AA; font-size: 0.92rem; }
                    .card { display: flex; align-items: center; justify-content: space-between; gap: 12px; background: #151618; border: 1px solid #2A2C31; padding: 14px 16px; border-radius: 18px; margin-bottom: 12px; }
                    .info { min-width: 0; flex: 1; }
                    .name { font-weight: 600; word-break: break-word; margin-bottom: 4px; }
                    .meta { font-size: 0.82rem; color: #9AA0AA; }
                    .btn { display: inline-block; background: #F2F3F5; color: #0A0A0B; text-decoration: none; padding: 10px 16px; border-radius: 10px; font-weight: 600; white-space: nowrap; }
                    .empty { text-align: center; color: #9AA0AA; padding: 40px 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <header>
                        <h1>$title</h1>
                        <p class="sub">$subLabel</p>
                    </header>
                    $itemsHtml
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    private fun acquireTransferLocks() {
        runCatching {
            if (wakeLock == null) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FlashShare::WebShareWakeLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) wakeLock?.acquire(20L * 60L * 1000L)

            if (wifiLock == null) {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm?.createWifiLock(mode, "FlashShare::WebShareWifiLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        }
    }

    private fun releaseTransferLocks() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
    }

    private fun escapeHtml(text: String): String =
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
}
