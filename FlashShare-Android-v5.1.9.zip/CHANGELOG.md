# FlashShare v5.1.0 Changelog

## v5.1.0 Targeted Hardening & Reliability Fixes (CI-verified: compiles and unit tests pass on GitHub Actions; NOT yet verified on a device or in a release/R8 build)

**Verification status:** GitHub Actions CI verified the debug builds of both flavors (`assembleFullDebug`, `assemblePlayDebug`), all JVM unit tests (`testFullDebugUnitTest`, `testPlayDebugUnitTest`), 16 KB `.so` page-size alignment, and that the `play` flavor manifest removes `READ_CONTACTS`, `WRITE_CONTACTS`, and `REQUEST_INSTALL_PACKAGES`. Still unverified: anything requiring a real device (Wi-Fi Direct, QR scan, hotspot, text share intent, large `.apks` install) and the R8-minified release build (`assembleFullRelease`, `assemblePlayRelease`).
1. **CI (`.github/workflows/build.yml`)** — Removed `wrapper-validation` and `chmod +x ./gradlew`, set `gradle-version: 8.11.1` on `gradle/actions/setup-gradle@v4` in both jobs, and replaced `./gradlew` with `gradle`.
2. **Version (`app/build.gradle.kts`, `README.md`, `CHANGELOG.md`)** — Bumped `versionCode = 7`, `versionName = "5.1.0"`, and updated headings.
3. **Wi-Fi Direct passphrase (`WifiDirectManager.kt`)** — Replaced weak SSID-derived passphrase with 16 random `[A-Za-z0-9]` characters via `SecureRandom` (`generateStrongPassphrase()`), independent of SSID.
4. **Receive server address filter (`TransferManager.kt`)** — Closed accepted sockets unless remote `InetAddress` is site-local or link-local (`isAllowedPeerAddress`), preserving Wi-Fi Direct group-owner late IP assignment.
5. **Web Share security headers (`LocalWebServer.kt`)** — Added `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, and `Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'` to `sendSimpleResponse` and `streamFileResponse`, plus ASCII fallback in `Content-Disposition` (`buildContentDisposition`).
6. **Off-main-thread `.apks` install (`MainViewModel.kt`, `HistoryAndSettingsScreens.kt`)** — Moved `ApksInstaller.installApksBundle` to `MainViewModel.installApksBundle` on `Dispatchers.IO` using `applicationContext`, with `AtomicBoolean` double-tap guard and main-thread `showMessage`.
7. **Safe startup `share_cache` cleanup (`StorageOrganizer.kt`, `FlashShareApp.kt`, `TransferManager.kt`)** — Restricted startup `cleanupShareCache()` to files older than 24 hours not referenced by staged/active transfers (`getStagedShareCachePaths()`), keeping manual Settings Clear unchanged.
8. **Plain-text `ACTION_SEND` (`MainActivity.kt`, `MainViewModel.kt`)** — Handled `ACTION_SEND` with `EXTRA_TEXT` (when `EXTRA_STREAM` is absent) by writing UTF-8 to `share_cache/shared_text_<timestamp>.txt` off the main thread and staging it for transfer.
9. **Foreground service lifecycle (`TransferForegroundService.kt`, `TransferManager.kt`)** — Changed `onStartCommand` to `START_NOT_STICKY`, added a 5-second grace period on initial empty `transfers` emission before `stopSelf()`, and ordered `ensureForegroundService()` calls after items are published in `transfers`.
10. **Contacts import dedupe, cap & error reporting (`ContactsRepository.kt`, `MainViewModel.kt`, `SendReceiveScreens.kt`, `PhoneCloneScreen.kt`, `strings.xml`)** — **UNVERIFIED**: Added (name + phone/email) pair duplicate detection, a 20,000-contact import cap (`MAX_IMPORT_CONTACTS`), `ContactsImportResult` summary, and `ContactsImportError` (`FILE_UNREADABLE`, `NO_CONTACTS_FOUND`, `PERMISSION_DENIED`) reporting.
11. **Shared-number duplicate rule fix (`ContactsRepository.kt`, `FlashShareUnitTests.kt`)** — **UNVERIFIED**: Corrected the duplicate rule so different contacts sharing the same phone number or email (e.g. "Mom" and "Home") are no longer skipped as duplicates.

---

## v5.0.0 Baseline

## Environment & Verification Disclosure (Honesty Note)
This release was authored and statically audited in an offline Linux sandbox containing OpenJDK 17 JRE (`java` only) and Python 3.11 — **no `javac`, `kotlinc`, `gradle`, Android SDK, or Android emulator** is installed, and outbound internet is disabled.

Accordingly:
- **No Gradle build, Android Lint, JVM unit test execution, or emulator/device test was run in this environment.**
- Every item below is explicitly marked **UNVERIFIED** for Gradle/runtime verification, with the exact command(s) you must run locally or in GitHub Actions to verify it, alongside the static checks that *were* executed in the sandbox.

---

## Phase A — Critical Security, Protocol V5, API 24, Theme & Wrapper

### 1. Remove `java.util.Base64` & unguarded API > 24 calls — **UNVERIFIED** (statically audited; needs `lintDebug` + `testDebugUnitTest` + API 24/25 device)
- **Changes**:
  - Added pure-Kotlin `Base64Url` (`app/src/main/java/com/flashshare/app/transfer/Base64Url.kt`) with strict RFC 4648 URL-safe encoding/decoding (zero `java.util.Base64`, zero `android.util.Base64`).
  - Updated `CryptoHelper.kt` to use `Base64Url` and replaced `ThreadLocal.withInitial` (API 26+) with an anonymous `object : ThreadLocal<Cipher>()` subclass (API 1+).
  - Added `base64Url_roundTripAndInvalidInputs` and `staticAudit_noJavaUtilBase64OrThreadLocalWithInitialInMainSources` in `FlashShareUnitTests.kt`.
  - Audited all other API > 24 calls across `app/src/main/java` (`MediaStore.Downloads`, `IS_PENDING`, `RELATIVE_PATH`, `canRequestPackageInstalls`, `NotificationChannel`, `startForegroundService`, `ForegroundServiceStartNotAllowedException`, `WifiNetworkSpecifier`, `WifiP2pConfig.Builder`, `RECEIVER_NOT_EXPORTED`, `getParcelableExtra` typed overload, `FLAG_MUTABLE`).
- **Why UNVERIFIED**: Cannot run `./gradlew lintFullDebug testFullDebugUnitTest` or boot an API 24/25 emulator in this sandbox.
- **Verify with**: `./gradlew assembleFullDebug lintFullDebug testFullDebugUnitTest` and launch on an Android 7.0/7.1 (API 24/25) device/emulator.

### 2. QR Pre-Shared Key (PSK) proof of possession & post-batch rotation — **UNVERIFIED** (needs `testDebugUnitTest` + real-device QR test)
- **Changes**:
  - Bumped wire protocol to **Protocol V5** (`PROTOCOL_VERSION_V5 = 5`), rejecting V4 and earlier.
  - Required constant-time `HMAC-SHA256(qrPsk, "FLASHSHARE-V5-QR-PROOF|" || batchId || clientEcdhPub || roleLabel)` for **both** QR push (`ROLE_PUSH`) and QR pull (`ROLE_PULL`) checked in `TransferProtocol.performServerHandshakeV5` **before** any state change, approval prompt, or rotation.
  - Added `ActiveBatchSession` in `TransferManager.kt` keyed by `batchId` (binding `peerFingerprint` + `qrPskBytes` + `activeSockets`) so parallel worker sockets and chunked-range sockets of the same batch share the PSK.
  - Rotated `_sessionEncryptionKey` only after the batch completes, cancels, or times out — never during handshake.
  - Exposed `sessionEncryptionKey` on `MainViewModel` and added it to `QrHubScreen` `remember(...)` keys so the receiver QR refreshes immediately after rotation.
  - Added `wasQrConnection` + `clearConnectionEncryptionKey()` in `WifiDirectManager.kt`; after a QR batch finishes or fails with `RESPONSE_AUTH_FAILED`, the sender clears its stored QR key and displays localized `"Session expired. Scan the new QR code."` (`R.string.error_qr_key_rotated`).
  - Updated `MainViewModel.resendHistoryItem()` so resending on a rotated QR session prompts to scan the new QR code and stages the file instead of failing silently.
- **Verify with**: `./gradlew testFullDebugUnitTest --tests "com.flashshare.app.FlashShareUnitTests.loopbackHandshakeV5_*"` and two-phone QR test.

### 3. Approval keyed by `(batchId, peerFingerprint)`, bounded queue & per-IP rate limit — **UNVERIFIED** (needs `testDebugUnitTest`)
- **Changes**:
  - Added `ApprovalCoordinator` (`app/src/main/java/com/flashshare/app/transfer/ApprovalCoordinator.kt`) keying approvals by `ApprovalKey(batchId, peerFingerprint)` so sockets from the same fingerprint share one decision while a different fingerprint gets its own prompt.
  - Replaced single pending slot with a bounded FIFO queue (max 3 pending) and per-remote-IP rate limiting (max 3 prompts per 60s window with expiry purge).
  - Updated `TransferManager`, `MainViewModel`, and `FlashShareAppRoot` to pass `senderFingerprint` when answering prompts.
- **Verify with**: `./gradlew testFullDebugUnitTest --tests "com.flashshare.app.FlashShareUnitTests.approvalCoordinator_keyedByBatchAndFingerprint_andRateLimited"`.

### 4. ZRTP-style hash-committed SAS, dual-phone confirmation & sender trust pinning — **UNVERIFIED** (needs `testDebugUnitTest` + two-phone nearby test)
- **Changes**:
  - Added ZRTP-style commitment in `TransferProtocol.performClientHandshakeV5` / `performServerHandshakeV5`: initiator sends `commit = SHA-256("FLASHSHARE-V5-COMMIT|" || clientEcdhPub || nonce)` first, responder sends its ephemeral pubkey, initiator reveals `(clientEcdhPub, nonce)`, responder verifies commitment before signing transcript and deriving HKDF session key + 6-digit SAS.
  - Added `PendingSasVerification` dialog on the **sender** side (`FlashShareAppRoot.kt`) and explicit **"Codes match"** / **"Codes don't match"** buttons on both phones before any file header or data flows; mismatch aborts with localized security warning (`R.string.sas_mismatch_warning`).
  - Skips SAS only when QR PSK was verified or peer fingerprint is already trusted/pinned.
  - Added sender-side pinned receiver fingerprints (`pinnedReceivers` in `UserPreferences.kt`). If a known receiver's fingerprint changes, shows a loud warning (`R.string.sas_fingerprint_changed_warning`) and forces a fresh SAS check.
- **Verify with**: `./gradlew testFullDebugUnitTest --tests "com.flashshare.app.FlashShareUnitTests.loopbackHandshakeV5_sasCommitmentMismatchAborts"` and two-phone non-QR send.

### 5. Theme & status-bar regression (dark-only consistency) — **UNVERIFIED** (statically audited; needs emulator in Light Mode)
- **Changes**:
  - Updated `MainActivity.kt` to use `SystemBarStyle.dark(Color.TRANSPARENT)` for both status and navigation bars.
  - Updated both `values/themes.xml` and `values-night/themes.xml` to `parent="Theme.AppCompat.NoActionBar"` with `#0A0A0B` `windowBackground` so the window cannot flip to light or flash white at launch.
  - Updated `README.md` to state dark-only monochrome UI (no Light/Dark/System theme claim).
- **Verify with**: Launch on an emulator/device with System Theme set to **Light Mode** and verify zero white launch flash and visible white status-bar icons.

### 6. Gradle wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`) — **UNVERIFIED** (NOT GENERATED — sandbox lacks `gradle` & internet)
- **Honest status**: `gradle` is not installed and outbound internet is disabled in this sandbox, so `gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar` **could not be generated** and are **NOT** included in this zip.
- **Changes made**: Updated `.github/workflows/build.yml` to run `gradle/actions/wrapper-validation@v4` unconditionally and invoke `./gradlew` only (no `gradle` fallback).
- **Exact command you must run once locally before pushing to CI**:
  ```bash
  gradle wrapper --gradle-version 8.11.1 --distribution-type bin && chmod +x gradlew
  ```

---

## Phase B — Functionality and Reliability

### 7. Split-APK `.apks` PackageInstaller & `share_cache` cleanup — **UNVERIFIED** (needs real device with split-APK app)
- **Changes**:
  - Added `ApksInstaller.kt` (`PackageInstaller.Session` with `MODE_FULL_INSTALL`, checking `canRequestPackageInstalls()` on API 26+, streaming all `*.apk` entries from the `.apks` zip, committing with an explicit `Intent` + `FLAG_MUTABLE` on API 31+).
  - Added non-exported `InstallResultReceiver.kt` (registered in `AndroidManifest.xml` with `android:exported="false"`) handling `STATUS_PENDING_USER_ACTION`, `STATUS_SUCCESS`, `STATUS_FAILURE_ABORTED`, and errors with localized messages via `InstallResultBus`.
  - Wired `HistoryScreen` Open action to launch `ApksInstaller.installApksBundle()` for `.apks` files.
  - Marked generated `.apks` bundles with `isCachedTempFile = true` in `FileBrowserRepository.kt`; `TransferManager` deletes them after sending and `FlashShareApp.onCreate()` cleans `cache/share_cache` on startup.
- **Verify with**: Send a split-APK app from Phone A to Phone B (full flavor) and tap **Open** in History.

### 8. Stable `transferId`, 7-day `.part` cleanup & Settings temporary-files row — **UNVERIFIED** (needs `testDebugUnitTest` + device test)
- **Changes**:
  - Added `TransferManager.computeStableTransferId()` (`SHA-256(uri | size | lastModified | receiverKey)`) with active-collision suffix (`_d1`, `_d2`) when two identical sends run simultaneously.
  - Added `StorageOrganizer.cleanupExpiredPartFiles()` (>7 days) called in `FlashShareApp.onCreate()` and in `finally` of every receive/pull batch.
  - Added `getTemporaryFilesSizeBytes()` and `clearAllTemporaryFiles()` in `StorageOrganizer.kt`, exposed on `MainViewModel`, and added a **Temporary files** row with formatted size + **Clear** button in `SettingsScreen`.
- **Verify with**: `./gradlew testFullDebugUnitTest --tests "com.flashshare.app.FlashShareUnitTests.partFileResume_stableTransferIdAndWholeFileSha256"` and Settings UI check.

### 9. Storage edge cases (`StorageOrganizer` & receive loop) — **UNVERIFIED** (needs API 29+ device test)
- **Changes**:
  - Updated `StorageOrganizer.hasEnoughSpace()` to require `2 * remainingBytes + 16 MB` on API 29+.
  - Moved `contentResolver.insert()` inside the `try` block with rollback `delete()` on failure.
  - Added `resolveMediaStoreTarget()` normalizing MIME against collection: mismatching MIME for `PHOTOS`/`VIDEOS`/`MUSIC` routes safely to `MediaStore.Downloads` instead of throwing.
  - Removed silent hidden-folder fallback on API 29+: throws `MediaStorePublishException`, marks the transfer `FAILED` with localized `R.string.error_storage_publish_failed`, and cleans up `.part`.
  - Updated `getDisplayStoragePath()` to report the real MediaStore collections on API 29+ and the actual legacy path on API <= 28.
- **Verify with**: Receive photos, videos, audio, and unknown-MIME files on Android 10/13/14/16 and confirm visibility in Gallery and Files.

### 10. Parallel range completion race fix — **UNVERIFIED** (needs `testDebugUnitTest`)
- **Changes**:
  - Added `ParallelCompletionCoordinator.kt` using `ConcurrentHashMap<String, CompletableDeferred<Byte>>` (`putIfAbsent`) so exactly one range handler hashes and publishes while concurrent handlers await the winner's result byte.
  - Added `parallelCompletionCoordinator_exactlyOneWinnerRunsVerifyAndPublish` unit test.
- **Verify with**: `./gradlew testFullDebugUnitTest --tests "com.flashshare.app.FlashShareUnitTests.parallelCompletionCoordinator_exactlyOneWinnerRunsVerifyAndPublish"`.

### 11. Timeouts & speed (`VERIFY_PENDING` keepalive, `VERIFYING` status, streaming SHA-256 trailer) — **UNVERIFIED** (needs 3+ GB transfer on slow device)
- **Changes**:
  - Added `TransferProtocol.VERIFY_PENDING = 12` and `readFinalVerifyByte()`; receiver sends `VERIFY_PENDING` every 5 seconds while hashing/publishing, preventing 60s sender timeouts on large files.
  - Added `TransferStatus.VERIFYING` with localized `"Verifying…"` string in `TransferQueueScreen`, `HistoryScreen`, `HomeScreen`, and `TransferForegroundService`.
  - Enabled streaming SHA-256 trailer (`hasTrailerHash = true`) for sequential sends so the sender hashes while streaming instead of doing a full pre-read pass (keeping header SHA-256 for parallel-range sends).
- **Verify with**: Transfer a 3+ GB file to a slow phone and confirm `"Verifying…"` appears without timing out.

---

## Phase C — Policy, Web Share, Tests & Share-Into-App Polish

### 12. Play-policy productFlavors (`play` and `full`) — **UNVERIFIED** (needs `./gradlew assembleFullDebug assemblePlayDebug` + merged manifest inspection)
- **Changes**:
  - Added `flavorDimensions += "distribution"` with `full` and `play` flavors in `app/build.gradle.kts` (`ENABLE_CONTACTS_CLONE`, `ENABLE_APK_INSTALL`, `ENABLE_APPS_TAB` `BuildConfig` flags).
  - Created `app/src/play/AndroidManifest.xml` using `tools:node="remove"` for `READ_CONTACTS`, `WRITE_CONTACTS`, `REQUEST_INSTALL_PACKAGES`, and `<queries>`.
  - Gated Phone Clone contacts, Apps tab, and APK/APKS install with `BuildConfig` flags.
  - Updated `.github/workflows/build.yml` to build, lint, test, and `zipalign -c -P 16` check both flavors, and updated `PRIVACY.md`.
- **Verify with**: `./gradlew assembleFullDebug assemblePlayDebug lintFullDebug lintPlayDebug` and inspect `app/build/intermediates/merged_manifests/playDebug/AndroidManifest.xml`.

### 13. Web share hardening & UI — **UNVERIFIED** (needs `testDebugUnitTest` + browser test)
- **Changes**:
  - Added `WebServerAuthGuard` in `LocalWebServer.kt`: binds authenticated cookie session to the first client IP, verifies tokens in constant time, enforces 5-failure lockout, and purges expired `rateLimits` entries every 30s.
  - Exposed `connectedClients` in `WebServerState` and rendered them in `WebShareScreen.kt` alongside a localized plain-HTTP warning banner (`R.string.web_share_http_warning`) and a prominent top **Stop sharing** button.
  - Fixed misleading "one-time" comments/strings to accurately state the token stays valid until sharing stops.
- **Verify with**: `./gradlew testFullDebugUnitTest --tests "com.flashshare.app.FlashShareUnitTests.webServerAuthGuard_rateLimitLockoutIpBindingAndPurge"` and test from two different client IPs.

### 14. JVM unit tests & `DeviceIdentityProvider` interface — **UNVERIFIED** (needs `./gradlew testFullDebugUnitTest testPlayDebugUnitTest`)
- **Changes**:
  - Extracted `interface DeviceIdentityProvider` in `DeviceIdentityManager.kt` and bound it in `AppModule.kt`.
  - Added `FakeDeviceIdentityProvider` and full loopback-socket & security tests in `FlashShareUnitTests.kt` (Base64Url, static API-26+ guard, V5 handshake success, V4 rejection, PSK mismatch without rotation/prompt, multi-socket batch PSK reuse, approval `(batchId, fingerprint)` + queue + IP rate limit, SAS commitment mismatch, `.part` resume, `ParallelCompletionCoordinator`, and `WebServerAuthGuard`).
- **Verify with**: `./gradlew testFullDebugUnitTest testPlayDebugUnitTest`.

### 15. Share-into-FlashShare intent handling — **UNVERIFIED** (needs real-device share + rotation test)
- **Changes**:
  - Updated `MainActivity.kt` to handle `ACTION_SEND`/`ACTION_SEND_MULTIPLE` only when `savedInstanceState == null` (or `onNewIntent`), mark `EXTRA_SHARE_CONSUMED`, clear action/extras after handling, and deduplicate URIs via `LinkedHashSet`.
  - Updated `MainViewModel.handleExternalShareUris()` to copy temporary-grant `content://` URIs into `cache/share_cache` (up to 512 MB cap with localized `R.string.error_share_too_large` message above the cap) and clean them up after transfer.
- **Verify with**: Share 3 files from Gallery/Files into FlashShare, rotate the screen, and confirm files are not duplicated.

---

## Static Sandbox Checks Executed (PASS — not a substitute for Gradle)
- XML well-formedness across all 17 XML files (including `app/src/play/AndroidManifest.xml`): **PASS**
- String key parity across `values/`, `values-am/`, and `values-om/` (192 keys each): **PASS**
- All `R.string.*` references across 41 Kotlin files exist in resources: **PASS**
- Zero `java.util.Base64`, zero `ThreadLocal.withInitial`, zero `TODO`/`FIXME`, zero stale V4 protocol symbols in `app/src/main/java`: **PASS**
- Dark-only theme check (`values/themes.xml` & `values-night/themes.xml`): **PASS**
