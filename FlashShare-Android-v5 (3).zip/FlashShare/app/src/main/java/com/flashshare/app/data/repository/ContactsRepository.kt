package com.flashshare.app.data.repository

import android.content.ContentProviderOperation
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

data class ParsedVCardContact(
    val displayName: String,
    val phones: List<String>,
    val emails: List<String>
)

@Singleton
class ContactsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        fun formatVCard30(contacts: List<ParsedVCardContact>): String {
            val sb = StringBuilder()
            for (c in contacts) {
                sb.appendLine("BEGIN:VCARD")
                sb.appendLine("VERSION:3.0")
                sb.appendLine("FN:${escapeVcard(c.displayName)}")
                c.phones.forEach { phone -> sb.appendLine("TEL;TYPE=CELL:$phone") }
                c.emails.forEach { email -> sb.appendLine("EMAIL:$email") }
                sb.appendLine("END:VCARD")
            }
            return sb.toString()
        }

        fun parseVCardLines(lines: Sequence<String>): List<ParsedVCardContact> {
            val results = mutableListOf<ParsedVCardContact>()
            var currentName = ""
            val currentPhones = mutableListOf<String>()
            val currentEmails = mutableListOf<String>()

            for (rawLine in lines) {
                val line = rawLine.trim()
                when {
                    line.equals("BEGIN:VCARD", ignoreCase = true) -> {
                        currentName = ""
                        currentPhones.clear()
                        currentEmails.clear()
                    }
                    line.startsWith("FN:", ignoreCase = true) -> {
                        currentName = unescapeVcard(line.substringAfter(":").trim())
                    }
                    line.startsWith("TEL", ignoreCase = true) && line.contains(":") -> {
                        val phone = line.substringAfter(":").trim()
                        if (phone.isNotBlank()) currentPhones.add(phone)
                    }
                    line.startsWith("EMAIL", ignoreCase = true) && line.contains(":") -> {
                        val email = line.substringAfter(":").trim()
                        if (email.isNotBlank()) currentEmails.add(email)
                    }
                    line.equals("END:VCARD", ignoreCase = true) -> {
                        if (currentName.isNotBlank() || currentPhones.isNotEmpty()) {
                            results.add(
                                ParsedVCardContact(
                                    displayName = currentName,
                                    phones = currentPhones.toList(),
                                    emails = currentEmails.toList()
                                )
                            )
                        }
                    }
                }
            }
            return results
        }

        private fun escapeVcard(value: String): String =
            value.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;")

        private fun unescapeVcard(value: String): String =
            value.replace("\\;", ";").replace("\\,", ",").replace("\\\\", "\\")
    }

    suspend fun getContactCount(): Int = withContext(Dispatchers.IO) {
        var count = 0
        runCatching {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID),
                null,
                null,
                null
            )?.use { cursor -> count = cursor.count }
        }
        count
    }

    suspend fun exportContactsToVcf(): ShareableFile? = withContext(Dispatchers.IO) {
        val contactsMap = linkedMapOf<String, Pair<String, MutableList<String>>>()
        val emailMap = mutableMapOf<String, MutableList<String>>()

        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol) ?: continue
                    val name = cursor.getString(nameCol)?.trim().orEmpty().ifBlank { "Unnamed" }
                    val number = cursor.getString(numCol)?.trim().orEmpty()
                    if (number.isBlank()) continue
                    val entry = contactsMap.getOrPut(contactId) { name to mutableListOf() }
                    if (number !in entry.second) entry.second.add(number)
                }
            }

            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Email.ADDRESS
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
                val emailCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol) ?: continue
                    val email = cursor.getString(emailCol)?.trim().orEmpty()
                    if (email.isNotBlank()) emailMap.getOrPut(contactId) { mutableListOf() }.add(email)
                }
            }
        }

        val parsedList = contactsMap.map { (id, pair) ->
            ParsedVCardContact(pair.first, pair.second, emailMap[id].orEmpty())
        }
        if (parsedList.isEmpty()) return@withContext null

        val exportDir = File(context.cacheDir, "share_cache").apply { mkdirs() }
        val vcfFile = File(exportDir, "FlashShare_Contacts_${System.currentTimeMillis()}.vcf")
        vcfFile.writeText(formatVCard30(parsedList), Charsets.UTF_8)

        ShareableFile(
            id = "contacts_vcf_${vcfFile.name}",
            name = vcfFile.name,
            sizeBytes = vcfFile.length(),
            mimeType = "text/vcard",
            category = FileCategory.CONTACTS,
            uri = Uri.fromFile(vcfFile),
            filePath = vcfFile.absolutePath,
            lastModified = vcfFile.lastModified()
        )
    }

    /**
     * Imports a received vCard (.vcf) from either a MediaStore content:// URI or a legacy File path.
     */
    suspend fun importContactsFromLocation(pathOrUri: String): Int = withContext(Dispatchers.IO) {
        val stream = if (pathOrUri.startsWith("content://")) {
            context.contentResolver.openInputStream(Uri.parse(pathOrUri))
        } else {
            val file = File(pathOrUri)
            if (file.exists()) FileInputStream(file) else null
        } ?: return@withContext 0

        val parsed = stream.use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                parseVCardLines(reader.lineSequence())
            }
        }

        var imported = 0
        for (contact in parsed) {
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )
            if (contact.displayName.isNotBlank()) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, contact.displayName)
                        .build()
                )
            }
            contact.phones.forEach { phone ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build()
                )
            }
            contact.emails.forEach { email ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                        .build()
                )
            }
            runCatching {
                context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                imported++
            }
        }
        imported
    }
}
