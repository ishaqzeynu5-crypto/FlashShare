package com.flashshare.app.transfer

import android.app.ForegroundServiceStartNotAllowedException
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.flashshare.app.R
import com.flashshare.app.data.local.UserPreferences
import com.flashshare.app.data.repository.TransferHistoryRepository
import com.flashshare.app.data.storage.MediaStorePublishException
import com.flashshare.app.data.storage.StorageOrganizer
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.IncomingTransferRequest
import com.flashshare.app.domain.model.PendingSasVerification
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.network.WifiDirectManager
import com.flashshare.app.service.TransferForegroundService
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.SecretKey
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val storageOrganizer: StorageOrganizer,
    private val historyRepository: TransferHistoryRepository,
    private val userPreferences: UserPreferences,
    private val wifiDirectManager: WifiDirectManager,
    private val deviceIdentityProvider: DeviceIdentityProvider
) {
    companion object {
        private const val TAG = "TransferManager"
        private const val QR_BATCH_ROTATION_GRACE_MS = 2_500L
        private const val SAS_CONFIRM_TIMEOUT_MS = 60_000L

        /**
         * Stable deterministic transferId so resume works across app restarts.
         */
        fun computeStableTransferId(
            sourceUri: String,
            sizeBytes: Long,
            lastModified: Long,
            receiverKey: String
        ): String {
            return CryptoHelper.sha256Hex(
                sourceUri.toByteArray(Charsets.UTF_8),
                "|".toByteArray(Charsets.UTF_8),
                sizeBytes.toString().toByteArray(Charsets.UTF_8),
                "|".toByteArray(Charsets.UTF_8),
                lastModified.toString().toByteArray(Charsets.UTF_8),
                "|".toByteArray(Charsets.UTF_8),
                receiverKey.toByteArray(Charsets.UTF_8)
            ).take(32)
        }
    }

    private data class ActiveBatchSession(
        val batchId: String,
        val peerFingerprint: String,
        val qrPskBytes: ByteArray?,
        val usesQrPsk: Boolean,
        val activeSockets: AtomicInteger = AtomicInteger(0),
        val filesCompleted: AtomicInteger = AtomicInteger(0),
        val totalFilesExpected: Int = 0,
        @Volatile var rotationJob: Job? = null
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connectionLimiter = Semaphore(TransferProtocol.MAX_CONCURRENT_CONNECTIONS)
    private val approvalCoordinator = ApprovalCoordinator()
    private val parallelCompletionCoordinator = ParallelCompletionCoordinator()

    private val itemMap = ConcurrentHashMap<String, TransferItem>()
    private val itemOrder = CopyOnWriteArrayList<String>()
    private val uiDirty = AtomicBoolean(false)

    private val _transfers = MutableStateFlow<List<TransferItem>>(emptyList())
    val transfers: StateFlow<List<TransferItem>> = _transfers.asStateFlow()

    private val _isReceiveServerRunning = MutableStateFlow(false)
    val isReceiveServerRunning: StateFlow<Boolean> = _isReceiveServerRunning.asStateFlow()

    private val _activePort = MutableStateFlow(TransferProtocol.DEFAULT_PORT)
    val activePort: StateFlow<Int> = _activePort.asStateFlow()

    private val _sessionEncryptionKey = MutableStateFlow(CryptoHelper.generateKeyBase64())
    val sessionEncryptionKey: StateFlow<String> = _sessionEncryptionKey.asStateFlow()

    val pendingIncomingRequest: StateFlow<IncomingTransferRequest?> = approvalCoordinator.currentPending

    private val _pendingSenderSas = MutableStateFlow<PendingSasVerification?>(null)
    val pendingSenderSas: StateFlow<PendingSasVerification?> = _pendingSenderSas.asStateFlow()

    private val _securityAlerts = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val securityAlerts: SharedFlow<String> = _securityAlerts.asSharedFlow()

    private val _lastReceivedVcfLocation = MutableStateFlow<String?>(null)
    val lastReceivedVcfLocation: StateFlow<String?> = _lastReceivedVcfLocation.asStateFlow()

    @Volatile
    private var stagedQrSendFiles: List<ShareableFile> = emptyList()

    private val pauseFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val cancelFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val parallelProgressBytes = ConcurrentHashMap<String, AtomicLong>()
    private val parallelRangePartFiles = ConcurrentHashMap<String, File>()
    private val activeBatchSessions = ConcurrentHashMap<String, ActiveBatchSession>()
    private val senderSasDecisions = ConcurrentHashMap<ApprovalCoordinator.ApprovalKey, CompletableDeferred<Boolean>>()
    private val qrSessionLock = Any()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    init {
        scope.launch {
            while (isActive) {
                delay(200L)
                if (uiDirty.compareAndSet(true, false)) {
                    publishSnapshot()
                }
            }
        }
    }

    fun stageFilesForQrPull(files: List<ShareableFile>) {
        stagedQrSendFiles = files
    }

    fun startReceiveServer(preferredPort: Int = TransferProtocol.DEFAULT_PORT) {
        if (_isReceiveServerRunning.value) return
        _sessionEncryptionKey.value = CryptoHelper.generateKeyBase64()

        serverJob = scope.launch {
            var boundSocket: ServerSocket? = null
            var boundPort = preferredPort
            for (port in preferredPort..TransferProtocol.MAX_PORT_FALLBACK) {
                try {
                    boundSocket = ServerSocket().apply {
                        reuseAddress = true
                        receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                        bind(InetSocketAddress(port))
                    }
                    boundPort = port
                    break
                } catch (_: Exception) {
                    // Port busy; try next
                }
            }

            if (boundSocket == null) {
                Log.e(TAG, "Failed to bind receive server on ports $preferredPort..${TransferProtocol.MAX_PORT_FALLBACK}")
                _isReceiveServerRunning.value = false
                return@launch
            }

            serverSocket = boundSocket
            _activePort.value = boundPort
            _isReceiveServerRunning.value = true

            try {
                while (isActive && !boundSocket.isClosed) {
                    val client = try {
                        boundSocket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    if (!connectionLimiter.tryAcquire()) {
                        Log.w(TAG, "Max concurrent connections reached; dropping connection")
                        runCatching { client.close() }
                        continue
                    }
                    launch {
                        try {
                            handleIncomingSocket(client)
                        } finally {
                            connectionLimiter.release()
                        }
                    }
                }
            } finally {
                _isReceiveServerRunning.value = false
            }
        }
    }

    fun stopReceiveServer() {
        stagedQrSendFiles = emptyList()
        activeBatchSessions.values.forEach { it.rotationJob?.cancel() }
        activeBatchSessions.clear()
        runCatching { serverSocket?.close() }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        _isReceiveServerRunning.value = false
    }

    fun respondToIncomingRequest(
        batchId: String,
        senderFingerprint: String,
        accept: Boolean,
        trustDevice: Boolean
    ) {
        val answered = approvalCoordinator.respond(batchId, senderFingerprint, accept)
        if (accept && trustDevice && answered != null) {
            scope.launch { userPreferences.addTrustedDevice(answered.senderFingerprint) }
        }
        if (!accept && answered?.verificationCode != null) {
            _securityAlerts.tryEmit(context.getString(R.string.sas_mismatch_warning))
        }
    }

    fun respondToSenderSas(
        batchId: String,
        peerFingerprint: String,
        peerName: String,
        codesMatch: Boolean,
        pinReceiver: Boolean
    ) {
        val key = ApprovalCoordinator.ApprovalKey(batchId, peerFingerprint)
        if (_pendingSenderSas.value?.batchId == batchId &&
            _pendingSenderSas.value?.peerFingerprint == peerFingerprint
        ) {
            _pendingSenderSas.value = null
        }
        if (codesMatch && pinReceiver) {
            scope.launch { userPreferences.pinReceiverFingerprint(peerName, peerFingerprint) }
        }
        if (!codesMatch) {
            _securityAlerts.tryEmit(context.getString(R.string.sas_mismatch_warning))
        }
        senderSasDecisions[key]?.complete(codesMatch)
    }

    /**
     * Pulls staged files from a sender hosting a QR session (Protocol V5).
     * Requires the QR key (constant-time HMAC proof of possession) + host approval.
     */
    fun pullFilesFromSender(
        hostIp: String,
        port: Int,
        peerName: String,
        encryptionKeyBase64: String?
    ) {
        val qrKeyBytes = CryptoHelper.decodeKeyBytes(encryptionKeyBase64)
        if (qrKeyBytes == null) {
            Log.w(TAG, "QR pull aborted: missing valid QR key")
            _securityAlerts.tryEmit(context.getString(R.string.error_qr_key_rotated))
            return
        }
        ensureForegroundService()
        scope.launch {
            var socket: Socket? = null
            val activeIds = mutableListOf<String>()
            try {
                socket = createOptimizedSocket(hostIp, port)
                socket.soTimeout = TransferProtocol.HANDSHAKE_TIMEOUT_MS
                val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
                val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream(), TransferProtocol.BUFFER_SIZE))

                val myName = userPreferences.deviceName.first()
                val batchId = UUID.randomUUID().toString()
                val flags = TransferProtocol.FLAG_BATCH or
                    TransferProtocol.FLAG_ENCRYPTED or
                    TransferProtocol.FLAG_USES_QR_PSK or
                    TransferProtocol.FLAG_PULL_FROM_SENDER

                TransferProtocol.writeBatchHeaderV5(
                    dataOut,
                    TransferProtocol.BatchHeaderV5(
                        flags = flags,
                        batchId = batchId,
                        senderName = myName,
                        totalFilesInBatch = 0,
                        streamFileCount = 0,
                        totalBatchBytes = 0L
                    )
                )

                val handshake = TransferProtocol.performClientHandshakeV5(
                    dataOut = dataOut,
                    dataIn = dataIn,
                    identity = deviceIdentityProvider,
                    flags = flags,
                    batchId = batchId,
                    roleLabel = TransferProtocol.ROLE_PULL,
                    qrPskBytes = qrKeyBytes
                )

                // QR PSK verified -> confirm SAS step automatically
                dataOut.writeByte(TransferProtocol.SAS_CONFIRMED.toInt())
                dataOut.flush()

                val hostAck = TransferProtocol.readAck(dataIn)
                if (hostAck.status != TransferProtocol.RESPONSE_OK) {
                    Log.w(TAG, "QR pull rejected by host (status=${hostAck.status})")
                    if (hostAck.status == TransferProtocol.RESPONSE_AUTH_FAILED) {
                        wifiDirectManager.clearConnectionEncryptionKey()
                        _securityAlerts.tryEmit(context.getString(R.string.error_qr_key_rotated))
                    }
                    return@launch
                }

                val fileCount = dataIn.readInt()
                val totalBatchBytes = dataIn.readLong()
                if (fileCount !in 1..TransferProtocol.MAX_FILES_PER_BATCH || totalBatchBytes < 0L) {
                    return@launch
                }
                if (!storageOrganizer.hasEnoughSpace(totalBatchBytes)) {
                    TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
                    return@launch
                }
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, 0L)

                socket.soTimeout = TransferProtocol.DATA_TIMEOUT_MS
                receiveFilesLoopV5(
                    dataIn = dataIn,
                    dataOut = dataOut,
                    streamFileCount = fileCount,
                    peerName = peerName,
                    peerFingerprint = handshake.peerFingerprint,
                    isChunkedRange = false,
                    secretKey = handshake.sessionKey,
                    trackedIds = activeIds
                )
            } catch (e: SecurityException) {
                Log.w(TAG, "QR pull security error: ${e.message}", e)
                wifiDirectManager.clearConnectionEncryptionKey()
                _securityAlerts.tryEmit(context.getString(R.string.error_qr_key_rotated))
                failActiveTrackedItems(activeIds, context.getString(R.string.error_qr_key_rotated))
            } catch (e: Exception) {
                Log.e(TAG, "QR pull failed", e)
                failActiveTrackedItems(activeIds, e.message ?: context.getString(R.string.error_disconnected))
            } finally {
                wifiDirectManager.clearConnectionEncryptionKey()
                storageOrganizer.cleanupExpiredPartFiles()
                runCatching { socket?.close() }
            }
        }
    }

    /**
     * Protocol V5 batch sender:
     * - ZRTP-style commitment + ECDH P-256 + HKDF-SHA256 + mutual ECDSA P-256 identity signatures
     * - Constant-time QR PSK proof for push sessions; clears stored QR key after batch finishes
     * - Dual-phone SAS confirmation + sender-side receiver fingerprint pinning for non-QR sessions
     * - Stable deterministic transferId for cross-restart resume
     */
    fun sendFiles(
        targetIp: String,
        port: Int = TransferProtocol.DEFAULT_PORT,
        peerName: String,
        files: List<ShareableFile>,
        encryptionKeyBase64: String? = null
    ) {
        if (files.isEmpty()) return
        ensureForegroundService()

        val batchId = UUID.randomUUID().toString()
        val totalBatchBytes = files.sumOf { it.sizeBytes }
        val receiverKey = peerName.ifBlank { targetIp }

        val queuedPairs = files.take(TransferProtocol.MAX_FILES_PER_BATCH).map { file ->
            val id = allocateUniqueStableTransferId(file, receiverKey)
            pauseFlags[id] = AtomicBoolean(false)
            cancelFlags[id] = AtomicBoolean(false)
            val item = TransferItem(
                id = id,
                fileName = file.name,
                sizeBytes = file.sizeBytes,
                mimeType = file.mimeType,
                category = file.category,
                direction = TransferDirection.SEND,
                status = TransferStatus.QUEUED,
                sourceUri = file.uri,
                localPath = file.filePath,
                peerName = peerName
            )
            upsertItem(item, immediate = false)
            file to item
        }
        publishSnapshot()

        scope.launch {
            val senderName = userPreferences.deviceName.first()
            val qrPskBytes = CryptoHelper.decodeKeyBytes(encryptionKeyBase64)

            try {
                if (queuedPairs.size == 1 &&
                    queuedPairs[0].first.sizeBytes >= TransferProtocol.LARGE_FILE_PARALLEL_THRESHOLD &&
                    !queuedPairs[0].first.filePath.isNullOrBlank()
                ) {
                    val (file, item) = queuedPairs[0]
                    sendLargeFileParallelV5(
                        targetIp = targetIp,
                        port = port,
                        peerName = peerName,
                        batchId = batchId,
                        senderName = senderName,
                        file = file,
                        item = item,
                        qrPskBytes = qrPskBytes
                    )
                    return@launch
                }

                val workerCount = when {
                    queuedPairs.size >= 6 -> TransferProtocol.PARALLEL_STREAMS_DEFAULT
                    queuedPairs.size >= 2 -> 2
                    else -> 1
                }
                val partitions = List(workerCount) { mutableListOf<Pair<ShareableFile, TransferItem>>() }
                queuedPairs.forEachIndexed { idx, pair -> partitions[idx % workerCount].add(pair) }

                coroutineScope {
                    partitions.filter { it.isNotEmpty() }.map { workerBatch ->
                        async(Dispatchers.IO) {
                            sendBatchOnReusedSocketV5(
                                targetIp = targetIp,
                                port = port,
                                peerName = peerName,
                                batchId = batchId,
                                senderName = senderName,
                                totalFilesInBatch = queuedPairs.size,
                                totalBatchBytes = totalBatchBytes,
                                workerItems = workerBatch,
                                qrPskBytes = qrPskBytes
                            )
                        }
                    }.awaitAll()
                }
            } finally {
                // Clear one-time QR key after batch finishes so sender never silently reuses a rotated key
                if (qrPskBytes != null) {
                    wifiDirectManager.clearConnectionEncryptionKey()
                }
                // Delete temporary share_cache bundles/copies after sending
                queuedPairs.forEach { (file, _) -> cleanupCachedTempFile(file) }
            }
        }
    }

    private fun allocateUniqueStableTransferId(file: ShareableFile, receiverKey: String): String {
        val base = computeStableTransferId(
            sourceUri = file.uri.toString(),
            sizeBytes = file.sizeBytes,
            lastModified = file.lastModified,
            receiverKey = receiverKey
        )
        var candidate = base
        var suffix = 1
        while (true) {
            val existing = itemMap[candidate]
            val isActive = existing != null && (
                existing.status == TransferStatus.QUEUED ||
                    existing.status == TransferStatus.RUNNING ||
                    existing.status == TransferStatus.VERIFYING ||
                    existing.status == TransferStatus.PAUSED
                )
            if (!isActive) return candidate
            candidate = "${base}_d${suffix++}"
        }
    }

    private suspend fun awaitSenderSasIfNeeded(
        batchId: String,
        peerName: String,
        hs: TransferProtocol.HandshakeResult
    ): Boolean {
        val pinned = userPreferences.getPinnedReceiverFingerprint(peerName)
        val fingerprintChanged = pinned != null && pinned != hs.peerFingerprint

        // Skip SAS ONLY when QR PSK was verified (and no fingerprint change), OR receiver fingerprint is already pinned
        if (!fingerprintChanged && (hs.qrPskVerified || pinned == hs.peerFingerprint)) {
            return true
        }

        val key = ApprovalCoordinator.ApprovalKey(batchId, hs.peerFingerprint)
        senderSasDecisions[key]?.let { existing ->
            return withTimeoutOrNull(SAS_CONFIRM_TIMEOUT_MS) { existing.await() } ?: false
        }

        val deferred = CompletableDeferred<Boolean>()
        val prev = senderSasDecisions.putIfAbsent(key, deferred)
        if (prev != null) {
            return withTimeoutOrNull(SAS_CONFIRM_TIMEOUT_MS) { prev.await() } ?: false
        }

        _pendingSenderSas.value = PendingSasVerification(
            batchId = batchId,
            peerFingerprint = hs.peerFingerprint,
            peerName = peerName,
            sasCode = hs.sasCode,
            fingerprintChangedWarning = fingerprintChanged
        )
        val ok = withTimeoutOrNull(SAS_CONFIRM_TIMEOUT_MS) { deferred.await() } ?: false
        if (_pendingSenderSas.value?.batchId == batchId &&
            _pendingSenderSas.value?.peerFingerprint == hs.peerFingerprint
        ) {
            _pendingSenderSas.value = null
        }
        senderSasDecisions.remove(key, deferred)
        return ok
    }

    private suspend fun sendLargeFileParallelV5(
        targetIp: String,
        port: Int,
        peerName: String,
        batchId: String,
        senderName: String,
        file: ShareableFile,
        item: TransferItem,
        qrPskBytes: ByteArray?
    ) {
        val wholeHash = computeWholeFileSha256(file)
        val streams = TransferProtocol.PARALLEL_STREAMS_DEFAULT
        val chunkSize = file.sizeBytes / streams
        val totalTransferred = AtomicLong(0L)
        val startMs = System.currentTimeMillis()
        updateItem(item.id, immediate = true) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }

        val anyFailed = AtomicBoolean(false)
        @Volatile var failureMessage: String? = null

        coroutineScope {
            (0 until streams).map { index ->
                val rangeStart = index * chunkSize
                val rangeEnd = if (index == streams - 1) file.sizeBytes else (index + 1) * chunkSize
                val rangeLen = rangeEnd - rangeStart
                async(Dispatchers.IO) {
                    var socket: Socket? = null
                    try {
                        socket = createOptimizedSocket(targetIp, port)
                        socket.soTimeout = TransferProtocol.HANDSHAKE_TIMEOUT_MS
                        val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
                        val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

                        var flags = TransferProtocol.FLAG_BATCH or TransferProtocol.FLAG_CHUNKED_RANGE or TransferProtocol.FLAG_ENCRYPTED
                        if (qrPskBytes != null) flags = flags or TransferProtocol.FLAG_USES_QR_PSK

                        TransferProtocol.writeBatchHeaderV5(
                            dataOut,
                            TransferProtocol.BatchHeaderV5(
                                flags = flags,
                                batchId = batchId,
                                senderName = senderName,
                                totalFilesInBatch = 1,
                                streamFileCount = 1,
                                totalBatchBytes = file.sizeBytes
                            )
                        )

                        val hs = TransferProtocol.performClientHandshakeV5(
                            dataOut = dataOut,
                            dataIn = dataIn,
                            identity = deviceIdentityProvider,
                            flags = flags,
                            batchId = batchId,
                            roleLabel = TransferProtocol.ROLE_PUSH,
                            qrPskBytes = qrPskBytes
                        )

                        val sasOk = awaitSenderSasIfNeeded(batchId, peerName, hs)
                        dataOut.writeByte(if (sasOk) TransferProtocol.SAS_CONFIRMED.toInt() else TransferProtocol.SAS_MISMATCH.toInt())
                        dataOut.flush()
                        if (!sasOk) {
                            anyFailed.set(true)
                            failureMessage = context.getString(R.string.sas_mismatch_warning)
                            return@async
                        }

                        socket.soTimeout = TransferProtocol.DATA_TIMEOUT_MS
                        val batchAck = TransferProtocol.readAck(dataIn)
                        if (batchAck.status != TransferProtocol.RESPONSE_OK) {
                            anyFailed.set(true)
                            failureMessage = mapBatchRejectReason(batchAck.status, file.sizeBytes)
                            return@async
                        }

                        val iv = CryptoHelper.generateBaseIv()
                        TransferProtocol.writeFileHeaderV5(
                            dataOut,
                            TransferProtocol.FileHeaderV5(
                                transferId = item.id,
                                fileName = file.name,
                                mimeType = file.mimeType,
                                categoryName = file.category.name,
                                totalSizeBytes = file.sizeBytes,
                                rangeStart = rangeStart,
                                rangeLength = rangeLen,
                                baseIv = iv,
                                hasTrailerHash = false,
                                wholeFileSha256 = wholeHash
                            )
                        )
                        val fileAck = TransferProtocol.readAck(dataIn)
                        if (fileAck.status != TransferProtocol.RESPONSE_OK) {
                            anyFailed.set(true)
                            failureMessage = context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                            return@async
                        }

                        streamRangeOutV5(
                            file = file,
                            transferId = item.id,
                            rangeStart = rangeStart,
                            rangeLength = rangeLen,
                            dataOut = dataOut,
                            secretKey = hs.sessionKey,
                            baseIv = iv,
                            hasher = null
                        ) { delta ->
                            val nowTotal = totalTransferred.addAndGet(delta)
                            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                            val speed = (nowTotal * 1000L) / elapsed
                            val remaining = (file.sizeBytes - nowTotal).coerceAtLeast(0L)
                            val eta = if (speed > 0L) remaining / speed else -1L
                            updateItem(item.id, immediate = false) {
                                it.copy(
                                    transferredBytes = nowTotal.coerceAtMost(file.sizeBytes),
                                    speedBytesPerSec = speed,
                                    etaSeconds = eta,
                                    status = TransferStatus.RUNNING
                                )
                            }
                        }

                        updateItem(item.id, immediate = true) {
                            it.copy(status = TransferStatus.VERIFYING, speedBytesPerSec = 0L, etaSeconds = 0L)
                        }
                        val verifyCode = TransferProtocol.readFinalVerifyByte(dataIn)
                        if (verifyCode != TransferProtocol.VERIFY_OK) {
                            anyFailed.set(true)
                            failureMessage = if (verifyCode == TransferProtocol.VERIFY_STORAGE_ERROR) {
                                context.getString(R.string.error_storage_publish_failed)
                            } else {
                                context.getString(R.string.error_checksum_mismatch)
                            }
                        }
                    } catch (e: SecurityException) {
                        Log.w(TAG, "Parallel stream $index security error: ${e.message}", e)
                        anyFailed.set(true)
                        failureMessage = if (qrPskBytes != null) {
                            _securityAlerts.tryEmit(context.getString(R.string.error_qr_key_rotated))
                            context.getString(R.string.error_qr_key_rotated)
                        } else {
                            e.message ?: context.getString(R.string.sas_mismatch_warning)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Parallel stream $index failed", e)
                        anyFailed.set(true)
                        failureMessage = e.message ?: context.getString(R.string.error_disconnected)
                    } finally {
                        runCatching { socket?.close() }
                    }
                }
            }.awaitAll()
        }

        val finalItem = when {
            cancelFlags[item.id]?.get() == true -> updateAndReturn(item.id, immediate = true) {
                it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
            }
            anyFailed.get() -> updateAndReturn(item.id, immediate = true) {
                it.copy(status = TransferStatus.FAILED, errorMessage = failureMessage, speedBytesPerSec = 0L, etaSeconds = -1L)
            }
            else -> updateAndReturn(item.id, immediate = true) {
                it.copy(transferredBytes = file.sizeBytes, status = TransferStatus.COMPLETED, speedBytesPerSec = 0L, etaSeconds = 0L)
            }
        }
        cleanupTransferState(item.id)
        finalItem?.let { historyRepository.recordTransfer(it) }
    }

    private suspend fun sendBatchOnReusedSocketV5(
        targetIp: String,
        port: Int,
        peerName: String,
        batchId: String,
        senderName: String,
        totalFilesInBatch: Int,
        totalBatchBytes: Long,
        workerItems: List<Pair<ShareableFile, TransferItem>>,
        qrPskBytes: ByteArray?
    ) {
        var socket: Socket? = null
        try {
            socket = createOptimizedSocket(targetIp, port)
            socket.soTimeout = TransferProtocol.HANDSHAKE_TIMEOUT_MS
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), TransferProtocol.BUFFER_SIZE))
            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream()))

            var flags = TransferProtocol.FLAG_BATCH or
                TransferProtocol.FLAG_ENCRYPTED or
                TransferProtocol.FLAG_STREAMING_SHA256_TRAILER
            if (qrPskBytes != null) flags = flags or TransferProtocol.FLAG_USES_QR_PSK

            TransferProtocol.writeBatchHeaderV5(
                dataOut,
                TransferProtocol.BatchHeaderV5(
                    flags = flags,
                    batchId = batchId,
                    senderName = senderName,
                    totalFilesInBatch = totalFilesInBatch,
                    streamFileCount = workerItems.size,
                    totalBatchBytes = totalBatchBytes
                )
            )

            val hs = TransferProtocol.performClientHandshakeV5(
                dataOut = dataOut,
                dataIn = dataIn,
                identity = deviceIdentityProvider,
                flags = flags,
                batchId = batchId,
                roleLabel = TransferProtocol.ROLE_PUSH,
                qrPskBytes = qrPskBytes
            )

            val sasOk = awaitSenderSasIfNeeded(batchId, peerName, hs)
            dataOut.writeByte(if (sasOk) TransferProtocol.SAS_CONFIRMED.toInt() else TransferProtocol.SAS_MISMATCH.toInt())
            dataOut.flush()
            if (!sasOk) {
                failWorkerItems(workerItems, context.getString(R.string.sas_mismatch_warning))
                return
            }

            socket.soTimeout = TransferProtocol.DATA_TIMEOUT_MS
            val batchAck = TransferProtocol.readAck(dataIn)
            if (batchAck.status != TransferProtocol.RESPONSE_OK) {
                failWorkerItems(workerItems, mapBatchRejectReason(batchAck.status, totalBatchBytes))
                return
            }

            streamFilesLoopV5(dataOut, dataIn, workerItems, hs.sessionKey)
        } catch (e: SecurityException) {
            Log.w(TAG, "Batch send security error: ${e.message}", e)
            val msg = if (qrPskBytes != null) {
                _securityAlerts.tryEmit(context.getString(R.string.error_qr_key_rotated))
                context.getString(R.string.error_qr_key_rotated)
            } else {
                e.message ?: context.getString(R.string.sas_mismatch_warning)
            }
            failWorkerItems(workerItems, msg)
        } catch (e: Exception) {
            Log.e(TAG, "Batch send failed", e)
            val msg = e.message?.takeIf { it.isNotBlank() } ?: context.getString(R.string.error_disconnected)
            failWorkerItems(workerItems, msg)
        } finally {
            runCatching { socket?.close() }
        }
    }

    private suspend fun failWorkerItems(workerItems: List<Pair<ShareableFile, TransferItem>>, msg: String) {
        workerItems.forEach { (_, item) ->
            val current = itemMap[item.id]
            if (current != null &&
                current.status != TransferStatus.COMPLETED &&
                current.status != TransferStatus.CANCELLED
            ) {
                val failed = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cleanupTransferState(item.id)
                failed?.let { historyRepository.recordTransfer(it) }
            }
        }
    }

    private fun mapBatchRejectReason(status: Byte, totalBytes: Long): String = when (status) {
        TransferProtocol.RESPONSE_REJECTED -> context.getString(R.string.incoming_rejected_by_peer)
        TransferProtocol.RESPONSE_AUTH_FAILED -> context.getString(R.string.error_qr_key_rotated)
        TransferProtocol.RESPONSE_SAS_MISMATCH -> context.getString(R.string.sas_mismatch_warning)
        else -> context.getString(R.string.error_low_storage, Formatters.formatBytes(totalBytes))
    }

    private suspend fun streamFilesLoopV5(
        dataOut: DataOutputStream,
        dataIn: DataInputStream,
        workerItems: List<Pair<ShareableFile, TransferItem>>,
        sessionKey: SecretKey
    ) {
        for ((file, item) in workerItems) {
            if (cancelFlags[item.id]?.get() == true) {
                val cancelled = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cleanupTransferState(item.id)
                cancelled?.let { historyRepository.recordTransfer(it) }
                continue
            }

            updateItem(item.id, immediate = true) { it.copy(status = TransferStatus.RUNNING, errorMessage = null) }
            val iv = CryptoHelper.generateBaseIv()

            // Streaming SHA-256 trailer optimization: avoid double-reading large sequential files!
            TransferProtocol.writeFileHeaderV5(
                dataOut,
                TransferProtocol.FileHeaderV5(
                    transferId = item.id,
                    fileName = file.name,
                    mimeType = file.mimeType,
                    categoryName = file.category.name,
                    totalSizeBytes = file.sizeBytes,
                    rangeStart = 0L,
                    rangeLength = file.sizeBytes,
                    baseIv = iv,
                    hasTrailerHash = true,
                    wholeFileSha256 = ByteArray(0)
                )
            )

            val fileAck = TransferProtocol.readAck(dataIn)
            if (fileAck.status == TransferProtocol.RESPONSE_LOW_STORAGE) {
                val msg = context.getString(R.string.error_low_storage, Formatters.formatBytes(file.sizeBytes))
                val failed = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.FAILED, errorMessage = msg, speedBytesPerSec = 0L)
                }
                cleanupTransferState(item.id)
                failed?.let { historyRepository.recordTransfer(it) }
                continue
            }
            if (fileAck.status != TransferProtocol.RESPONSE_OK) {
                val cancelled = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L)
                }
                cleanupTransferState(item.id)
                cancelled?.let { historyRepository.recordTransfer(it) }
                continue
            }

            val resumeOffset = fileAck.offsetOrAvailableBytes.coerceIn(0L, file.sizeBytes)
            var sent = resumeOffset
            val startMs = System.currentTimeMillis()

            // If resuming from offset > 0, hash the prefix first so the trailer is still the WHOLE-file SHA-256
            val sha256 = MessageDigest.getInstance("SHA-256")
            if (resumeOffset > 0L) {
                hashFilePrefix(file, resumeOffset, sha256)
            }

            streamRangeOutV5(
                file = file,
                transferId = item.id,
                rangeStart = resumeOffset,
                rangeLength = file.sizeBytes - resumeOffset,
                dataOut = dataOut,
                secretKey = sessionKey,
                baseIv = iv,
                hasher = sha256
            ) { delta ->
                sent += delta
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                val transferredNow = (sent - resumeOffset).coerceAtLeast(0L)
                val speed = (transferredNow * 1000L) / elapsed
                val remaining = (file.sizeBytes - sent).coerceAtLeast(0L)
                val eta = if (speed > 0L) remaining / speed else -1L
                updateItem(item.id, immediate = false) {
                    it.copy(
                        transferredBytes = sent.coerceAtMost(file.sizeBytes),
                        speedBytesPerSec = speed,
                        etaSeconds = eta,
                        status = TransferStatus.RUNNING
                    )
                }
            }

            if (cancelFlags[item.id]?.get() == true) {
                val cancelled = updateAndReturn(item.id, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cleanupTransferState(item.id)
                cancelled?.let { historyRepository.recordTransfer(it) }
                break
            }

            // Send the 32-byte whole-file SHA-256 trailer
            dataOut.write(sha256.digest())
            dataOut.flush()

            updateItem(item.id, immediate = true) {
                it.copy(status = TransferStatus.VERIFYING, speedBytesPerSec = 0L, etaSeconds = 0L)
            }

            val verify = TransferProtocol.readFinalVerifyByte(dataIn)
            val doneItem = when (verify) {
                TransferProtocol.VERIFY_OK -> updateAndReturn(item.id, immediate = true) {
                    it.copy(
                        transferredBytes = file.sizeBytes,
                        status = TransferStatus.COMPLETED,
                        speedBytesPerSec = 0L,
                        etaSeconds = 0L
                    )
                }
                TransferProtocol.VERIFY_STORAGE_ERROR -> updateAndReturn(item.id, immediate = true) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = context.getString(R.string.error_storage_publish_failed),
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
                else -> updateAndReturn(item.id, immediate = true) {
                    it.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = context.getString(R.string.error_checksum_mismatch),
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L
                    )
                }
            }
            cleanupTransferState(item.id)
            doneItem?.let { historyRepository.recordTransfer(it) }
        }
    }

    private suspend fun streamRangeOutV5(
        file: ShareableFile,
        transferId: String,
        rangeStart: Long,
        rangeLength: Long,
        dataOut: DataOutputStream,
        secretKey: SecretKey,
        baseIv: ByteArray,
        hasher: MessageDigest?,
        onBytesSent: (Long) -> Unit
    ) {
        var remaining = rangeLength
        var chunkIndex = 0L
        val plainBuf = ByteArray(TransferProtocol.BUFFER_SIZE)
        val encOutBuf = ByteArray(TransferProtocol.BUFFER_SIZE + CryptoHelper.GCM_TAG_BYTES + 32)
        val nonceScratch = ByteArray(CryptoHelper.BASE_IV_BYTES)

        val localFile = file.filePath?.let { File(it) }?.takeIf { it.exists() && it.canRead() }
        if (localFile != null) {
            FileInputStream(localFile).use { fis ->
                val channel = fis.channel
                if (rangeStart > 0L) channel.position(rangeStart)
                val wrapped = ByteBuffer.wrap(plainBuf)
                while (remaining > 0L) {
                    if (awaitPauseOrCancel(transferId)) break
                    wrapped.clear()
                    wrapped.limit(minOf(TransferProtocol.BUFFER_SIZE.toLong(), remaining).toInt())
                    val read = channel.read(wrapped)
                    if (read <= 0) break
                    hasher?.update(plainBuf, 0, read)
                    val encLen = CryptoHelper.encryptChunkInto(
                        secretKey, baseIv, chunkIndex++, plainBuf, read, encOutBuf, nonceScratch
                    )
                    dataOut.writeInt(encLen)
                    dataOut.write(encOutBuf, 0, encLen)
                    remaining -= read
                    onBytesSent(read.toLong())
                }
            }
        } else {
            val stream = context.contentResolver.openInputStream(file.uri)
                ?: throw IllegalStateException(context.getString(R.string.error_file_unreadable))
            stream.use { input ->
                if (rangeStart > 0L) skipFully(input, rangeStart)
                while (remaining > 0L) {
                    if (awaitPauseOrCancel(transferId)) break
                    val toRead = minOf(plainBuf.size.toLong(), remaining).toInt()
                    val read = input.read(plainBuf, 0, toRead)
                    if (read <= 0) break
                    hasher?.update(plainBuf, 0, read)
                    val encLen = CryptoHelper.encryptChunkInto(
                        secretKey, baseIv, chunkIndex++, plainBuf, read, encOutBuf, nonceScratch
                    )
                    dataOut.writeInt(encLen)
                    dataOut.write(encOutBuf, 0, encLen)
                    remaining -= read
                    onBytesSent(read.toLong())
                }
            }
        }
        dataOut.flush()
    }

    private fun resolveQrPskForBatch(batchId: String): ByteArray? = synchronized(qrSessionLock) {
        activeBatchSessions[batchId]?.qrPskBytes
            ?: CryptoHelper.decodeKeyBytes(_sessionEncryptionKey.value)
    }

    private fun registerAuthenticatedBatchSocket(
        batch: TransferProtocol.BatchHeaderV5,
        hs: TransferProtocol.HandshakeResult
    ): ActiveBatchSession {
        return synchronized(qrSessionLock) {
            val existing = activeBatchSessions[batch.batchId]
            if (existing != null) {
                if (existing.peerFingerprint != hs.peerFingerprint) {
                    throw SecurityException("Batch fingerprint mismatch on reused batchId")
                }
                existing.rotationJob?.cancel()
                existing.rotationJob = null
                existing.activeSockets.incrementAndGet()
                existing
            } else {
                val created = ActiveBatchSession(
                    batchId = batch.batchId,
                    peerFingerprint = hs.peerFingerprint,
                    qrPskBytes = hs.usedQrPskBytes,
                    usesQrPsk = hs.qrPskVerified,
                    activeSockets = AtomicInteger(1),
                    totalFilesExpected = batch.totalFilesInBatch
                )
                activeBatchSessions[batch.batchId] = created
                created
            }
        }
    }

    private fun releaseBatchSocketAndMaybeRotateQrKey(session: ActiveBatchSession, abortedOrCancelled: Boolean) {
        val remaining = session.activeSockets.decrementAndGet()
        if (remaining > 0) return

        synchronized(qrSessionLock) {
            if (session.activeSockets.get() > 0) return
            if (!session.usesQrPsk) {
                activeBatchSessions.remove(session.batchId, session)
                return
            }

            val batchDone = abortedOrCancelled ||
                session.totalFilesExpected <= 0 ||
                session.filesCompleted.get() >= session.totalFilesExpected

            if (batchDone) {
                activeBatchSessions.remove(session.batchId, session)
                _sessionEncryptionKey.value = CryptoHelper.generateKeyBase64()
            } else {
                // Short grace window so staggered parallel worker sockets of the same batch can still join
                session.rotationJob?.cancel()
                session.rotationJob = scope.launch {
                    delay(QR_BATCH_ROTATION_GRACE_MS)
                    synchronized(qrSessionLock) {
                        if (session.activeSockets.get() == 0 &&
                            activeBatchSessions.remove(session.batchId, session)
                        ) {
                            _sessionEncryptionKey.value = CryptoHelper.generateKeyBase64()
                        }
                    }
                }
            }
        }
    }

    private suspend fun handleIncomingSocket(socket: Socket) {
        val trackedIds = mutableListOf<String>()
        var batchSession: ActiveBatchSession? = null
        var abortedOrCancelled = false
        try {
            socket.tcpNoDelay = true
            socket.receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
            socket.soTimeout = TransferProtocol.HANDSHAKE_TIMEOUT_MS

            val remoteIp = socket.inetAddress?.hostAddress ?: "unknown"
            val dataIn = DataInputStream(BufferedInputStream(socket.getInputStream(), TransferProtocol.BUFFER_SIZE))
            val dataOut = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

            // Strictly enforce Protocol V5 only (rejects V1/V2/V3/V4)
            TransferProtocol.readAndVerifyVersionV5(dataIn)
            val batch = TransferProtocol.readBatchHeaderV5Body(dataIn)

            // Handshake verifies ZRTP commitment + QR proof BEFORE any state change, approval, or rotation
            val hs = TransferProtocol.performServerHandshakeV5(
                dataIn = dataIn,
                dataOut = dataOut,
                identity = deviceIdentityProvider,
                batch = batch,
                resolveQrPskForBatch = { id -> resolveQrPskForBatch(id) }
            )

            // Register authenticated batch session (does NOT rotate QR key yet!)
            batchSession = registerAuthenticatedBatchSocket(batch, hs)

            socket.soTimeout = TransferProtocol.DATA_TIMEOUT_MS

            // Both sides must confirm SAS (when non-QR & untrusted) BEFORE any file data flows
            val clientSasByte = dataIn.readByte()
            if (clientSasByte != TransferProtocol.SAS_CONFIRMED) {
                abortedOrCancelled = true
                _securityAlerts.tryEmit(context.getString(R.string.sas_mismatch_warning))
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_SAS_MISMATCH, 0L)
                return
            }

            // Receiver approval keyed by (batchId, peerFingerprint) with bounded queue + per-IP rate limit
            val approved = awaitBatchApproval(batch, hs, remoteIp)
            if (!approved) {
                abortedOrCancelled = true
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_REJECTED, 0L)
                return
            }

            if (batch.isPullRequest) {
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, 0L)
                val files = stagedQrSendFiles
                dataOut.writeInt(files.size)
                dataOut.writeLong(files.sumOf { it.sizeBytes })
                dataOut.flush()
                if (files.isEmpty()) return

                val receiverAck = TransferProtocol.readAck(dataIn)
                if (receiverAck.status != TransferProtocol.RESPONSE_OK) {
                    abortedOrCancelled = true
                    return
                }

                ensureForegroundService()
                val pairs = files.map { f ->
                    val id = allocateUniqueStableTransferId(f, hs.peerFingerprint)
                    pauseFlags[id] = AtomicBoolean(false)
                    cancelFlags[id] = AtomicBoolean(false)
                    trackedIds.add(id)
                    val item = TransferItem(
                        id = id,
                        fileName = f.name,
                        sizeBytes = f.sizeBytes,
                        mimeType = f.mimeType,
                        category = f.category,
                        direction = TransferDirection.SEND,
                        status = TransferStatus.QUEUED,
                        sourceUri = f.uri,
                        localPath = f.filePath,
                        peerName = batch.senderName
                    )
                    upsertItem(item, immediate = false)
                    f to item
                }
                publishSnapshot()
                streamFilesLoopV5(dataOut, dataIn, pairs, hs.sessionKey)
                batchSession.filesCompleted.addAndGet(pairs.size)
                return
            }

            if (!storageOrganizer.hasEnoughSpace(batch.totalBatchBytes)) {
                abortedOrCancelled = true
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
                return
            }

            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, 0L)
            ensureForegroundService()

            val completedCount = receiveFilesLoopV5(
                dataIn = dataIn,
                dataOut = dataOut,
                streamFileCount = batch.streamFileCount,
                peerName = batch.senderName,
                peerFingerprint = hs.peerFingerprint,
                isChunkedRange = batch.isChunkedRange,
                secretKey = hs.sessionKey,
                trackedIds = trackedIds
            )
            batchSession.filesCompleted.addAndGet(completedCount)
        } catch (e: SecurityException) {
            abortedOrCancelled = true
            Log.w(TAG, "Incoming V5 security rejection: ${e.message}")
            failActiveTrackedItems(trackedIds, e.message ?: context.getString(R.string.error_disconnected))
        } catch (e: Exception) {
            abortedOrCancelled = true
            Log.e(TAG, "Incoming V5 session failed", e)
            failActiveTrackedItems(trackedIds, e.message ?: context.getString(R.string.error_disconnected))
        } finally {
            batchSession?.let { releaseBatchSocketAndMaybeRotateQrKey(it, abortedOrCancelled) }
            storageOrganizer.cleanupExpiredPartFiles()
            runCatching { socket.close() }
        }
    }

    private suspend fun receiveFilesLoopV5(
        dataIn: DataInputStream,
        dataOut: DataOutputStream,
        streamFileCount: Int,
        peerName: String,
        peerFingerprint: String,
        isChunkedRange: Boolean,
        secretKey: SecretKey,
        trackedIds: MutableList<String>
    ): Int {
        val encInBuf = ByteArray(TransferProtocol.MAX_ENC_CHUNK_BYTES)
        val plainOutBuf = ByteArray(TransferProtocol.BUFFER_SIZE + 64)
        val nonceScratch = ByteArray(CryptoHelper.BASE_IV_BYTES)
        val outWriteLock = Any()
        var completedInStream = 0

        for (i in 0 until streamFileCount) {
            val header = TransferProtocol.readFileHeaderV5(dataIn)
            val transferId = header.transferId
            trackedIds.add(transferId)
            val category = runCatching { FileCategory.valueOf(header.categoryName) }
                .getOrElse { Formatters.inferCategory(header.fileName, header.mimeType) }

            val partFile = if (isChunkedRange) {
                parallelRangePartFiles.getOrPut(transferId) {
                    storageOrganizer.resolvePartFile(transferId, peerFingerprint, header.totalSizeBytes)
                }
            } else {
                storageOrganizer.resolvePartFile(transferId, peerFingerprint, header.totalSizeBytes)
            }

            val resumeOffset = if (isChunkedRange) {
                header.rangeStart
            } else if (partFile.exists() && partFile.length() in 1L until header.totalSizeBytes) {
                partFile.length()
            } else {
                0L
            }

            val bytesToReceive = if (isChunkedRange) {
                header.rangeLength
            } else {
                (header.totalSizeBytes - resumeOffset).coerceAtLeast(0L)
            }

            if (!storageOrganizer.hasEnoughSpace(bytesToReceive)) {
                TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_LOW_STORAGE, storageOrganizer.getAvailableBytes())
                continue
            }

            pauseFlags.putIfAbsent(transferId, AtomicBoolean(false))
            cancelFlags.putIfAbsent(transferId, AtomicBoolean(false))

            if (!itemMap.containsKey(transferId)) {
                upsertItem(
                    TransferItem(
                        id = transferId,
                        fileName = StorageOrganizer.sanitizeFileName(header.fileName),
                        sizeBytes = header.totalSizeBytes,
                        transferredBytes = if (isChunkedRange) 0L else resumeOffset,
                        mimeType = header.mimeType,
                        category = category,
                        direction = TransferDirection.RECEIVE,
                        status = TransferStatus.RUNNING,
                        peerName = peerName
                    ),
                    immediate = true
                )
            }

            TransferProtocol.writeAck(dataOut, TransferProtocol.RESPONSE_OK, resumeOffset)

            val progressCounter = parallelProgressBytes.getOrPut(transferId) {
                AtomicLong(if (isChunkedRange) 0L else resumeOffset)
            }
            val startMs = System.currentTimeMillis()
            var receivedInRange = 0L
            var chunkIndex = 0L

            RandomAccessFile(partFile, "rw").use { raf ->
                val channel = raf.channel
                var writePos = resumeOffset
                while (receivedInRange < bytesToReceive) {
                    if (awaitPauseOrCancel(transferId)) break
                    val encLen = dataIn.readInt()
                    TransferProtocol.validateEncryptedChunkLength(encLen)
                    dataIn.readFully(encInBuf, 0, encLen)
                    val plainLen = CryptoHelper.decryptChunkInto(
                        secretKey, header.baseIv, chunkIndex++, encInBuf, encLen, plainOutBuf, nonceScratch
                    )
                    val writeBuf = ByteBuffer.wrap(plainOutBuf, 0, plainLen)
                    while (writeBuf.hasRemaining()) {
                        writePos += channel.write(writeBuf, writePos)
                    }
                    receivedInRange += plainLen
                    val totalNow = progressCounter.addAndGet(plainLen.toLong())
                    val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                    val speed = (receivedInRange * 1000L) / elapsed
                    val remaining = (header.totalSizeBytes - totalNow).coerceAtLeast(0L)
                    val eta = if (speed > 0L) remaining / speed else -1L
                    updateItem(transferId, immediate = false) {
                        it.copy(
                            transferredBytes = totalNow.coerceAtMost(header.totalSizeBytes),
                            speedBytesPerSec = speed,
                            etaSeconds = eta,
                            status = TransferStatus.RUNNING
                        )
                    }
                }
            }

            if (cancelFlags[transferId]?.get() == true) {
                partFile.delete()
                val cancelled = updateAndReturn(transferId, immediate = true) {
                    it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cleanupTransferState(transferId)
                cancelled?.let { historyRepository.recordTransfer(it) }
                return completedInStream
            }

            // Read 32-byte streaming SHA-256 trailer if sender used trailer mode
            val expectedWholeHash = if (header.hasTrailerHash) {
                ByteArray(32).also { dataIn.readFully(it) }
            } else {
                header.wholeFileSha256
            }

            val finishedAllBytes = progressCounter.get() >= header.totalSizeBytes
            if (!finishedAllBytes) {
                // Parallel range completed; other ranges still in flight
                synchronized(outWriteLock) {
                    dataOut.writeByte(TransferProtocol.VERIFY_OK.toInt())
                    dataOut.flush()
                }
                continue
            }

            // Send VERIFY_PENDING keepalive every 5s so slow phones never time out during large-file hash/publish
            updateItem(transferId, immediate = true) {
                it.copy(status = TransferStatus.VERIFYING, speedBytesPerSec = 0L, etaSeconds = 0L)
            }
            val keepaliveJob = scope.launch {
                while (isActive) {
                    delay(TransferProtocol.VERIFY_KEEPALIVE_INTERVAL_MS)
                    runCatching {
                        synchronized(outWriteLock) {
                            dataOut.writeByte(TransferProtocol.VERIFY_PENDING.toInt())
                            dataOut.flush()
                        }
                    }
                }
            }

            val (isWinner, verifyResult) = try {
                parallelCompletionCoordinator.executeOnce(transferId) {
                    verifyAndPublishOnce(
                        transferId = transferId,
                        partFile = partFile,
                        header = header,
                        category = category,
                        expectedWholeHash = expectedWholeHash
                    )
                }
            } finally {
                keepaliveJob.cancel()
            }

            synchronized(outWriteLock) {
                dataOut.writeByte(verifyResult.toInt())
                dataOut.flush()
            }

            if (isWinner) {
                parallelCompletionCoordinator.clear(transferId)
                if (verifyResult == TransferProtocol.VERIFY_OK) {
                    completedInStream++
                }
            }
        }
        return completedInStream
    }

    private suspend fun verifyAndPublishOnce(
        transferId: String,
        partFile: File,
        header: TransferProtocol.FileHeaderV5,
        category: FileCategory,
        expectedWholeHash: ByteArray
    ): Byte {
        val computedHash = computeFileSha256(partFile)
        val hashMatches = CryptoHelper.constantTimeEquals(computedHash, expectedWholeHash)
        if (!hashMatches) {
            partFile.delete()
            val failed = updateAndReturn(transferId, immediate = true) {
                it.copy(
                    status = TransferStatus.FAILED,
                    errorMessage = context.getString(R.string.error_checksum_mismatch),
                    speedBytesPerSec = 0L,
                    etaSeconds = -1L
                )
            }
            cleanupTransferState(transferId)
            failed?.let { historyRepository.recordTransfer(it) }
            return TransferProtocol.VERIFY_HASH_MISMATCH
        }

        return try {
            val publishedLocation = storageOrganizer.publishCompletedFile(
                partFile = partFile,
                fileName = header.fileName,
                mimeType = header.mimeType,
                category = category
            )
            if (category == FileCategory.CONTACTS || header.fileName.endsWith(".vcf", ignoreCase = true)) {
                _lastReceivedVcfLocation.value = publishedLocation
            }
            val completed = updateAndReturn(transferId, immediate = true) {
                it.copy(
                    transferredBytes = header.totalSizeBytes,
                    status = TransferStatus.COMPLETED,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    localPath = publishedLocation
                )
            }
            cleanupTransferState(transferId)
            completed?.let { historyRepository.recordTransfer(it) }
            TransferProtocol.VERIFY_OK
        } catch (e: MediaStorePublishException) {
            Log.e(TAG, "Publishing received file failed", e)
            // Clean up .part on publish failure (never silently fall back to hidden folder)
            partFile.delete()
            val failed = updateAndReturn(transferId, immediate = true) {
                it.copy(
                    status = TransferStatus.FAILED,
                    errorMessage = context.getString(R.string.error_storage_publish_failed),
                    speedBytesPerSec = 0L,
                    etaSeconds = -1L
                )
            }
            cleanupTransferState(transferId)
            failed?.let { historyRepository.recordTransfer(it) }
            TransferProtocol.VERIFY_STORAGE_ERROR
        }
    }

    private suspend fun awaitBatchApproval(
        batch: TransferProtocol.BatchHeaderV5,
        hs: TransferProtocol.HandshakeResult,
        remoteIp: String
    ): Boolean {
        val trusted = userPreferences.trustedDevices.first()
        if (hs.peerFingerprint in trusted) return true

        val fileCount = if (batch.isPullRequest) stagedQrSendFiles.size else batch.totalFilesInBatch
        val totalBytes = if (batch.isPullRequest) stagedQrSendFiles.sumOf { it.sizeBytes } else batch.totalBatchBytes

        val request = IncomingTransferRequest(
            batchId = batch.batchId,
            senderFingerprint = hs.peerFingerprint,
            senderName = batch.senderName,
            fileCount = fileCount,
            totalBytes = totalBytes,
            verificationCode = if (hs.qrPskVerified) null else hs.sasCode,
            isPullRequest = batch.isPullRequest
        )
        return approvalCoordinator.awaitApproval(request, remoteIp)
    }

    private fun hashFilePrefix(file: ShareableFile, prefixBytes: Long, md: MessageDigest) {
        val buf = ByteArray(256 * 1024)
        val stream = if (!file.filePath.isNullOrBlank() && File(file.filePath).canRead()) {
            FileInputStream(File(file.filePath))
        } else {
            context.contentResolver.openInputStream(file.uri)
                ?: throw IllegalStateException(context.getString(R.string.error_file_unreadable))
        }
        stream.use { input ->
            var remaining = prefixBytes
            while (remaining > 0L) {
                val read = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (read <= 0) break
                md.update(buf, 0, read)
                remaining -= read
            }
        }
    }

    private fun computeWholeFileSha256(file: ShareableFile): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(256 * 1024)
        val stream = if (!file.filePath.isNullOrBlank() && File(file.filePath).canRead()) {
            FileInputStream(File(file.filePath))
        } else {
            context.contentResolver.openInputStream(file.uri)
                ?: throw IllegalStateException(context.getString(R.string.error_file_unreadable))
        }
        stream.use { input ->
            while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                md.update(buf, 0, read)
            }
        }
        return md.digest()
    }

    private fun computeFileSha256(file: File): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(256 * 1024)
        FileInputStream(file).use { input ->
            while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                md.update(buf, 0, read)
            }
        }
        return md.digest()
    }

    private fun cleanupCachedTempFile(file: ShareableFile) {
        if (!file.isCachedTempFile) return
        val path = file.filePath ?: return
        runCatching {
            val f = File(path)
            if (f.exists() && f.parentFile?.name == "share_cache") {
                f.delete()
            }
        }
    }

    private suspend fun failActiveTrackedItems(ids: List<String>, message: String) {
        ids.distinct().forEach { id ->
            val current = itemMap[id]
            if (current != null &&
                (current.status == TransferStatus.RUNNING ||
                    current.status == TransferStatus.QUEUED ||
                    current.status == TransferStatus.VERIFYING ||
                    current.status == TransferStatus.PAUSED)
            ) {
                val failed = updateAndReturn(id, immediate = true) {
                    it.copy(status = TransferStatus.FAILED, errorMessage = message, speedBytesPerSec = 0L, etaSeconds = -1L)
                }
                cleanupTransferState(id)
                failed?.let { historyRepository.recordTransfer(it) }
            }
        }
    }

    private fun cleanupTransferState(transferId: String) {
        pauseFlags.remove(transferId)
        cancelFlags.remove(transferId)
        parallelProgressBytes.remove(transferId)
        parallelRangePartFiles.remove(transferId)
        parallelCompletionCoordinator.clear(transferId)
    }

    fun pauseTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        updateItem(transferId, immediate = true) { item ->
            if (item.status == TransferStatus.RUNNING || item.status == TransferStatus.QUEUED) {
                item.copy(status = TransferStatus.PAUSED, speedBytesPerSec = 0L, etaSeconds = -1L)
            } else item
        }
    }

    fun resumeTransfer(transferId: String) {
        pauseFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(false)
        updateItem(transferId, immediate = true) { item ->
            if (item.status == TransferStatus.PAUSED) item.copy(status = TransferStatus.RUNNING) else item
        }
    }

    fun cancelTransfer(transferId: String) {
        cancelFlags.getOrPut(transferId) { AtomicBoolean(false) }.set(true)
        pauseFlags[transferId]?.set(false)
        updateItem(transferId, immediate = true) {
            it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L, etaSeconds = -1L)
        }
    }

    fun pauseAllActive() {
        _transfers.value.forEach {
            if (it.status == TransferStatus.RUNNING || it.status == TransferStatus.QUEUED) pauseTransfer(it.id)
        }
    }

    fun resumeAllPaused() {
        _transfers.value.forEach {
            if (it.status == TransferStatus.PAUSED) resumeTransfer(it.id)
        }
    }

    fun cancelAllActive() {
        _transfers.value.forEach { item ->
            if (item.status == TransferStatus.RUNNING ||
                item.status == TransferStatus.QUEUED ||
                item.status == TransferStatus.PAUSED
            ) {
                cancelTransfer(item.id)
            }
        }
    }

    fun clearFinished() {
        val activeIds = itemOrder.filter { id ->
            val st = itemMap[id]?.status
            st == TransferStatus.RUNNING ||
                st == TransferStatus.QUEUED ||
                st == TransferStatus.VERIFYING ||
                st == TransferStatus.PAUSED
        }
        val keepSet = activeIds.toSet()
        itemMap.keys.filterNot { it in keepSet }.forEach {
            itemMap.remove(it)
            cleanupTransferState(it)
        }
        itemOrder.clear()
        itemOrder.addAll(activeIds)
        publishSnapshot()
    }

    fun clearLastReceivedVcf() {
        _lastReceivedVcfLocation.value = null
    }

    private suspend fun awaitPauseOrCancel(transferId: String): Boolean {
        if (cancelFlags[transferId]?.get() == true) return true
        while (pauseFlags[transferId]?.get() == true) {
            if (cancelFlags[transferId]?.get() == true) return true
            delay(150L)
        }
        return cancelFlags[transferId]?.get() == true
    }

    private fun createOptimizedSocket(ip: String, port: Int): Socket {
        var lastError: Exception? = null
        val preferredNet = wifiDirectManager.getPreferredTransferNetwork()
        for (attempt in 1..3) {
            val socket = try {
                if (preferredNet != null && attempt <= 2) {
                    preferredNet.socketFactory.createSocket()
                } else {
                    Socket()
                }
            } catch (_: Exception) {
                Socket()
            }
            try {
                socket.tcpNoDelay = true
                socket.sendBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                socket.receiveBufferSize = TransferProtocol.SOCKET_BUFFER_SIZE
                socket.connect(InetSocketAddress(ip, port), 12_000)
                socket.soTimeout = TransferProtocol.DATA_TIMEOUT_MS
                return socket
            } catch (e: Exception) {
                lastError = e
                runCatching { socket.close() }
                if (attempt < 3) {
                    try { Thread.sleep(800L) } catch (_: InterruptedException) { break }
                }
            }
        }
        throw lastError ?: IllegalStateException(context.getString(R.string.error_disconnected))
    }

    private fun skipFully(stream: InputStream, bytesToSkip: Long) {
        var remaining = bytesToSkip
        val discard = ByteArray(64 * 1024)
        while (remaining > 0L) {
            val skipped = stream.skip(remaining)
            if (skipped > 0L) remaining -= skipped
            else {
                val read = stream.read(discard, 0, minOf(discard.size.toLong(), remaining).toInt())
                if (read == -1) break
                remaining -= read
            }
        }
    }

    private fun upsertItem(item: TransferItem, immediate: Boolean) {
        if (!itemMap.containsKey(item.id)) itemOrder.add(0, item.id)
        itemMap[item.id] = item
        if (immediate) publishSnapshot() else uiDirty.set(true)
    }

    private fun updateItem(id: String, immediate: Boolean, transform: (TransferItem) -> TransferItem) {
        val prev = itemMap[id] ?: return
        itemMap[id] = transform(prev)
        if (immediate) publishSnapshot() else uiDirty.set(true)
    }

    private fun updateAndReturn(id: String, immediate: Boolean, transform: (TransferItem) -> TransferItem): TransferItem? {
        val prev = itemMap[id] ?: return null
        val next = transform(prev)
        itemMap[id] = next
        if (immediate) publishSnapshot() else uiDirty.set(true)
        return next
    }

    private fun publishSnapshot() {
        _transfers.value = itemOrder.mapNotNull { itemMap[it] }
    }

    private fun ensureForegroundService() {
        val intent = Intent(context, TransferForegroundService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && e is ForegroundServiceStartNotAllowedException) {
                Log.w(TAG, "Cannot start foreground service from background", e)
            } else {
                Log.w(TAG, "Failed to start foreground service", e)
            }
        }
    }
}
