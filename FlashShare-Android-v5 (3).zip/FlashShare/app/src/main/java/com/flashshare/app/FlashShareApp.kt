package com.flashshare.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.flashshare.app.data.storage.StorageOrganizer
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class FlashShareApp : Application(), ImageLoaderFactory {

    @Inject
    lateinit var storageOrganizer: StorageOrganizer

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        // Clean stale temporary split-APK/share copies and .part files older than 7 days
        appScope.launch {
            runCatching { storageOrganizer.cleanupShareCache() }
            runCatching { storageOrganizer.cleanupExpiredPartFiles() }
        }
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .crossfade(true)
            .build()
    }
}
