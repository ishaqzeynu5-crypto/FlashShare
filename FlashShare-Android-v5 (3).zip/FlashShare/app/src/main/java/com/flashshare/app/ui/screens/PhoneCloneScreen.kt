package com.flashshare.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flashshare.app.BuildConfig
import com.flashshare.app.R
import com.flashshare.app.domain.model.PhoneCloneSelection
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.ui.permissions.PermissionRationaleDialog
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineStrong
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneCloneScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenSendRadar: () -> Unit,
    onOpenReceiveQr: () -> Unit,
    onOpenTransfers: () -> Unit
) {
    val context = LocalContext.current
    val summary by viewModel.cloneSummary.collectAsState()
    val isPreparing by viewModel.isPreparingClone.collectAsState()
    val lastVcfPath by viewModel.lastReceivedVcfPath.collectAsState()

    var selection by remember { mutableStateOf(PhoneCloneSelection(includeContacts = BuildConfig.ENABLE_CONTACTS_CLONE)) }
    var showContactsDialog by remember { mutableStateOf(false) }

    val clonePermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.loadPhoneCloneSummary()
    }

    LaunchedEffect(Unit) {
        val needed = ((if (BuildConfig.ENABLE_CONTACTS_CLONE) PermissionHelper.contactsPermissions() else emptyArray()) + PermissionHelper.mediaPermissions()).distinct().toTypedArray()
        if (PermissionHelper.hasAll(context, needed)) {
            viewModel.loadPhoneCloneSummary()
        } else {
            showContactsDialog = true
        }
    }

    if (showContactsDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_contacts_title),
            description = stringResource(R.string.perm_contacts_desc),
            onGrantClick = {
                showContactsDialog = false
                clonePermLauncher.launch(
                    ((if (BuildConfig.ENABLE_CONTACTS_CLONE) PermissionHelper.contactsPermissions() else emptyArray()) + PermissionHelper.mediaPermissions()).distinct().toTypedArray()
                )
            },
            onOpenSettingsClick = {
                showContactsDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = {
                showContactsDialog = false
                viewModel.loadPhoneCloneSummary()
            }
        )
    }

    Scaffold(
        containerColor = BgBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
                title = { Text(stringResource(R.string.clone_title), color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = TextPrimary
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = stringResource(R.string.clone_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            OutlinedButton(
                onClick = onOpenReceiveQr,
                border = BorderStroke(1.dp, OutlineStrong),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
            ) {
                Text(stringResource(R.string.clone_new_phone), color = TextPrimary)
            }

            if (BuildConfig.ENABLE_CONTACTS_CLONE && lastVcfPath != null) {
                Button(
                    onClick = {
                        viewModel.importReceivedContacts { count ->
                            viewModel.showMessage(context.getString(R.string.clone_contacts_imported, count))
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                ) {
                    Text(stringResource(R.string.clone_import_contacts), fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = stringResource(R.string.clone_old_phone),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            if (BuildConfig.ENABLE_CONTACTS_CLONE) {
                CloneCategoryRow(
                    icon = AppIcons.Contacts,
                    title = stringResource(R.string.clone_contacts),
                    subtitle = stringResource(R.string.clone_contacts_count, summary.contactCount),
                    checked = selection.includeContacts,
                    onToggle = { selection = selection.copy(includeContacts = !selection.includeContacts) }
                )
            }

            CloneCategoryRow(
                icon = AppIcons.PhotoLibrary,
                title = stringResource(R.string.clone_photos),
                subtitle = stringResource(R.string.clone_items_summary, summary.photoCount, Formatters.formatBytes(summary.photoBytes)),
                checked = selection.includePhotos,
                onToggle = { selection = selection.copy(includePhotos = !selection.includePhotos) }
            )

            CloneCategoryRow(
                icon = AppIcons.PlayCircle,
                title = stringResource(R.string.clone_videos),
                subtitle = stringResource(R.string.clone_items_summary, summary.videoCount, Formatters.formatBytes(summary.videoBytes)),
                checked = selection.includeVideos,
                onToggle = { selection = selection.copy(includeVideos = !selection.includeVideos) }
            )

            CloneCategoryRow(
                icon = AppIcons.MusicNote,
                title = stringResource(R.string.clone_music),
                subtitle = stringResource(R.string.clone_items_summary, summary.musicCount, Formatters.formatBytes(summary.musicBytes)),
                checked = selection.includeMusic,
                onToggle = { selection = selection.copy(includeMusic = !selection.includeMusic) }
            )

            if (isPreparing) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(color = TextPrimary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(stringResource(R.string.clone_preparing), color = TextSecondary)
                }
            } else {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = {
                        viewModel.startPhoneCloneSend(selection) { sentImmediately ->
                            if (sentImmediately) onOpenTransfers() else onOpenSendRadar()
                        }
                    },
                    enabled = (BuildConfig.ENABLE_CONTACTS_CLONE && selection.includeContacts) || selection.includePhotos ||
                        selection.includeVideos || selection.includeMusic,
                    colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                ) {
                    Text(stringResource(R.string.clone_start), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun CloneCategoryRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, OutlineSubtle),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = TextPrimary)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
        }
    }
}
