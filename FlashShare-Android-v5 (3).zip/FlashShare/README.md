# FlashShare v5.0.0 — Offline Android File Sharing

**FlashShare** (`com.flashshare.app`) is a 100% offline Android file-sharing application built with **Kotlin 2.0.21**, **Jetpack Compose (Material 3, BOM 2025.05.00)**, **Hilt 2.56.2**, **Room 2.7.1**, **CameraX 1.4.2 + offline ZXing**, and **Protocol V5** (ZRTP-style hash-committed ECDH P-256 + mutual ECDSA Android Keystore identity + HKDF-SHA256 + AES-256-GCM + dual-phone SAS confirmation + whole-file SHA-256).

- **SDK**: `minSdk = 24`, `compileSdk = 36`, `targetSdk = 36` (Android 16)
- **Toolchain**: AGP `8.9.1`, Gradle `8.11.1`, JDK `17`
- **Appearance**: Consistently dark-only monochrome UI (`#0A0A0B`) with dark system bars regardless of OS light/dark setting
- **Languages**: English (`en`), Afaan Oromoo (`om`), Amharic (`am`) with bundled offline `NotoSans` + `NotoSansEthiopic` fonts
- **Flavors**: `full` (includes Phone Clone contacts, Apps tab, and `.apks` `PackageInstaller`) and `play` (removes `READ_CONTACTS`, `WRITE_CONTACTS`, `REQUEST_INSTALL_PACKAGES`, and `<queries>` for Google Play policy compliance)
- **Privacy**: 100% offline, zero ads, zero analytics, zero tracking (see [PRIVACY.md](PRIVACY.md))

## Generate Gradle Wrapper & Build Locally
Because `gradle` and outbound internet are unavailable in the packaging sandbox, generate and commit the Gradle wrapper once locally before pushing to CI:
```bash
gradle wrapper --gradle-version 8.11.1 --distribution-type bin
chmod +x gradlew
```

Then build, lint, and test both flavors:
```bash
./gradlew assembleFullDebug assemblePlayDebug lintFullDebug lintPlayDebug testFullDebugUnitTest testPlayDebugUnitTest
./gradlew assembleFullRelease assemblePlayRelease
```

## CI / GitHub Actions Release Signing
Configure these **Repository Secrets** so CI signs releases with your persistent keystore (never generated per run):
- `FLASHSHARE_KEYSTORE_BASE64`: Base64-encoded `.jks` keystore (`base64 -w 0 flashshare-release.jks`)
- `FLASHSHARE_KEY_ALIAS`
- `FLASHSHARE_STORE_PASSWORD`
- `FLASHSHARE_KEY_PASSWORD`

See [CHANGELOG.md](CHANGELOG.md) for the complete v5.0.0 item-by-item verification log.
