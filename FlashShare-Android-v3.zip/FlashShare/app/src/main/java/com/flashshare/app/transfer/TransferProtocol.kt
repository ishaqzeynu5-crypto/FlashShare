package com.flashshare.app.transfer

import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Framed TCP transfer protocol:
 * - V1: legacy single-file framing (backward compatible on receiver)
 * - V2: persistent batch reuse, parallel ranges, optional QR AES-GCM, CRC32 (backward compatible)
 * - V3: always-on AES-256-GCM (QR one-time key OR ephemeral ECDH P-256 handshake) +
 *       sender-hosted QR pull mode (receiver scans sender's QR and pulls files directly)
 */
object TransferProtocol {
    const val DEFAULT_PORT: Int = 8988
    const val MAX_PORT_FALLBACK: Int = 8998
    const val MAGIC: Int = 0x46534831 // "FSH1"
    const val PROTOCOL_VERSION_V1: Int = 1
    const val PROTOCOL_VERSION_V2: Int = 2
    const val PROTOCOL_VERSION_V3: Int = 3

    const val BUFFER_SIZE: Int = 512 * 1024
    const val SOCKET_BUFFER_SIZE: Int = 1024 * 1024
    const val LARGE_FILE_PARALLEL_THRESHOLD: Long = 32L * 1024L * 1024L
    const val PARALLEL_STREAMS_DEFAULT: Int = 3

    // Flags
    const val FLAG_ENCRYPTED: Int = 0x01
    const val FLAG_BATCH: Int = 0x02
    const val FLAG_CHUNKED_RANGE: Int = 0x04
    const val FLAG_ECDH_KEY_EXCHANGE: Int = 0x08
    const val FLAG_PULL_FROM_SENDER: Int = 0x10

    // Response codes
    const val RESPONSE_OK: Byte = 1
    const val RESPONSE_LOW_STORAGE: Byte = 2
    const val RESPONSE_REJECTED: Byte = 3

    // Integrity codes
    const val VERIFY_OK: Byte = 10
    const val VERIFY_CRC_MISMATCH: Byte = 11

    data class FileHeader(
        val transferId: String,
        val fileName: String,
        val mimeType: String,
        val categoryName: String,
        val senderName: String,
        val totalSizeBytes: Long
    )

    data class ReceiverAck(
        val status: Byte,
        val offsetOrAvailableBytes: Long
    )

    data class BatchHeaderV2(
        val flags: Int,
        val batchId: String,
        val senderId: String,
        val senderName: String,
        val totalFilesInBatch: Int,
        val streamFileCount: Int,
        val totalBatchBytes: Long
    ) {
        val isEncrypted: Boolean get() = (flags and FLAG_ENCRYPTED) != 0
        val isChunkedRange: Boolean get() = (flags and FLAG_CHUNKED_RANGE) != 0
        val usesEcdh: Boolean get() = (flags and FLAG_ECDH_KEY_EXCHANGE) != 0
        val isPullRequest: Boolean get() = (flags and FLAG_PULL_FROM_SENDER) != 0
    }

    data class FileHeaderV2(
        val transferId: String,
        val fileName: String,
        val mimeType: String,
        val categoryName: String,
        val totalSizeBytes: Long,
        val rangeStart: Long,
        val rangeLength: Long,
        val baseIv: ByteArray = ByteArray(0)
    )

    fun readPreambleVersion(input: DataInputStream): Int {
        val magic = input.readInt()
        if (magic != MAGIC) {
            throw IllegalStateException("Invalid FlashShare protocol header")
        }
        return input.readInt()
    }

    fun readHeaderV1Body(input: DataInputStream): FileHeader {
        return FileHeader(
            transferId = input.readUTF(),
            fileName = input.readUTF(),
            mimeType = input.readUTF(),
            categoryName = input.readUTF(),
            senderName = input.readUTF(),
            totalSizeBytes = input.readLong()
        )
    }

    fun writeAck(out: DataOutputStream, status: Byte, offsetOrAvailableBytes: Long) {
        out.writeByte(status.toInt())
        out.writeLong(offsetOrAvailableBytes)
        out.flush()
    }

    fun readAck(input: DataInputStream): ReceiverAck {
        return ReceiverAck(
            status = input.readByte(),
            offsetOrAvailableBytes = input.readLong()
        )
    }

    fun writeBatchHeader(out: DataOutputStream, version: Int, header: BatchHeaderV2) {
        out.writeInt(MAGIC)
        out.writeInt(version)
        out.writeByte(header.flags)
        out.writeUTF(header.batchId)
        out.writeUTF(header.senderId)
        out.writeUTF(header.senderName)
        out.writeInt(header.totalFilesInBatch)
        out.writeInt(header.streamFileCount)
        out.writeLong(header.totalBatchBytes)
        out.flush()
    }

    fun readBatchHeaderBody(input: DataInputStream): BatchHeaderV2 {
        val flags = input.readByte().toInt() and 0xFF
        val batchId = input.readUTF()
        val senderId = input.readUTF()
        val senderName = input.readUTF()
        val totalFiles = input.readInt()
        val streamFiles = input.readInt()
        val totalBytes = input.readLong()
        return BatchHeaderV2(
            flags = flags,
            batchId = batchId,
            senderId = senderId,
            senderName = senderName,
            totalFilesInBatch = totalFiles,
            streamFileCount = streamFiles,
            totalBatchBytes = totalBytes
        )
    }

    fun writeBytesFrame(out: DataOutputStream, bytes: ByteArray) {
        out.writeInt(bytes.size)
        out.write(bytes)
        out.flush()
    }

    fun readBytesFrame(input: DataInputStream): ByteArray {
        val len = input.readInt()
        if (len < 0 || len > 4096) throw IllegalStateException("Invalid handshake frame length: $len")
        return ByteArray(len).also { input.readFully(it) }
    }

    fun writeFileHeaderV2(out: DataOutputStream, header: FileHeaderV2) {
        out.writeUTF(header.transferId)
        out.writeUTF(header.fileName)
        out.writeUTF(header.mimeType)
        out.writeUTF(header.categoryName)
        out.writeLong(header.totalSizeBytes)
        out.writeLong(header.rangeStart)
        out.writeLong(header.rangeLength)
        out.writeByte(header.baseIv.size)
        if (header.baseIv.isNotEmpty()) {
            out.write(header.baseIv)
        }
        out.flush()
    }

    fun readFileHeaderV2(input: DataInputStream): FileHeaderV2 {
        val transferId = input.readUTF()
        val fileName = input.readUTF()
        val mimeType = input.readUTF()
        val categoryName = input.readUTF()
        val totalSize = input.readLong()
        val rangeStart = input.readLong()
        val rangeLength = input.readLong()
        val ivLen = input.readByte().toInt() and 0xFF
        val iv = if (ivLen > 0) ByteArray(ivLen).also { input.readFully(it) } else ByteArray(0)
        return FileHeaderV2(
            transferId = transferId,
            fileName = fileName,
            mimeType = mimeType,
            categoryName = categoryName,
            totalSizeBytes = totalSize,
            rangeStart = rangeStart,
            rangeLength = rangeLength,
            baseIv = iv
        )
    }
}
