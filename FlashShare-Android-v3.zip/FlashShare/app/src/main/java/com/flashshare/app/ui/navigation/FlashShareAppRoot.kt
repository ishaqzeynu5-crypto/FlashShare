package com.flashshare.app.ui.navigation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.flashshare.app.R
import com.flashshare.app.ui.screens.FileBrowserScreen
import com.flashshare.app.ui.screens.HistoryScreen
import com.flashshare.app.ui.screens.HomeScreen
import com.flashshare.app.ui.screens.LanguageScreen
import com.flashshare.app.ui.screens.PhoneCloneScreen
import com.flashshare.app.ui.screens.QrHubScreen
import com.flashshare.app.ui.screens.SendRadarScreen
import com.flashshare.app.ui.screens.SettingsScreen
import com.flashshare.app.ui.screens.TransferQueueScreen
import com.flashshare.app.ui.screens.WebShareScreen
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceContainerDark
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

object Routes {
    const val HOME = "home"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val LANGUAGE = "language"
    const val FILES = "files"
    const val SEND_RADAR = "send_radar"
    const val QR_HUB = "qr_hub/{tab}"
    const val TRANSFERS = "transfers"
    const val PHONE_CLONE = "phone_clone"
    const val WEB_SHARE = "web_share"

    fun qrHub(showFirst: Boolean): String = "qr_hub/${if (showFirst) "show" else "scan"}"
}

private data class BottomTab(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector
)

@Composable
fun FlashShareAppRoot(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val statusBanner by viewModel.statusBanner.collectAsState()
    val pendingRequest by viewModel.pendingIncomingRequest.collectAsState()

    LaunchedEffect(statusBanner) {
        statusBanner?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearMessage()
        }
    }

    pendingRequest?.let { req ->
        AlertDialog(
            onDismissRequest = {
                viewModel.respondToIncomingRequest(req.batchId, accept = false, trustDevice = false)
            },
            containerColor = SurfaceDark,
            title = { Text(stringResource(R.string.incoming_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.incoming_message,
                        req.senderName,
                        req.fileCount,
                        Formatters.formatBytes(req.totalBytes)
                    )
                )
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            viewModel.respondToIncomingRequest(req.batchId, accept = true, trustDevice = true)
                        }
                    ) {
                        Text(stringResource(R.string.incoming_trust_accept))
                    }
                    Button(
                        onClick = {
                            viewModel.respondToIncomingRequest(req.batchId, accept = true, trustDevice = false)
                        }
                    ) {
                        Text(stringResource(R.string.incoming_accept))
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.respondToIncomingRequest(req.batchId, accept = false, trustDevice = false)
                    }
                ) {
                    Text(stringResource(R.string.incoming_reject))
                }
            }
        )
    }

    // 3-tab Bottom Navigation: Home, History, Settings
    val tabs = listOf(
        BottomTab(Routes.HOME, R.string.nav_home, Icons.Default.Home),
        BottomTab(Routes.HISTORY, R.string.nav_history, AppIcons.History),
        BottomTab(Routes.SETTINGS, R.string.nav_settings, Icons.Default.Settings)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = currentRoute in tabs.map { it.route }

    Scaffold(
        containerColor = BgBlack,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                androidx.compose.foundation.layout.Column {
                    HorizontalDivider(color = OutlineSubtle, thickness = 1.dp)
                    NavigationBar(containerColor = SurfaceDark, tonalElevation = 0.dp) {
                        tabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TextPrimary,
                                    selectedTextColor = TextPrimary,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = SurfaceContainerDark
                                ),
                                icon = {
                                    Icon(tab.icon, contentDescription = stringResource(tab.labelRes))
                                },
                                label = { Text(stringResource(tab.labelRes)) }
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    viewModel = viewModel,
                    onSendClick = { navController.navigate(Routes.FILES) },
                    onReceiveClick = { navController.navigate(Routes.qrHub(showFirst = true)) },
                    onQrClick = { navController.navigate(Routes.qrHub(showFirst = false)) },
                    onPhoneCloneClick = { navController.navigate(Routes.PHONE_CLONE) },
                    onWebShareClick = { navController.navigate(Routes.WEB_SHARE) },
                    onHistoryClick = { navController.navigate(Routes.HISTORY) },
                    onSettingsClick = { navController.navigate(Routes.SETTINGS) },
                    onOpenTransfers = { navController.navigate(Routes.TRANSFERS) }
                )
            }
            composable(Routes.FILES) {
                FileBrowserScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenQr = { navController.navigate(Routes.qrHub(showFirst = true)) },
                    onProceedToSend = {
                        if (viewModel.sendSelectedFiles()) {
                            navController.navigate(Routes.TRANSFERS)
                        } else {
                            navController.navigate(Routes.SEND_RADAR)
                        }
                    }
                )
            }
            composable(Routes.SEND_RADAR) {
                SendRadarScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onShowQrClick = { navController.navigate(Routes.qrHub(showFirst = true)) },
                    onScanQrClick = { navController.navigate(Routes.qrHub(showFirst = false)) },
                    onOpenTransfers = {
                        navController.navigate(Routes.TRANSFERS) {
                            popUpTo(Routes.HOME)
                        }
                    }
                )
            }
            composable(
                route = Routes.QR_HUB,
                arguments = listOf(navArgument("tab") { type = NavType.StringType })
            ) { backStack ->
                val initialShow = backStack.arguments?.getString("tab") != "scan"
                QrHubScreen(
                    viewModel = viewModel,
                    initialShowTab = initialShow,
                    onBack = { navController.popBackStack() },
                    onOpenTransfers = {
                        navController.navigate(Routes.TRANSFERS) {
                            popUpTo(Routes.HOME)
                        }
                    }
                )
            }
            composable(Routes.TRANSFERS) {
                TransferQueueScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.HISTORY) {
                HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToSendRadar = { navController.navigate(Routes.SEND_RADAR) },
                    onNavigateToTransfers = { navController.navigate(Routes.TRANSFERS) }
                )
            }
            composable(Routes.PHONE_CLONE) {
                PhoneCloneScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenSendRadar = { navController.navigate(Routes.SEND_RADAR) },
                    onOpenReceiveQr = { navController.navigate(Routes.qrHub(showFirst = true)) },
                    onOpenTransfers = { navController.navigate(Routes.TRANSFERS) }
                )
            }
            composable(Routes.WEB_SHARE) {
                WebShareScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onSelectFiles = { navController.navigate(Routes.FILES) }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    viewModel = viewModel,
                    onOpenLanguage = { navController.navigate(Routes.LANGUAGE) }
                )
            }
            composable(Routes.LANGUAGE) {
                LanguageScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
