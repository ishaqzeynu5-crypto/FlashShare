package com.flashshare.app.network

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.flashshare.app.R
import com.flashshare.app.domain.model.NearbyDevice
import com.flashshare.app.domain.model.QrConnectionPayload
import com.flashshare.app.transfer.TransferProtocol
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.util.Formatters
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

sealed class WifiDirectState {
    data object Idle : WifiDirectState()
    data object Discovering : WifiDirectState()
    data class PreparingGroup(val stepMessage: String = "") : WifiDirectState()
    data class Connecting(val targetName: String) : WifiDirectState()
    data class HostingGroup(
        val ipAddress: String?,
        val ssid: String? = null,
        val passphrase: String? = null,
        val band5GhzRequested: Boolean = false
    ) : WifiDirectState()
    data class Connected(
        val peerName: String,
        val groupOwnerIp: String,
        val port: Int = TransferProtocol.DEFAULT_PORT,
        val isGroupOwner: Boolean,
        val encryptionKeyBase64: String? = null,
        val wasQrConnection: Boolean = false
    ) : WifiDirectState()
    data class Error(val message: String) : WifiDirectState()
}

@Singleton
class WifiDirectManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val PASSPHRASE_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        const val PASSPHRASE_LENGTH = 16
        const val QR_CONNECT_TIMEOUT_MS = 15_000
        private val GROUP_INFO_RETRY_DELAYS_MS = longArrayOf(200L, 400L, 800L, 1_200L)
        private val passphraseRandom = SecureRandom()

        fun generateStrongPassphrase(length: Int = PASSPHRASE_LENGTH): String {
            val sb = StringBuilder(length)
            repeat(length) {
                sb.append(PASSPHRASE_ALPHABET[passphraseRandom.nextInt(PASSPHRASE_ALPHABET.length)])
            }
            return sb.toString()
        }
    }
    private val manager: WifiP2pManager? =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private val connectivityManager: ConnectivityManager? =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var channel: WifiP2pManager.Channel? = null
    private var receiverRegistered = false
    private var isHostingReceiverGroup = false
    private var lastBand5Ghz = false

    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private var boundNetworkCallback: ConnectivityManager.NetworkCallback? = null
    private var connectTimeoutRunnable: Runnable? = null
    @Volatile
    private var activeTransferNetwork: Network? = null
    @Volatile
    private var isCreatingGroup = false

    private val _peers = MutableStateFlow<List<NearbyDevice>>(emptyList())
    val peers: StateFlow<List<NearbyDevice>> = _peers.asStateFlow()

    private val _state = MutableStateFlow<WifiDirectState>(WifiDirectState.Idle)
    val state: StateFlow<WifiDirectState> = _state.asStateFlow()

    private val _isWifiP2pEnabled = MutableStateFlow(true)
    val isWifiP2pEnabled: StateFlow<Boolean> = _isWifiP2pEnabled.asStateFlow()

    private var pendingPeerName: String = "Nearby Device"

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val stateVal = intent.getIntExtra(
                        WifiP2pManager.EXTRA_WIFI_STATE,
                        WifiP2pManager.WIFI_P2P_STATE_DISABLED
                    )
                    _isWifiP2pEnabled.value = (stateVal == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    if (hasNearbyPermission()) {
                        channel?.let { ch ->
                            manager?.requestPeers(ch) { peerList ->
                                val list = peerList.deviceList.map { device: WifiP2pDevice ->
                                    NearbyDevice(
                                        deviceName = device.deviceName.ifBlank { device.deviceAddress },
                                        deviceAddress = device.deviceAddress,
                                        isGroupOwner = device.isGroupOwner,
                                        port = TransferProtocol.DEFAULT_PORT
                                    )
                                }
                                _peers.value = list
                            }
                        }
                    }
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    if (isHostingReceiverGroup) {
                        channel?.let { publishHostingGroupInfo(it, lastBand5Ghz) }
                    } else {
                        requestConnectionInfo()
                    }
                }
            }
        }
    }

    fun initialize() {
        if (channel == null && manager != null) {
            channel = manager.initialize(context, Looper.getMainLooper(), null)
        }
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
            receiverRegistered = true
        }
    }

    fun hasNearbyPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.NEARBY_WIFI_DEVICES
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Returns the explicit Wi-Fi / P2P Network so TCP sockets bypass 4G/5G Mobile Data.
     */
    fun getPreferredTransferNetwork(): Network? {
        activeTransferNetwork?.let { return it }
        val cm = connectivityManager ?: return null
        return cm.allNetworks.firstOrNull { net ->
            val caps = cm.getNetworkCapabilities(net)
            caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        initialize()
        isHostingReceiverGroup = false
        if (!hasNearbyPermission()) {
            _state.value = WifiDirectState.Error(context.getString(R.string.error_wifi_perm_required))
            return
        }
        val ch = channel ?: return
        _state.value = WifiDirectState.Discovering
        manager?.discoverPeers(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                _state.value = WifiDirectState.Discovering
            }

            override fun onFailure(reasonCode: Int) {
                _state.value = WifiDirectState.Error(context.getString(R.string.error_discovery_unavailable, reasonCode))
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        val ch = channel ?: return
        manager?.stopPeerDiscovery(ch, null)
        if (_state.value is WifiDirectState.Discovering) {
            _state.value = WifiDirectState.Idle
        }
    }

    /**
     * Starts a Wi-Fi Direct group as receiver (Group Owner).
     * Prefers 5 GHz band via WifiP2pConfig.Builder on API 29+, falling back gracefully to default band.
     */
    fun isWifiEnabledNow(): Boolean {
        return wifiManager?.isWifiEnabled ?: _isWifiP2pEnabled.value
    }

    @SuppressLint("MissingPermission")
    fun startReceiverGroup(forceRecreate: Boolean = false, silentPrewarm: Boolean = false) {
        initialize()
        stopDiscovery()

        // Reuse already-active Wi-Fi Direct group immediately so QR appears in 0ms
        val existing = _state.value as? WifiDirectState.HostingGroup
        if (!forceRecreate && existing != null &&
            !existing.ipAddress.isNullOrBlank() &&
            !existing.ssid.isNullOrBlank() &&
            !existing.passphrase.isNullOrBlank()
        ) {
            isHostingReceiverGroup = true
            return
        }

        if (!forceRecreate && isCreatingGroup) {
            return
        }

        if (!isWifiEnabledNow()) {
            if (!silentPrewarm) {
                _state.value = WifiDirectState.Error(context.getString(R.string.error_wifi_disabled))
            }
            return
        }

        if (!PermissionHelper.isLocationServiceEnabled(context)) {
            if (!silentPrewarm) {
                _state.value = WifiDirectState.Error(context.getString(R.string.error_location_required_p2p))
            }
            return
        }

        if (!hasNearbyPermission() || manager == null || channel == null) {
            if (!silentPrewarm) {
                _state.value = WifiDirectState.Error(context.getString(R.string.error_wifi_perm_required))
            }
            return
        }
        val ch = channel ?: return

        isHostingReceiverGroup = true
        isCreatingGroup = true
        if (!silentPrewarm) {
            _state.value = WifiDirectState.PreparingGroup(context.getString(R.string.qr_preparing_group))
        }

        // Check if an OS-level group is already formed; skip removeGroup() when null!
        manager.requestGroupInfo(ch) { activeGroup ->
            if (!isHostingReceiverGroup) {
                isCreatingGroup = false
                return@requestGroupInfo
            }
            if (!forceRecreate && activeGroup != null &&
                !activeGroup.networkName.isNullOrBlank() &&
                !activeGroup.passphrase.isNullOrBlank()
            ) {
                isCreatingGroup = false
                publishHostingGroupInfoWithRetry(ch, band5GhzRequested = lastBand5Ghz, attemptIndex = 0)
            } else if (activeGroup == null) {
                // No existing group: skip removeGroup() and create immediately (zero artificial delay)
                createPreferredReceiverGroup(ch, silentPrewarm)
            } else {
                // Stale or forced-recreate group: remove first, then create on callback
                manager.removeGroup(ch, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() {
                        mainHandler.postDelayed({ createPreferredReceiverGroup(ch, silentPrewarm) }, 150L)
                    }

                    override fun onFailure(reason: Int) {
                        createPreferredReceiverGroup(ch, silentPrewarm)
                    }
                })
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun createPreferredReceiverGroup(ch: WifiP2pManager.Channel, silentPrewarm: Boolean) {
        if (!isHostingReceiverGroup) {
            isCreatingGroup = false
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val suffix = (1000 + SecureRandom().nextInt(9000)).toString()
            val config = WifiP2pConfig.Builder()
                .setNetworkName("DIRECT-FS-Flash$suffix")
                .setPassphrase(generateStrongPassphrase())
                .setGroupOperatingBand(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ)
                .build()

            manager?.createGroup(ch, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    lastBand5Ghz = true
                    isCreatingGroup = false
                    if (!silentPrewarm) {
                        _state.value = WifiDirectState.PreparingGroup(context.getString(R.string.qr_reading_group_info))
                    }
                    publishHostingGroupInfoWithRetry(ch, band5GhzRequested = true, attemptIndex = 0)
                }

                override fun onFailure(reasonCode: Int) {
                    // Fall back immediately to OS-selected band (only pause briefly on BUSY)
                    if (reasonCode == WifiP2pManager.BUSY) {
                        mainHandler.postDelayed({ createLegacyGroup(ch, retriesLeft = 1, silentPrewarm = silentPrewarm) }, 250L)
                    } else {
                        createLegacyGroup(ch, retriesLeft = 1, silentPrewarm = silentPrewarm)
                    }
                }
            })
        } else {
            createLegacyGroup(ch, retriesLeft = 1, silentPrewarm = silentPrewarm)
        }
    }

    @SuppressLint("MissingPermission")
    private fun createLegacyGroup(ch: WifiP2pManager.Channel, retriesLeft: Int = 1, silentPrewarm: Boolean = false) {
        if (!isHostingReceiverGroup) {
            isCreatingGroup = false
            return
        }
        manager?.createGroup(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                lastBand5Ghz = false
                isCreatingGroup = false
                if (!silentPrewarm) {
                    _state.value = WifiDirectState.PreparingGroup(context.getString(R.string.qr_reading_group_info))
                }
                publishHostingGroupInfoWithRetry(ch, band5GhzRequested = false, attemptIndex = 0)
            }

            override fun onFailure(reasonCode: Int) {
                if (retriesLeft > 0 && reasonCode == WifiP2pManager.BUSY) {
                    mainHandler.postDelayed({ createLegacyGroup(ch, retriesLeft - 1, silentPrewarm) }, 350L)
                    return
                }
                lastBand5Ghz = false
                isCreatingGroup = false
                if (!silentPrewarm) {
                    _state.value = WifiDirectState.Error(
                        context.getString(R.string.error_wifi_direct_group_failed, reasonCode)
                    )
                }
            }
        })
    }

    private fun publishHostingGroupInfoWithRetry(
        ch: WifiP2pManager.Channel,
        band5GhzRequested: Boolean,
        attemptIndex: Int
    ) {
        publishHostingGroupInfo(ch, band5GhzRequested)
        if (attemptIndex < GROUP_INFO_RETRY_DELAYS_MS.size) {
            mainHandler.postDelayed({
                val current = _state.value
                val ready = current is WifiDirectState.HostingGroup &&
                    !current.ipAddress.isNullOrBlank() &&
                    !current.ssid.isNullOrBlank() &&
                    !current.passphrase.isNullOrBlank()
                if (isHostingReceiverGroup && !ready) {
                    publishHostingGroupInfoWithRetry(ch, band5GhzRequested, attemptIndex + 1)
                }
            }, GROUP_INFO_RETRY_DELAYS_MS[attemptIndex])
        }
    }

    @SuppressLint("MissingPermission")
    private fun publishHostingGroupInfo(ch: WifiP2pManager.Channel, band5GhzRequested: Boolean) {
        manager?.requestGroupInfo(ch) { group ->
            val ssid = group?.networkName?.takeIf { it.isNotBlank() }
            val pass = group?.passphrase?.takeIf { it.isNotBlank() }
            if (ssid == null || pass == null) return@requestGroupInfo
            manager.requestConnectionInfo(ch) { connInfo ->
                val dynamicIp = connInfo?.groupOwnerAddress?.hostAddress
                    ?: "192.168.49.1"
                _state.value = WifiDirectState.HostingGroup(
                    ipAddress = dynamicIp,
                    ssid = ssid,
                    passphrase = pass,
                    band5GhzRequested = band5GhzRequested
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToPeer(device: NearbyDevice) {
        initialize()
        stopDiscovery()
        isHostingReceiverGroup = false
        if (!hasNearbyPermission()) {
            _state.value = WifiDirectState.Error(context.getString(R.string.error_wifi_perm_required))
            return
        }
        val ch = channel ?: return
        pendingPeerName = device.deviceName
        _state.value = WifiDirectState.Connecting(device.deviceName)
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            wps.setup = WpsInfo.PBC
            groupOwnerIntent = 0
        }
        manager?.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                requestConnectionInfo()
            }

            override fun onFailure(reason: Int) {
                _state.value = WifiDirectState.Error(context.getString(R.string.error_peer_connect_failed, device.deviceName, reason))
            }
        })
    }

    /**
     * Connects using a scanned QR payload.
     * On API 29+, if the QR includes the receiver's Wi-Fi Direct SSID + passphrase,
     * automatically joins that peer-to-peer Wi-Fi network via WifiNetworkSpecifier and binds sockets to it
     * so 4G/5G Mobile Data never hijacks the transfer.
     */
    fun connectByQrPayload(payload: QrConnectionPayload) {
        initialize()
        stopDiscovery()
        isHostingReceiverGroup = false
        val cm = connectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            cm != null &&
            !payload.ssid.isNullOrBlank() &&
            !payload.passphrase.isNullOrBlank()
        ) {
            releaseBoundNetwork()
            _state.value = WifiDirectState.Connecting(payload.deviceName)

            val specifier = WifiNetworkSpecifier.Builder()
                .setSsid(payload.ssid)
                .setWpa2Passphrase(payload.passphrase)
                .build()

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specifier)
                .build()

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cancelConnectTimeout()
                    activeTransferNetwork = network
                    runCatching { cm.bindProcessToNetwork(network) }
                    _state.value = WifiDirectState.Connected(
                        peerName = payload.deviceName,
                        groupOwnerIp = payload.ipAddress,
                        port = payload.port,
                        isGroupOwner = false,
                        encryptionKeyBase64 = payload.encryptionKeyBase64,
                        wasQrConnection = !payload.encryptionKeyBase64.isNullOrBlank()
                    )
                }

                override fun onUnavailable() {
                    cancelConnectTimeout()
                    releaseBoundNetwork()
                    _state.value = WifiDirectState.Error(
                        context.getString(R.string.error_qr_connect_timeout)
                    )
                }

                override fun onLost(network: Network) {
                    if (activeTransferNetwork == network) {
                        activeTransferNetwork = null
                        runCatching { cm.bindProcessToNetwork(null) }
                    }
                }
            }
            boundNetworkCallback = callback
            val timeoutTask = Runnable {
                if (_state.value is WifiDirectState.Connecting) {
                    releaseBoundNetwork()
                    _state.value = WifiDirectState.Error(
                        context.getString(R.string.error_qr_connect_timeout)
                    )
                }
            }
            connectTimeoutRunnable = timeoutTask
            mainHandler.postDelayed(timeoutTask, QR_CONNECT_TIMEOUT_MS.toLong() + 1_000L)

            runCatching { cm.requestNetwork(request, callback, QR_CONNECT_TIMEOUT_MS) }
                .onFailure {
                    cancelConnectTimeout()
                    releaseBoundNetwork()
                    _state.value = WifiDirectState.Error(
                        context.getString(R.string.error_qr_connect_timeout)
                    )
                }
        } else {
            connectDirectlyByIp(
                ipAddress = payload.ipAddress,
                peerName = payload.deviceName,
                port = payload.port,
                encryptionKeyBase64 = payload.encryptionKeyBase64
            )
        }
    }

    /**
     * Directly connects over local Wi-Fi or Hotspot using IP, port, and optional QR AES key.
     */
    fun connectDirectlyByIp(
        ipAddress: String,
        peerName: String,
        port: Int = TransferProtocol.DEFAULT_PORT,
        encryptionKeyBase64: String? = null
    ) {
        stopDiscovery()
        _state.value = WifiDirectState.Connected(
            peerName = peerName,
            groupOwnerIp = ipAddress,
            port = port,
            isGroupOwner = false,
            encryptionKeyBase64 = encryptionKeyBase64,
            wasQrConnection = !encryptionKeyBase64.isNullOrBlank()
        )
    }

    /**
     * Clears the one-time QR PSK after the batch finishes or after receiver rotation so the
     * sender never silently reuses a stale key.
     */
    fun clearConnectionEncryptionKey() {
        val cur = _state.value
        if (cur is WifiDirectState.Connected && cur.encryptionKeyBase64 != null) {
            _state.value = cur.copy(encryptionKeyBase64 = null)
        }
    }

    @SuppressLint("MissingPermission")
    fun requestConnectionInfo() {
        val ch = channel ?: return
        manager?.requestConnectionInfo(ch) { info ->
            if (info != null && info.groupFormed) {
                stopDiscovery()
                val ownerIp = info.groupOwnerAddress?.hostAddress
                    ?: Formatters.getLocalIpAddress()
                if (!ownerIp.isNullOrBlank()) {
                    _state.value = WifiDirectState.Connected(
                        peerName = pendingPeerName,
                        groupOwnerIp = ownerIp,
                        port = TransferProtocol.DEFAULT_PORT,
                        isGroupOwner = info.isGroupOwner
                    )
                }
            }
        }
    }

    fun cancelConnect() {
        cancelConnectTimeout()
        if (_state.value is WifiDirectState.Connecting) {
            releaseBoundNetwork()
            _state.value = WifiDirectState.Idle
        }
    }

    private fun cancelConnectTimeout() {
        connectTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        connectTimeoutRunnable = null
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        isHostingReceiverGroup = false
        isCreatingGroup = false
        cancelConnectTimeout()
        releaseBoundNetwork()
        val ch = channel
        if (ch != null) {
            manager?.removeGroup(ch, null)
            manager?.stopPeerDiscovery(ch, null)
        }
        _peers.value = emptyList()
        _state.value = WifiDirectState.Idle
    }

    private fun releaseBoundNetwork() {
        val cm = connectivityManager
        boundNetworkCallback?.let { cb ->
            runCatching { cm?.unregisterNetworkCallback(cb) }
        }
        boundNetworkCallback = null
        activeTransferNetwork = null
        runCatching { cm?.bindProcessToNetwork(null) }
    }

    fun release() {
        releaseBoundNetwork()
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
    }
}
