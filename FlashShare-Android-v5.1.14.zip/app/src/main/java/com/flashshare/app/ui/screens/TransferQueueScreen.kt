package com.flashshare.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferItem
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineStrong
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceContainerDark
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferQueueScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onSendMoreFiles: () -> Unit
) {
    val transfers by viewModel.transfers.collectAsStateWithLifecycle()

    val totalBytes = remember(transfers) { transfers.sumOf { it.sizeBytes }.coerceAtLeast(1L) }
    val doneBytes = remember(transfers, totalBytes) { transfers.sumOf { it.transferredBytes }.coerceAtMost(totalBytes) }
    val overallFraction = (doneBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
    val overallPercent = (overallFraction * 100f).toInt().coerceIn(0, 100)

    val combinedSpeed = remember(transfers) {
        transfers.filter { it.status == TransferStatus.RUNNING }.sumOf { it.speedBytesPerSec }
    }
    val remainingBytes = (totalBytes - doneBytes).coerceAtLeast(0L)
    val overallEta = if (combinedSpeed > 0L) remainingBytes / combinedSpeed else -1L

    val hasActive = remember(transfers) {
        transfers.any { it.status == TransferStatus.RUNNING || it.status == TransferStatus.QUEUED || it.status == TransferStatus.VERIFYING }
    }
    val hasPaused = remember(transfers) { transfers.any { it.status == TransferStatus.PAUSED } }

    Scaffold(
        containerColor = BgBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
                title = { Text(stringResource(R.string.transfers_title), color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    if (transfers.any {
                            it.status == TransferStatus.COMPLETED ||
                                it.status == TransferStatus.FAILED ||
                                it.status == TransferStatus.CANCELLED
                        }
                    ) {
                        TextButton(
                            onClick = { viewModel.clearFinishedTransfers() },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.transfer_clear_done), color = TextPrimary)
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (transfers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.transfers_empty),
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // Big Circular Progress + Speed + Time Left + Pause / Cancel buttons
                item(key = "overall_header") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        border = BorderStroke(1.dp, OutlineSubtle),
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier.size(148.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    progress = { overallFraction },
                                    color = TextPrimary,
                                    trackColor = SurfaceContainerDark,
                                    strokeWidth = 10.dp,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = stringResource(R.string.transfer_overall_progress, overallPercent),
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = stringResource(R.string.transfer_speed_value, Formatters.formatBytes(combinedSpeed)),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Text(
                                text = stringResource(R.string.transfer_eta_value, Formatters.formatDuration(overallEta)),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )

                            Surface(
                                color = SurfaceContainerDark,
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, OutlineSubtle)
                            ) {
                                Text(
                                    text = stringResource(R.string.transfer_encrypted_badge),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = onSendMoreFiles,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TextPrimary,
                                    contentColor = BgBlack
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 50.dp)
                            ) {
                                Icon(AppIcons.Upload, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.transfer_send_more),
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (hasActive || hasPaused) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            if (hasActive) viewModel.pauseAllActive()
                                            else viewModel.resumeAllPaused()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = TextPrimary,
                                            contentColor = BgBlack
                                        ),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 48.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (hasActive) AppIcons.Pause else Icons.Default.PlayArrow,
                                            contentDescription = null
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (hasActive) {
                                                stringResource(R.string.transfer_pause)
                                            } else {
                                                stringResource(R.string.transfer_resume)
                                            },
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.cancelAllActive() },
                                        border = BorderStroke(1.dp, OutlineStrong),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 48.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = null, tint = TextPrimary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(stringResource(R.string.transfer_cancel), color = TextPrimary)
                                    }
                                }
                            }
                        }
                    }
                }

                // Per-file rows (Done / % / Queued)
                items(transfers, key = { it.id }) { item ->
                    TransferFileRow(
                        item = item,
                        onPause = { viewModel.pauseTransfer(item.id) },
                        onResume = { viewModel.resumeTransfer(item.id) },
                        onCancel = { viewModel.cancelTransfer(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TransferFileRow(
    item: TransferItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit
) {
    val badgeText = when (item.status) {
        TransferStatus.QUEUED -> stringResource(R.string.transfer_status_queued)
        TransferStatus.RUNNING -> stringResource(R.string.transfer_status_running, item.progressPercent)
        TransferStatus.VERIFYING -> stringResource(R.string.transfer_status_verifying)
        TransferStatus.PAUSED -> stringResource(R.string.transfer_status_paused)
        TransferStatus.COMPLETED -> stringResource(R.string.transfer_status_completed)
        TransferStatus.FAILED -> stringResource(R.string.transfer_status_failed)
        TransferStatus.CANCELLED -> stringResource(R.string.transfer_status_cancelled)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, OutlineSubtle),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (item.direction == TransferDirection.SEND) AppIcons.Upload else AppIcons.Download,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = Formatters.formatBytes(item.sizeBytes),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (item.status == TransferStatus.COMPLETED || item.status == TransferStatus.RUNNING || item.status == TransferStatus.VERIFYING) {
                        TextPrimary
                    } else {
                        TextSecondary
                    }
                )

                if (item.status == TransferStatus.RUNNING || item.status == TransferStatus.QUEUED) {
                    IconButton(onClick = onPause, modifier = Modifier.size(48.dp)) {
                        Icon(AppIcons.Pause, contentDescription = stringResource(R.string.transfer_pause), tint = TextPrimary)
                    }
                } else if (item.status == TransferStatus.PAUSED) {
                    IconButton(onClick = onResume, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Default.PlayArrow, contentDescription = stringResource(R.string.transfer_resume), tint = TextPrimary)
                    }
                }
                if (item.status == TransferStatus.RUNNING || item.status == TransferStatus.QUEUED || item.status == TransferStatus.PAUSED) {
                    IconButton(onClick = onCancel, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.transfer_cancel), tint = TextSecondary)
                    }
                }
            }

            if (!item.errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}
