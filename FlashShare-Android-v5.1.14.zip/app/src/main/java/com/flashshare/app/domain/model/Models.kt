package com.flashshare.app.domain.model

import android.net.Uri
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.UUID

enum class FileCategory(val folderName: String) {
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    MUSIC("Music"),
    APPS("Apps"),
    DOCUMENTS("Documents"),
    DOWNLOADS("Downloads"),
    CONTACTS("Contacts"),
    OTHER("Other")
}

data class ShareableFile(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val category: FileCategory,
    val uri: Uri,
    val filePath: String? = null,
    val packageName: String? = null,
    val isSplitApk: Boolean = false,
    val lastModified: Long = 0L,
    val durationMs: Long = 0L,
    val isCachedTempFile: Boolean = false
)

enum class TransferDirection {
    SEND,
    RECEIVE
}

enum class TransferStatus {
    QUEUED,
    RUNNING,
    VERIFYING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class TransferItem(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val sizeBytes: Long,
    val transferredBytes: Long = 0L,
    val mimeType: String,
    val category: FileCategory,
    val direction: TransferDirection,
    val status: TransferStatus = TransferStatus.QUEUED,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val sourceUri: Uri? = null,
    val localPath: String? = null,
    val peerName: String = "",
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    val progressFraction: Float
        get() = if (sizeBytes <= 0L) 0f else (transferredBytes.toDouble() / sizeBytes.toDouble())
            .coerceIn(0.0, 1.0)
            .toFloat()

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}

data class IncomingTransferRequest(
    val batchId: String,
    val senderFingerprint: String,
    val senderName: String,
    val fileCount: Int,
    val totalBytes: Long,
    val verificationCode: String? = null,
    val isPullRequest: Boolean = false
)

/**
 * Shown on the sender phone when connecting without a verified QR PSK and to an unpinned
 * receiver (or when a previously pinned receiver's fingerprint has changed).
 */
data class PendingSasVerification(
    val batchId: String,
    val peerFingerprint: String,
    val peerName: String,
    val sasCode: String,
    val fingerprintChangedWarning: Boolean = false
)

data class NearbyDevice(
    val deviceName: String,
    val deviceAddress: String,
    val isGroupOwner: Boolean = false,
    val ipAddress: String? = null,
    val port: Int = 8988
)

enum class QrRole {
    SEND,
    RECEIVE
}

sealed class QrHostUiState {
    data object Idle : QrHostUiState()
    data class Preparing(val message: String) : QrHostUiState()
    data class Ready(
        val payload: String,
        val ipAddress: String,
        val port: Int,
        val ssid: String?,
        val band5Ghz: Boolean,
        val isLanFallback: Boolean = false
    ) : QrHostUiState()
    data class Error(
        val message: String,
        val needsWifiEnabled: Boolean = false,
        val needsLocationServices: Boolean = false
    ) : QrHostUiState()
}

data class QrConnectionPayload(
    val role: QrRole = QrRole.RECEIVE,
    val deviceId: String = "",
    val deviceName: String,
    val ipAddress: String,
    val port: Int = 8988,
    val ssid: String? = null,
    val passphrase: String? = null,
    val encryptionKeyBase64: String? = null
) {
    fun encode(): String {
        val parts = listOf(
            "FLASHSHARE",
            "v5",
            role.name,
            urlEncode(deviceId),
            urlEncode(deviceName),
            urlEncode(ipAddress),
            port.toString(),
            urlEncode(ssid.orEmpty()),
            urlEncode(passphrase.orEmpty()),
            urlEncode(encryptionKeyBase64.orEmpty())
        )
        return parts.joinToString("|")
    }

    companion object {
        private fun urlEncode(value: String): String =
            URLEncoder.encode(value, "UTF-8").replace("+", "%20")

        private fun urlDecode(value: String): String =
            runCatching { URLDecoder.decode(value, "UTF-8") }.getOrDefault(value)

        fun decode(raw: String): QrConnectionPayload? {
            val parts = raw.trim().split("|")
            if (parts.size < 7 || parts[0] != "FLASHSHARE") return null
            if (parts[1] != "v5") return null
            val role = runCatching { QrRole.valueOf(parts[2]) }.getOrDefault(QrRole.RECEIVE)
            val deviceId = urlDecode(parts[3])
            val name = urlDecode(parts[4]).ifBlank { "FlashShare Device" }
            val ip = urlDecode(parts[5])
            val port = parts[6].toIntOrNull() ?: return null
            if (ip.isBlank() || port !in 1024..65535) return null
            val ssid = parts.getOrNull(7)?.let { urlDecode(it) }?.ifBlank { null }
            val pass = parts.getOrNull(8)?.let { urlDecode(it) }?.ifBlank { null }
            val key = parts.getOrNull(9)?.let { urlDecode(it) }?.ifBlank { null }
            return QrConnectionPayload(
                role = role,
                deviceId = deviceId,
                deviceName = name,
                ipAddress = ip,
                port = port,
                ssid = ssid,
                passphrase = pass,
                encryptionKeyBase64 = key
            )
        }
    }
}

enum class AppLanguage(val tag: String) {
    ENGLISH("en"),
    OROMO("om"),
    AMHARIC("am")
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class PhoneCloneSelection(
    val includeContacts: Boolean = true,
    val includePhotos: Boolean = true,
    val includeVideos: Boolean = true,
    val includeMusic: Boolean = true
)

data class PhoneCloneSummary(
    val contactCount: Int = 0,
    val photoCount: Int = 0,
    val photoBytes: Long = 0L,
    val videoCount: Int = 0,
    val videoBytes: Long = 0L,
    val musicCount: Int = 0,
    val musicBytes: Long = 0L
)
