package com.flashshare.app.qr

import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * CameraX + offline ZXing QR scanner.
 * @param resetKey Incrementing this key unlocks scanning again (e.g. after a connection failure).
 * @param onQrScanned Return true if the QR was accepted (keep scanner locked while connecting),
 *                    or false if invalid (automatically unlocks after a short cooldown).
 */
@Composable
fun QrScannerView(
    modifier: Modifier = Modifier,
    resetKey: Int = 0,
    onQrScanned: (String) -> Boolean
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnQrScanned by rememberUpdatedState(onQrScanned)
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val hasDecoded = remember { AtomicBoolean(false) }
    val isDisposed = remember { AtomicBoolean(false) }
    val cameraProviderRef = remember { AtomicReference<ProcessCameraProvider?>(null) }
    val imageAnalysisRef = remember { AtomicReference<ImageAnalysis?>(null) }

    LaunchedEffect(resetKey) {
        if (resetKey > 0) {
            hasDecoded.set(false)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            isDisposed.set(true)
            runCatching { imageAnalysisRef.getAndSet(null)?.clearAnalyzer() }
            runCatching { cameraProviderRef.getAndSet(null)?.unbindAll() }
            runCatching { cameraExecutor.shutdownNow() }
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    if (isDisposed.get()) return@addListener
                    val cameraProvider = runCatching { cameraProviderFuture.get() }.getOrNull()
                        ?: return@addListener
                    if (isDisposed.get()) return@addListener

                    cameraProviderRef.set(cameraProvider)
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also { imageAnalysis ->
                            imageAnalysis.setAnalyzer(cameraExecutor, ZxingQrAnalyzer { code ->
                                if (!isDisposed.get() && hasDecoded.compareAndSet(false, true)) {
                                    previewView.post {
                                        if (isDisposed.get()) return@post
                                        val accepted = currentOnQrScanned(code)
                                        if (!accepted) {
                                            previewView.postDelayed({
                                                if (!isDisposed.get()) {
                                                    hasDecoded.set(false)
                                                }
                                            }, 1_200L)
                                        }
                                    }
                                }
                            })
                        }
                    imageAnalysisRef.set(analysis)

                    runCatching {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            analysis
                        )
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            }
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            val boxSize = minOf(size.width, size.height) * 0.65f
            val left = (size.width - boxSize) / 2f
            val top = (size.height - boxSize) / 2f
            drawRoundRect(
                color = Color(0xFFF2F3F5),
                topLeft = Offset(left, top),
                size = Size(boxSize, boxSize),
                cornerRadius = CornerRadius(24.dp.toPx(), 24.dp.toPx()),
                style = Stroke(width = 3.dp.toPx())
            )
        }
    }
}

private class ZxingQrAnalyzer(
    private val onResult: (String) -> Unit
) : ImageAnalysis.Analyzer {

    private val reader = MultiFormatReader().apply {
        setHints(
            mapOf(
                DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                DecodeHintType.TRY_HARDER to true
            )
        )
    }

    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val data = ByteArray(buffer.remaining())
            buffer.get(data)

            val width = image.width
            val height = image.height
            val source = PlanarYUVLuminanceSource(
                data,
                plane.rowStride,
                height,
                0,
                0,
                width,
                height,
                false
            )
            val bitmap = BinaryBitmap(HybridBinarizer(source))
            val result = reader.decodeWithState(bitmap)
            if (!result.text.isNullOrBlank()) {
                onResult(result.text)
            }
        } catch (_: Exception) {
            // Frame had no QR code
        } finally {
            reader.reset()
            image.close()
        }
    }
}
