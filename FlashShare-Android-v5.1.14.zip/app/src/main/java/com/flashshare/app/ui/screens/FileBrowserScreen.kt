package com.flashshare.app.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.flashshare.app.BuildConfig
import com.flashshare.app.R
import com.flashshare.app.domain.model.FileCategory
import com.flashshare.app.domain.model.ShareableFile
import com.flashshare.app.ui.permissions.PermissionHelper
import com.flashshare.app.ui.permissions.PermissionRationaleDialog
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineStrong
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceContainerDark
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val FileCategoryChips = buildList {
    add(FileCategory.PHOTOS to R.string.tab_photos)
    add(FileCategory.VIDEOS to R.string.tab_videos)
    add(FileCategory.MUSIC to R.string.tab_music)
    if (BuildConfig.ENABLE_APPS_TAB) {
        add(FileCategory.APPS to R.string.tab_apps)
    }
    add(FileCategory.DOCUMENTS to R.string.tab_documents)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenQr: () -> Unit,
    onProceedToSend: () -> Unit
) {
    val context = LocalContext.current
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val categoryFiles by viewModel.categoryFiles.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoadingCategory.collectAsStateWithLifecycle()
    val selectedFiles by viewModel.selectedFiles.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    var showMediaPermDialog by remember { mutableStateOf(false) }
    var isPartialVisualAccess by remember { mutableStateOf(PermissionHelper.isPartialVisualMediaAccess(context)) }

    val mediaPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        isPartialVisualAccess = PermissionHelper.isPartialVisualMediaAccess(context)
        viewModel.loadCategoryFiles(selectedCategory, forceRefresh = true)
    }

    // SAF picker for Android 13-16 non-media files (PDFs, Office docs, archives, downloads)
    val safPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.addSafDocuments(context, uris)
        }
    }

    LaunchedEffect(selectedCategory) {
        val needsMediaPerm = selectedCategory == FileCategory.PHOTOS ||
            selectedCategory == FileCategory.VIDEOS ||
            selectedCategory == FileCategory.MUSIC
        if (needsMediaPerm && !PermissionHelper.hasVisualMediaAccess(context)) {
            showMediaPermDialog = true
        } else {
            isPartialVisualAccess = PermissionHelper.isPartialVisualMediaAccess(context)
            viewModel.loadCategoryFiles(selectedCategory)
        }
    }

    if (showMediaPermDialog) {
        PermissionRationaleDialog(
            title = stringResource(R.string.perm_media_title),
            description = stringResource(R.string.perm_media_desc),
            onGrantClick = {
                showMediaPermDialog = false
                mediaPermLauncher.launch(PermissionHelper.mediaPermissions())
            },
            onOpenSettingsClick = {
                showMediaPermDialog = false
                PermissionHelper.openAppSettings(context)
            },
            onDismiss = {
                showMediaPermDialog = false
                viewModel.loadCategoryFiles(selectedCategory)
            }
        )
    }

    val rawList = categoryFiles[selectedCategory].orEmpty()
    val displayedList = remember(rawList, searchQuery) {
        if (searchQuery.isBlank()) rawList
        else rawList.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }
    val allDisplayedSelected = remember(displayedList, selectedFiles) {
        displayedList.isNotEmpty() && displayedList.all { selectedFiles.containsKey(it.id) }
    }

    Scaffold(
        containerColor = BgBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
                title = { Text(stringResource(R.string.files_title), color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    if (displayedList.isNotEmpty()) {
                        TextButton(
                            onClick = { viewModel.selectAllFiles(displayedList) },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(
                                text = if (allDisplayedSelected) {
                                    stringResource(R.string.action_deselect_all)
                                } else {
                                    stringResource(R.string.action_select_all)
                                },
                                color = TextPrimary
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Search field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text(stringResource(R.string.files_search_hint), color = TextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )

                // Category chips: Photos, Videos, Music, Apps, Docs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FileCategoryChips.forEach { (category, labelRes) ->
                        val active = category == selectedCategory
                        FilterChip(
                            selected = active,
                            onClick = { viewModel.selectCategory(category) },
                            label = { Text(stringResource(labelRes)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TextPrimary,
                                selectedLabelColor = BgBlack,
                                containerColor = SurfaceDark,
                                labelColor = TextPrimary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = active,
                                borderColor = OutlineSubtle,
                                selectedBorderColor = TextPrimary
                            ),
                            modifier = Modifier.heightIn(min = 40.dp)
                        )
                    }
                }

                // Android 14+ partial visual media banner
                if (isPartialVisualAccess &&
                    (selectedCategory == FileCategory.PHOTOS || selectedCategory == FileCategory.VIDEOS)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        border = BorderStroke(1.dp, OutlineSubtle),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.files_partial_media_hint),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(
                                onClick = { mediaPermLauncher.launch(PermissionHelper.mediaPermissions()) },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(stringResource(R.string.action_grant), color = TextPrimary)
                            }
                        }
                    }
                }

                // SAF Document Picker banner for Docs on Android 13-16
                if (selectedCategory == FileCategory.DOCUMENTS) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { safPickerLauncher.launch(arrayOf("*/*")) },
                            border = BorderStroke(1.dp, OutlineStrong),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                        ) {
                            Icon(AppIcons.Folder, contentDescription = null, tint = TextPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.action_browse_device), color = TextPrimary)
                        }
                    }
                }

                // 3-column thumbnail grid
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        isLoading && displayedList.isEmpty() -> {
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = TextPrimary)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(stringResource(R.string.files_loading), color = TextSecondary)
                            }
                        }
                        displayedList.isEmpty() -> {
                            Column(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = stringResource(R.string.files_empty_category),
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                if (selectedCategory == FileCategory.DOCUMENTS) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = stringResource(R.string.files_docs_saf_hint),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                        else -> {
                            val bottomPad = if (selectedFiles.isNotEmpty()) 96.dp else 12.dp
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(3),
                                contentPadding = PaddingValues(
                                    start = 12.dp,
                                    end = 12.dp,
                                    top = 8.dp,
                                    bottom = bottomPad
                                ),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(displayedList, key = { it.id }) { file ->
                                    val isSelected = selectedFiles.containsKey(file.id)
                                    GridFileTile(
                                        file = file,
                                        isSelected = isSelected,
                                        onToggle = { viewModel.toggleFileSelection(file) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Floating bottom bar: "N files selected" + size, QR icon button, and "Send (N)"
            if (selectedFiles.isNotEmpty()) {
                val totalBytes = remember(selectedFiles) { selectedFiles.values.sumOf { it.sizeBytes } }
                Surface(
                    color = SurfaceDark,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, OutlineStrong),
                    shadowElevation = 10.dp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.files_selected_count, selectedFiles.size),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = Formatters.formatBytes(totalBytes),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        // QR icon button directly from Select Files
                        IconButton(
                            onClick = onOpenQr,
                            modifier = Modifier
                                .size(48.dp)
                                .background(SurfaceContainerDark, RoundedCornerShape(14.dp))
                                .border(1.dp, OutlineSubtle, RoundedCornerShape(14.dp))
                        ) {
                            Icon(
                                imageVector = AppIcons.QrCodeScanner,
                                contentDescription = stringResource(R.string.action_show_qr),
                                tint = TextPrimary
                            )
                        }

                        Button(
                            onClick = onProceedToSend,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TextPrimary,
                                contentColor = BgBlack
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.files_send_selected, selectedFiles.size),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridFileTile(
    file: ShareableFile,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    val context = LocalContext.current
    val isMedia = file.category == FileCategory.PHOTOS || file.category == FileCategory.VIDEOS
    val borderColor = if (isSelected) TextPrimary else OutlineSubtle

    val appIconBitmap by produceState<Bitmap?>(
        initialValue = AppIconCache.get(file.packageName),
        key1 = file.packageName
    ) {
        val pkg = file.packageName ?: return@produceState
        AppIconCache.get(pkg)?.let {
            value = it
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            runCatching {
                val drawable = context.packageManager.getApplicationIcon(pkg)
                val bmp = if (drawable is BitmapDrawable && drawable.bitmap != null) {
                    drawable.bitmap
                } else {
                    val width = drawable.intrinsicWidth.coerceIn(48, 128)
                    val height = drawable.intrinsicHeight.coerceIn(48, 128)
                    Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { created ->
                        val canvas = Canvas(created)
                        drawable.setBounds(0, 0, canvas.width, canvas.height)
                        drawable.draw(canvas)
                    }
                }
                AppIconCache.put(pkg, bmp)
                bmp
            }.getOrNull()
        }
    }

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark)
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onToggle)
    ) {
        if (isMedia) {
            AsyncImage(
                model = file.uri,
                contentDescription = file.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (file.category == FileCategory.VIDEOS) {
                Icon(
                    imageVector = AppIcons.PlayCircle,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(32.dp)
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .background(BgBlack.copy(alpha = 0.78f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = Formatters.formatBytes(file.sizeBytes),
                        color = TextPrimary,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(2.dp))
                val iconBmp = appIconBitmap
                if (iconBmp != null) {
                    Image(
                        bitmap = iconBmp.asImageBitmap(),
                        contentDescription = file.name,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                } else {
                    val icon = when (file.category) {
                        FileCategory.MUSIC -> AppIcons.MusicNote
                        FileCategory.APPS -> AppIcons.PhoneAndroid
                        else -> AppIcons.Description
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = file.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = Formatters.formatBytes(file.sizeBytes),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        // Check badge
        if (isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(22.dp)
                    .background(BgBlack, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

private object AppIconCache {
    private const val MAX_ENTRIES = 64
    private val lock = Any()
    private val map = object : LinkedHashMap<String, Bitmap>(MAX_ENTRIES + 1, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean = size > MAX_ENTRIES
    }

    fun get(packageName: String?): Bitmap? {
        if (packageName.isNullOrBlank()) return null
        return synchronized(lock) { map[packageName]?.takeUnless { it.isRecycled } }
    }

    fun put(packageName: String, bitmap: Bitmap) {
        synchronized(lock) { map[packageName] = bitmap }
    }
}
