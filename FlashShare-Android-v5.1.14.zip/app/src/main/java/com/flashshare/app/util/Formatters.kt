package com.flashshare.app.util

import com.flashshare.app.domain.model.FileCategory
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {

    fun formatBytes(bytes: Long): String {
        if (bytes < 0L) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        val tb = gb * 1024.0
        return when {
            bytes >= tb -> String.format(Locale.US, "%.2f TB", bytes / tb)
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.1f KB", bytes / kb)
            else -> "$bytes B"
        }
    }

    fun formatDuration(seconds: Long): String {
        if (seconds < 0L) return "--"
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return when {
            hrs > 0 -> String.format(Locale.US, "%dh %02dm", hrs, mins)
            mins > 0 -> String.format(Locale.US, "%dm %02ds", mins, secs)
            else -> String.format(Locale.US, "%ds", secs)
        }
    }

    fun formatTimestamp(timestampMs: Long): String {
        val sdf = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        return sdf.format(Date(timestampMs))
    }

    fun inferCategory(fileName: String, mimeType: String): FileCategory {
        val lower = fileName.lowercase(Locale.US)
        val mime = mimeType.lowercase(Locale.US)
        return when {
            lower.endsWith(".apk") || lower.endsWith(".apks") || mime == "application/vnd.android.package-archive" ->
                FileCategory.APPS
            lower.endsWith(".vcf") || mime.contains("vcard") ->
                FileCategory.CONTACTS
            mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
                lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".gif") ||
                lower.endsWith(".heic") ->
                FileCategory.PHOTOS
            mime.startsWith("video/") || lower.endsWith(".mp4") || lower.endsWith(".mkv") ||
                lower.endsWith(".mov") || lower.endsWith(".avi") || lower.endsWith(".webm") ||
                lower.endsWith(".3gp") ->
                FileCategory.VIDEOS
            mime.startsWith("audio/") || lower.endsWith(".mp3") || lower.endsWith(".wav") ||
                lower.endsWith(".m4a") || lower.endsWith(".flac") || lower.endsWith(".ogg") ||
                lower.endsWith(".aac") ->
                FileCategory.MUSIC
            mime.startsWith("text/") || mime == "application/pdf" ||
                lower.endsWith(".pdf") || lower.endsWith(".doc") || lower.endsWith(".docx") ||
                lower.endsWith(".xls") || lower.endsWith(".xlsx") || lower.endsWith(".ppt") ||
                lower.endsWith(".pptx") || lower.endsWith(".txt") || lower.endsWith(".csv") ||
                lower.endsWith(".epub") || lower.endsWith(".zip") || lower.endsWith(".rar") ->
                FileCategory.DOCUMENTS
            else -> FileCategory.OTHER
        }
    }

    fun inferMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.US)
        return when (ext) {
            "apk" -> "application/vnd.android.package-archive"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "m4a" -> "audio/mp4"
            "flac" -> "audio/flac"
            "ogg" -> "audio/ogg"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain"
            "csv" -> "text/csv"
            "vcf" -> "text/vcard"
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xls" -> "application/vnd.ms-excel"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "ppt" -> "application/vnd.ms-powerpoint"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            "zip" -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    /**
     * Pure helper for unit testing: selects the highest-priority site-local IPv4 address from
     * Wi-Fi / Wi-Fi Direct / Hotspot interfaces only (rejects cellular rmnet*, tun*, link-local, etc.).
     */
    fun selectBestLocalIp(interfaceIpPairs: List<Pair<String, String>>): String? {
        val ranked = mutableListOf<Pair<Int, String>>()
        for ((rawName, ip) in interfaceIpPairs) {
            val name = rawName.lowercase(Locale.US)
            val priority = when {
                name.startsWith("p2p") -> 1
                name.startsWith("wlan") -> 2
                name.startsWith("ap") || name.startsWith("swlan") -> 3
                else -> continue
            }
            if (isSiteLocalIpv4(ip)) {
                ranked.add(priority to ip)
            }
        }
        return ranked.minByOrNull { it.first }?.second
    }

    internal fun isSiteLocalIpv4(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        val a = parts[0].toIntOrNull() ?: return false
        val b = parts[1].toIntOrNull() ?: return false
        val c = parts[2].toIntOrNull() ?: return false
        val d = parts[3].toIntOrNull() ?: return false
        if (a !in 0..255 || b !in 0..255 || c !in 0..255 || d !in 0..255) return false
        return a == 10 || (a == 172 && b in 16..31) || (a == 192 && b == 168)
    }

    /**
     * Finds the device's active local IPv4 address strictly on Wi-Fi / Wi-Fi Direct / Hotspot
     * (p2p*, wlan*, ap*, swlan*) site-local interfaces. Never picks cellular (rmnet*) or VPN interfaces.
     */
    fun getLocalIpAddress(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            val pairs = mutableListOf<Pair<String, String>>()
            for (ni in interfaces) {
                if (!ni.isUp || ni.isLoopback) continue
                for (addr in ni.inetAddresses.toList()) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        addr.hostAddress?.let { pairs.add(ni.name to it) }
                    }
                }
            }
            selectBestLocalIp(pairs)
        } catch (_: Exception) {
            null
        }
    }
}
