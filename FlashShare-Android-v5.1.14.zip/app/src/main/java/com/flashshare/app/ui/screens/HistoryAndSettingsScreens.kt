package com.flashshare.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flashshare.app.R
import com.flashshare.app.data.local.TransferHistoryEntity
import com.flashshare.app.domain.model.AppLanguage
import com.flashshare.app.domain.model.TransferDirection
import com.flashshare.app.domain.model.TransferStatus
import com.flashshare.app.ui.theme.AppIcons
import com.flashshare.app.ui.theme.BgBlack
import com.flashshare.app.ui.theme.OutlineStrong
import com.flashshare.app.ui.theme.OutlineSubtle
import com.flashshare.app.ui.theme.SurfaceDark
import com.flashshare.app.ui.theme.TextPrimary
import com.flashshare.app.ui.theme.TextSecondary
import com.flashshare.app.ui.viewmodel.MainViewModel
import com.flashshare.app.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: MainViewModel,
    onNavigateToSendRadar: () -> Unit,
    onNavigateToTransfers: () -> Unit
) {
    val context = LocalContext.current
    val history by viewModel.history.collectAsStateWithLifecycle()
    val missingMsg = stringResource(R.string.history_file_missing)

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
            title = { Text(stringResource(R.string.history_title), color = TextPrimary) },
            actions = {
                if (history.isNotEmpty()) {
                    TextButton(
                        onClick = { viewModel.clearAllHistory() },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.history_clear_all), color = TextPrimary)
                    }
                }
            }
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = BorderStroke(1.dp, OutlineSubtle),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(
                text = stringResource(R.string.history_saved_folder, viewModel.storageOrganizer.getDisplayStoragePath()),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.padding(14.dp)
            )
        }

        if (history.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.history_empty),
                    color = TextSecondary
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(history, key = { it.id }) { entry ->
                    HistoryEntryCard(
                        entry = entry,
                        onOpen = {
                            val loc = entry.localPath
                            if (loc.isNullOrBlank()) {
                                viewModel.showMessage(missingMsg)
                            } else if (viewModel.storageOrganizer.isApksBundle(loc, entry.fileName)) {
                                viewModel.installApksBundle(loc)
                            } else {
                                val intent = viewModel.storageOrganizer.buildOpenFileIntent(loc, entry.mimeType)
                                if (intent != null) {
                                    runCatching { context.startActivity(intent) }
                                        .onFailure { viewModel.showMessage(missingMsg) }
                                } else {
                                    viewModel.showMessage(missingMsg)
                                }
                            }
                        },
                        onResend = {
                            if (viewModel.resendHistoryItem(entry)) onNavigateToTransfers() else onNavigateToSendRadar()
                        },
                        onDelete = { viewModel.deleteHistoryItem(entry.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryEntryCard(
    entry: TransferHistoryEntity,
    onOpen: () -> Unit,
    onResend: () -> Unit,
    onDelete: () -> Unit
) {
    val isSend = entry.directionEnum() == TransferDirection.SEND
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, OutlineSubtle),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isSend) AppIcons.Upload else AppIcons.Download,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = entry.fileName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${Formatters.formatBytes(entry.sizeBytes)} · ${
                            when (entry.statusEnum()) {
                                TransferStatus.COMPLETED -> stringResource(R.string.transfer_status_completed)
                                TransferStatus.FAILED -> stringResource(R.string.transfer_status_failed)
                                TransferStatus.CANCELLED -> stringResource(R.string.transfer_status_cancelled)
                                TransferStatus.PAUSED -> stringResource(R.string.transfer_status_paused)
                                TransferStatus.QUEUED -> stringResource(R.string.transfer_status_queued)
                                TransferStatus.VERIFYING -> stringResource(R.string.transfer_status_verifying)
                                TransferStatus.RUNNING -> stringResource(R.string.transfer_status_running, 0)
                            }
                        } · ${Formatters.formatTimestamp(entry.timestamp)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onOpen, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(AppIcons.Folder, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.history_open), color = TextPrimary)
                }
                TextButton(onClick = onResend, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(AppIcons.Replay, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.history_resend), color = TextPrimary)
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.history_delete),
                        tint = TextSecondary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onOpenLanguage: () -> Unit
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val trustedDevices by viewModel.trustedDevices.collectAsStateWithLifecycle()
    val turboMode by viewModel.turboMode.collectAsStateWithLifecycle()
    val currentDeviceName by viewModel.deviceName.collectAsStateWithLifecycle()
    val tempFilesSizeBytes by viewModel.tempFilesSizeBytes.collectAsStateWithLifecycle()
    var editedName by remember(currentDeviceName) { mutableStateOf(currentDeviceName) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.refreshTempFilesSize()
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            containerColor = SurfaceDark,
            title = { Text(stringResource(R.string.settings_privacy_policy)) },
            text = { Text(stringResource(R.string.settings_privacy_policy_body)) },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text(stringResource(R.string.action_close), color = TextPrimary)
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
            title = { Text(stringResource(R.string.settings_title), color = TextPrimary) }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language entry
            Surface(
                onClick = onOpenLanguage,
                color = SurfaceDark,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, OutlineSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 64.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.settings_language),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = when (language) {
                                AppLanguage.OROMO -> stringResource(R.string.settings_lang_om)
                                AppLanguage.AMHARIC -> stringResource(R.string.settings_lang_am)
                                AppLanguage.ENGLISH -> stringResource(R.string.settings_lang_en)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Icon(AppIcons.Language, contentDescription = null, tint = TextPrimary)
                }
            }

            // Always-on encryption status card
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.settings_security_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.settings_security_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            // Turbo Speed Mode
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = stringResource(R.string.settings_turbo_title),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.settings_turbo_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = turboMode,
                        onCheckedChange = { viewModel.setTurboMode(it) }
                    )
                }
            }

            // Trusted Devices
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.settings_trusted_devices, trustedDevices.size),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    if (trustedDevices.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { viewModel.clearTrustedDevices() },
                            border = BorderStroke(1.dp, OutlineStrong),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.settings_clear_trusted), color = TextPrimary)
                        }
                    }
                }
            }

            // Temporary Files (.part + share_cache) with Clear button
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                        Text(
                            text = stringResource(R.string.settings_temp_files_title),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(
                                R.string.settings_temp_files_size,
                                Formatters.formatBytes(tempFilesSizeBytes)
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    OutlinedButton(
                        onClick = { viewModel.clearTemporaryFiles() },
                        enabled = tempFilesSizeBytes > 0L,
                        border = BorderStroke(1.dp, OutlineStrong),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.settings_temp_files_clear), color = TextPrimary)
                    }
                }
            }

            // Device Name
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.settings_device_name),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = editedName,
                            onValueChange = { editedName = it },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = { viewModel.setDeviceName(editedName) },
                            colors = ButtonDefaults.buttonColors(containerColor = TextPrimary, contentColor = BgBlack),
                            modifier = Modifier.heightIn(min = 52.dp)
                        ) {
                            Text(stringResource(R.string.action_save), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Storage & Privacy
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.settings_storage_path),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = viewModel.storageOrganizer.getDisplayStoragePath(),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showPrivacyDialog = true },
                        border = BorderStroke(1.dp, OutlineStrong),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.settings_privacy_policy), color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.settings_privacy_note),
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val selectedLang by viewModel.language.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = BgBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgBlack),
                title = { Text(stringResource(R.string.language_screen_title), color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = TextPrimary
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            listOf(
                AppLanguage.ENGLISH to R.string.settings_lang_en,
                AppLanguage.OROMO to R.string.settings_lang_om,
                AppLanguage.AMHARIC to R.string.settings_lang_am
            ).forEach { (lang, labelRes) ->
                val isSelected = selectedLang == lang
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) TextPrimary else OutlineSubtle),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 64.dp)
                        .clickable { viewModel.setLanguage(lang) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(labelRes),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = TextPrimary
                        )
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
