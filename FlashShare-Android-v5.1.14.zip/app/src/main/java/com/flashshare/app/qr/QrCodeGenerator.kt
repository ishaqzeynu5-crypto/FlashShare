package com.flashshare.app.qr

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object QrCodeGenerator {

    private const val MAX_CACHE_ENTRIES = 12

    private val cacheLock = Any()
    private val bitmapCache = object : LinkedHashMap<String, Bitmap>(MAX_CACHE_ENTRIES + 1, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean {
            return size > MAX_CACHE_ENTRIES
        }
    }

    fun getCached(content: String?): Bitmap? {
        if (content.isNullOrBlank()) return null
        return synchronized(cacheLock) {
            bitmapCache[content]?.takeUnless { it.isRecycled }
        }
    }

    /**
     * Pure-JVM testable minimal QR matrix encoder (width=0, height=0 -> ~37x37..65x65 modules).
     */
    fun encodeMinimalMatrix(content: String): BitMatrix? {
        if (content.isBlank()) return null
        return runCatching {
            val hints = mapOf(
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.MARGIN to 1
            )
            QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 0, 0, hints)
        }.getOrNull()
    }

    /**
     * Generates (or returns cached) a minimal-module QR Bitmap suitable for crisp nearest-neighbor
     * GPU scaling in Compose (FilterQuality.None). Avoids 560x560 pixel loops on the main thread.
     */
    fun generateBitmap(content: String, sizePx: Int = 0): Bitmap? {
        if (content.isBlank()) return null
        if (sizePx <= 0) {
            getCached(content)?.let { return it }
        }
        return runCatching {
            val matrix = if (sizePx <= 0) {
                encodeMinimalMatrix(content)
            } else {
                val hints = mapOf(
                    EncodeHintType.CHARACTER_SET to "UTF-8",
                    EncodeHintType.MARGIN to 1
                )
                QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            } ?: return null

            val width = matrix.width
            val height = matrix.height
            val pixels = IntArray(width * height)
            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
                }
            }
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565).apply {
                setPixels(pixels, 0, width, 0, 0, width, height)
            }
            if (sizePx <= 0) {
                synchronized(cacheLock) {
                    bitmapCache[content] = bitmap
                }
            }
            bitmap
        }.getOrNull()
    }

    suspend fun generateBitmapAsync(content: String): Bitmap? {
        if (content.isBlank()) return null
        getCached(content)?.let { return it }
        return withContext(Dispatchers.Default) {
            generateBitmap(content, 0)
        }
    }
}
